import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/joinnow',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/joinnow',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

const JoinController = { index, store }

export default JoinController