import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/leader/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/leader',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderController::editProfile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
export const editProfile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editProfile.url(options),
    method: 'get',
})

editProfile.definition = {
    methods: ["get","head"],
    url: '/leader/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::editProfile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
editProfile.url = (options?: RouteQueryOptions) => {
    return editProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::editProfile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
editProfile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editProfile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::editProfile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
editProfile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editProfile.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderController::updateProfile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
export const updateProfile = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile.url(options),
    method: 'put',
})

updateProfile.definition = {
    methods: ["put"],
    url: '/leader/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaderController::updateProfile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
updateProfile.url = (options?: RouteQueryOptions) => {
    return updateProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::updateProfile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
updateProfile.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LeaderController::editBiography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
export const editBiography = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editBiography.url(options),
    method: 'get',
})

editBiography.definition = {
    methods: ["get","head"],
    url: '/leader/biography',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::editBiography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
editBiography.url = (options?: RouteQueryOptions) => {
    return editBiography.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::editBiography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
editBiography.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editBiography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::editBiography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
editBiography.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editBiography.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderController::updateBiography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
export const updateBiography = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBiography.url(options),
    method: 'put',
})

updateBiography.definition = {
    methods: ["put"],
    url: '/leader/biography',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaderController::updateBiography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
updateBiography.url = (options?: RouteQueryOptions) => {
    return updateBiography.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::updateBiography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
updateBiography.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBiography.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/leader/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

const LeaderController = { create, store, editProfile, updateProfile, editBiography, updateBiography, show }

export default LeaderController