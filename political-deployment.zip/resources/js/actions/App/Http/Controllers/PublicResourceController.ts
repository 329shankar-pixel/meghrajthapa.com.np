import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicResourceController::create
* @see app/Http/Controllers/PublicResourceController.php:18
* @route '/community/resources/submit'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/community/resources/submit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicResourceController::create
* @see app/Http/Controllers/PublicResourceController.php:18
* @route '/community/resources/submit'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicResourceController::create
* @see app/Http/Controllers/PublicResourceController.php:18
* @route '/community/resources/submit'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicResourceController::create
* @see app/Http/Controllers/PublicResourceController.php:18
* @route '/community/resources/submit'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicResourceController::store
* @see app/Http/Controllers/PublicResourceController.php:33
* @route '/community/resources/submit'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/community/resources/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicResourceController::store
* @see app/Http/Controllers/PublicResourceController.php:33
* @route '/community/resources/submit'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicResourceController::store
* @see app/Http/Controllers/PublicResourceController.php:33
* @route '/community/resources/submit'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

const PublicResourceController = { create, store }

export default PublicResourceController