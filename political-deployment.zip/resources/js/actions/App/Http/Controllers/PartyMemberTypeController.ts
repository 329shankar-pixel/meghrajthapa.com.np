import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PartyMemberTypeController::index
* @see app/Http/Controllers/PartyMemberTypeController.php:24
* @route '/party-member-types'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/party-member-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberTypeController::index
* @see app/Http/Controllers/PartyMemberTypeController.php:24
* @route '/party-member-types'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberTypeController::index
* @see app/Http/Controllers/PartyMemberTypeController.php:24
* @route '/party-member-types'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::index
* @see app/Http/Controllers/PartyMemberTypeController.php:24
* @route '/party-member-types'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::create
* @see app/Http/Controllers/PartyMemberTypeController.php:38
* @route '/party-member-types/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/party-member-types/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberTypeController::create
* @see app/Http/Controllers/PartyMemberTypeController.php:38
* @route '/party-member-types/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberTypeController::create
* @see app/Http/Controllers/PartyMemberTypeController.php:38
* @route '/party-member-types/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::create
* @see app/Http/Controllers/PartyMemberTypeController.php:38
* @route '/party-member-types/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::store
* @see app/Http/Controllers/PartyMemberTypeController.php:46
* @route '/party-member-types'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/party-member-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PartyMemberTypeController::store
* @see app/Http/Controllers/PartyMemberTypeController.php:46
* @route '/party-member-types'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberTypeController::store
* @see app/Http/Controllers/PartyMemberTypeController.php:46
* @route '/party-member-types'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::show
* @see app/Http/Controllers/PartyMemberTypeController.php:0
* @route '/party-member-types/{party_member_type}'
*/
export const show = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/party-member-types/{party_member_type}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberTypeController::show
* @see app/Http/Controllers/PartyMemberTypeController.php:0
* @route '/party-member-types/{party_member_type}'
*/
show.url = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member_type: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member_type: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member_type: args.party_member_type,
    }

    return show.definition.url
            .replace('{party_member_type}', parsedArgs.party_member_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberTypeController::show
* @see app/Http/Controllers/PartyMemberTypeController.php:0
* @route '/party-member-types/{party_member_type}'
*/
show.get = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::show
* @see app/Http/Controllers/PartyMemberTypeController.php:0
* @route '/party-member-types/{party_member_type}'
*/
show.head = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::edit
* @see app/Http/Controllers/PartyMemberTypeController.php:65
* @route '/party-member-types/{party_member_type}/edit'
*/
export const edit = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/party-member-types/{party_member_type}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberTypeController::edit
* @see app/Http/Controllers/PartyMemberTypeController.php:65
* @route '/party-member-types/{party_member_type}/edit'
*/
edit.url = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member_type: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member_type: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member_type: args.party_member_type,
    }

    return edit.definition.url
            .replace('{party_member_type}', parsedArgs.party_member_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberTypeController::edit
* @see app/Http/Controllers/PartyMemberTypeController.php:65
* @route '/party-member-types/{party_member_type}/edit'
*/
edit.get = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::edit
* @see app/Http/Controllers/PartyMemberTypeController.php:65
* @route '/party-member-types/{party_member_type}/edit'
*/
edit.head = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::update
* @see app/Http/Controllers/PartyMemberTypeController.php:75
* @route '/party-member-types/{party_member_type}'
*/
export const update = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/party-member-types/{party_member_type}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\PartyMemberTypeController::update
* @see app/Http/Controllers/PartyMemberTypeController.php:75
* @route '/party-member-types/{party_member_type}'
*/
update.url = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member_type: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member_type: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member_type: args.party_member_type,
    }

    return update.definition.url
            .replace('{party_member_type}', parsedArgs.party_member_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberTypeController::update
* @see app/Http/Controllers/PartyMemberTypeController.php:75
* @route '/party-member-types/{party_member_type}'
*/
update.put = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::update
* @see app/Http/Controllers/PartyMemberTypeController.php:75
* @route '/party-member-types/{party_member_type}'
*/
update.patch = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\PartyMemberTypeController::destroy
* @see app/Http/Controllers/PartyMemberTypeController.php:93
* @route '/party-member-types/{party_member_type}'
*/
export const destroy = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/party-member-types/{party_member_type}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PartyMemberTypeController::destroy
* @see app/Http/Controllers/PartyMemberTypeController.php:93
* @route '/party-member-types/{party_member_type}'
*/
destroy.url = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member_type: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member_type: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member_type: args.party_member_type,
    }

    return destroy.definition.url
            .replace('{party_member_type}', parsedArgs.party_member_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberTypeController::destroy
* @see app/Http/Controllers/PartyMemberTypeController.php:93
* @route '/party-member-types/{party_member_type}'
*/
destroy.delete = (args: { party_member_type: string | number } | [party_member_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

const PartyMemberTypeController = { index, create, store, show, edit, update, destroy }

export default PartyMemberTypeController