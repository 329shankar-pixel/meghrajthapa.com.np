import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PartyMemberExportController::exportExcel
* @see app/Http/Controllers/PartyMemberExportController.php:22
* @route '/party-members-export/excel'
*/
export const exportExcel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportExcel.url(options),
    method: 'get',
})

exportExcel.definition = {
    methods: ["get","head"],
    url: '/party-members-export/excel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberExportController::exportExcel
* @see app/Http/Controllers/PartyMemberExportController.php:22
* @route '/party-members-export/excel'
*/
exportExcel.url = (options?: RouteQueryOptions) => {
    return exportExcel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberExportController::exportExcel
* @see app/Http/Controllers/PartyMemberExportController.php:22
* @route '/party-members-export/excel'
*/
exportExcel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportExcel.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberExportController::exportExcel
* @see app/Http/Controllers/PartyMemberExportController.php:22
* @route '/party-members-export/excel'
*/
exportExcel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportExcel.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberExportController::exportPdf
* @see app/Http/Controllers/PartyMemberExportController.php:81
* @route '/party-members-export/pdf'
*/
export const exportPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

exportPdf.definition = {
    methods: ["get","head"],
    url: '/party-members-export/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberExportController::exportPdf
* @see app/Http/Controllers/PartyMemberExportController.php:81
* @route '/party-members-export/pdf'
*/
exportPdf.url = (options?: RouteQueryOptions) => {
    return exportPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberExportController::exportPdf
* @see app/Http/Controllers/PartyMemberExportController.php:81
* @route '/party-members-export/pdf'
*/
exportPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberExportController::exportPdf
* @see app/Http/Controllers/PartyMemberExportController.php:81
* @route '/party-members-export/pdf'
*/
exportPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportPdf.url(options),
    method: 'head',
})

const PartyMemberExportController = { exportExcel, exportPdf }

export default PartyMemberExportController