import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\SiteSettingController::index
* @see app/Http/Controllers/Settings/SiteSettingController.php:21
* @route '/site-settings'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/site-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\SiteSettingController::index
* @see app/Http/Controllers/Settings/SiteSettingController.php:21
* @route '/site-settings'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SiteSettingController::index
* @see app/Http/Controllers/Settings/SiteSettingController.php:21
* @route '/site-settings'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\SiteSettingController::index
* @see app/Http/Controllers/Settings/SiteSettingController.php:21
* @route '/site-settings'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\SiteSettingController::update
* @see app/Http/Controllers/Settings/SiteSettingController.php:28
* @route '/site-settings'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/site-settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\SiteSettingController::update
* @see app/Http/Controllers/Settings/SiteSettingController.php:28
* @route '/site-settings'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SiteSettingController::update
* @see app/Http/Controllers/Settings/SiteSettingController.php:28
* @route '/site-settings'
*/
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

const SiteSettingController = { index, update }

export default SiteSettingController