import SiteSettingController from './SiteSettingController'
import StatController from './StatController'
import MissionController from './MissionController'
import ProfileController from './ProfileController'
import PasswordController from './PasswordController'
import TwoFactorAuthenticationController from './TwoFactorAuthenticationController'

const Settings = {
    SiteSettingController: Object.assign(SiteSettingController, SiteSettingController),
    StatController: Object.assign(StatController, StatController),
    MissionController: Object.assign(MissionController, MissionController),
    ProfileController: Object.assign(ProfileController, ProfileController),
    PasswordController: Object.assign(PasswordController, PasswordController),
    TwoFactorAuthenticationController: Object.assign(TwoFactorAuthenticationController, TwoFactorAuthenticationController),
}

export default Settings