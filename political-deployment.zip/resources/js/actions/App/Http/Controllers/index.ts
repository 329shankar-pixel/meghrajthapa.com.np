import SitemapController from './SitemapController'
import PublicController from './PublicController'
import JoinController from './JoinController'
import LocationController from './LocationController'
import DashboardController from './DashboardController'
import RoleController from './RoleController'
import PermissionController from './PermissionController'
import UserController from './UserController'
import PartyMemberController from './PartyMemberController'
import PartyMemberExportController from './PartyMemberExportController'
import PartyMemberTypeController from './PartyMemberTypeController'
import NewsController from './NewsController'
import BlogController from './BlogController'
import ActivityController from './ActivityController'
import EventController from './EventController'
import VolunteerController from './VolunteerController'
import ResourceController from './ResourceController'
import LeaderController from './LeaderController'
import QuoteController from './QuoteController'
import InfographicController from './InfographicController'
import LeaderVideoController from './LeaderVideoController'
import LeaderCategoryController from './LeaderCategoryController'
import LeaderGalleryController from './LeaderGalleryController'
import LeaderTimelineController from './LeaderTimelineController'
import Settings from './Settings'
import PublicResourceController from './PublicResourceController'

const Controllers = {
    SitemapController: Object.assign(SitemapController, SitemapController),
    PublicController: Object.assign(PublicController, PublicController),
    JoinController: Object.assign(JoinController, JoinController),
    LocationController: Object.assign(LocationController, LocationController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    RoleController: Object.assign(RoleController, RoleController),
    PermissionController: Object.assign(PermissionController, PermissionController),
    UserController: Object.assign(UserController, UserController),
    PartyMemberController: Object.assign(PartyMemberController, PartyMemberController),
    PartyMemberExportController: Object.assign(PartyMemberExportController, PartyMemberExportController),
    PartyMemberTypeController: Object.assign(PartyMemberTypeController, PartyMemberTypeController),
    NewsController: Object.assign(NewsController, NewsController),
    BlogController: Object.assign(BlogController, BlogController),
    ActivityController: Object.assign(ActivityController, ActivityController),
    EventController: Object.assign(EventController, EventController),
    VolunteerController: Object.assign(VolunteerController, VolunteerController),
    ResourceController: Object.assign(ResourceController, ResourceController),
    LeaderController: Object.assign(LeaderController, LeaderController),
    QuoteController: Object.assign(QuoteController, QuoteController),
    InfographicController: Object.assign(InfographicController, InfographicController),
    LeaderVideoController: Object.assign(LeaderVideoController, LeaderVideoController),
    LeaderCategoryController: Object.assign(LeaderCategoryController, LeaderCategoryController),
    LeaderGalleryController: Object.assign(LeaderGalleryController, LeaderGalleryController),
    LeaderTimelineController: Object.assign(LeaderTimelineController, LeaderTimelineController),
    Settings: Object.assign(Settings, Settings),
    PublicResourceController: Object.assign(PublicResourceController, PublicResourceController),
}

export default Controllers