import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicController::submit
* @see app/Http/Controllers/PublicController.php:157
* @route '/public-resources/submit'
*/
export const submit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: submit.url(options),
    method: 'get',
})

submit.definition = {
    methods: ["get","head"],
    url: '/public-resources/submit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::submit
* @see app/Http/Controllers/PublicController.php:157
* @route '/public-resources/submit'
*/
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::submit
* @see app/Http/Controllers/PublicController.php:157
* @route '/public-resources/submit'
*/
submit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: submit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::submit
* @see app/Http/Controllers/PublicController.php:157
* @route '/public-resources/submit'
*/
submit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: submit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::store
* @see app/Http/Controllers/PublicController.php:171
* @route '/public-resources/submit'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/public-resources/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicController::store
* @see app/Http/Controllers/PublicController.php:171
* @route '/public-resources/submit'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::store
* @see app/Http/Controllers/PublicController.php:171
* @route '/public-resources/submit'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

const resources = {
    submit: Object.assign(submit, submit),
    store: Object.assign(store, store),
}

export default resources