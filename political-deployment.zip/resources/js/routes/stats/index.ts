import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\StatController::index
* @see app/Http/Controllers/Settings/StatController.php:24
* @route '/stats'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\StatController::index
* @see app/Http/Controllers/Settings/StatController.php:24
* @route '/stats'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\StatController::index
* @see app/Http/Controllers/Settings/StatController.php:24
* @route '/stats'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\StatController::index
* @see app/Http/Controllers/Settings/StatController.php:24
* @route '/stats'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\StatController::create
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/stats/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\StatController::create
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\StatController::create
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\StatController::create
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\StatController::store
* @see app/Http/Controllers/Settings/StatController.php:31
* @route '/stats'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stats',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\StatController::store
* @see app/Http/Controllers/Settings/StatController.php:31
* @route '/stats'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\StatController::store
* @see app/Http/Controllers/Settings/StatController.php:31
* @route '/stats'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\StatController::show
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}'
*/
export const show = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/stats/{stat}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\StatController::show
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}'
*/
show.url = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stat: args }
    }

    if (Array.isArray(args)) {
        args = {
            stat: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stat: args.stat,
    }

    return show.definition.url
            .replace('{stat}', parsedArgs.stat.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\StatController::show
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}'
*/
show.get = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\StatController::show
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}'
*/
show.head = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\StatController::edit
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}/edit'
*/
export const edit = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/stats/{stat}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\StatController::edit
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}/edit'
*/
edit.url = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stat: args }
    }

    if (Array.isArray(args)) {
        args = {
            stat: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stat: args.stat,
    }

    return edit.definition.url
            .replace('{stat}', parsedArgs.stat.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\StatController::edit
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}/edit'
*/
edit.get = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\StatController::edit
* @see app/Http/Controllers/Settings/StatController.php:0
* @route '/stats/{stat}/edit'
*/
edit.head = (args: { stat: string | number } | [stat: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\StatController::update
* @see app/Http/Controllers/Settings/StatController.php:45
* @route '/stats/{stat}'
*/
export const update = (args: { stat: number | { id: number } } | [stat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/stats/{stat}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Settings\StatController::update
* @see app/Http/Controllers/Settings/StatController.php:45
* @route '/stats/{stat}'
*/
update.url = (args: { stat: number | { id: number } } | [stat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stat: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { stat: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            stat: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stat: typeof args.stat === 'object'
        ? args.stat.id
        : args.stat,
    }

    return update.definition.url
            .replace('{stat}', parsedArgs.stat.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\StatController::update
* @see app/Http/Controllers/Settings/StatController.php:45
* @route '/stats/{stat}'
*/
update.put = (args: { stat: number | { id: number } } | [stat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\StatController::update
* @see app/Http/Controllers/Settings/StatController.php:45
* @route '/stats/{stat}'
*/
update.patch = (args: { stat: number | { id: number } } | [stat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Settings\StatController::destroy
* @see app/Http/Controllers/Settings/StatController.php:59
* @route '/stats/{stat}'
*/
export const destroy = (args: { stat: number | { id: number } } | [stat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/stats/{stat}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\StatController::destroy
* @see app/Http/Controllers/Settings/StatController.php:59
* @route '/stats/{stat}'
*/
destroy.url = (args: { stat: number | { id: number } } | [stat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stat: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { stat: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            stat: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stat: typeof args.stat === 'object'
        ? args.stat.id
        : args.stat,
    }

    return destroy.definition.url
            .replace('{stat}', parsedArgs.stat.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\StatController::destroy
* @see app/Http/Controllers/Settings/StatController.php:59
* @route '/stats/{stat}'
*/
destroy.delete = (args: { stat: number | { id: number } } | [stat: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

const stats = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default stats