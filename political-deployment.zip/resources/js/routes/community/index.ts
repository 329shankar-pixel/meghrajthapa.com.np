import resources from './resources'

const community = {
    resources: Object.assign(resources, resources),
}

export default community