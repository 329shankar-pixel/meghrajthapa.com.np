import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\VolunteerController::index
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/volunteers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VolunteerController::index
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VolunteerController::index
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\VolunteerController::index
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\VolunteerController::create
* @see app/Http/Controllers/VolunteerController.php:27
* @route '/volunteers/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/volunteers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VolunteerController::create
* @see app/Http/Controllers/VolunteerController.php:27
* @route '/volunteers/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VolunteerController::create
* @see app/Http/Controllers/VolunteerController.php:27
* @route '/volunteers/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\VolunteerController::create
* @see app/Http/Controllers/VolunteerController.php:27
* @route '/volunteers/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\VolunteerController::store
* @see app/Http/Controllers/VolunteerController.php:47
* @route '/volunteers'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/volunteers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\VolunteerController::store
* @see app/Http/Controllers/VolunteerController.php:47
* @route '/volunteers'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VolunteerController::store
* @see app/Http/Controllers/VolunteerController.php:47
* @route '/volunteers'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\VolunteerController::show
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers/{volunteer}'
*/
export const show = (args: { volunteer: string | number } | [volunteer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/volunteers/{volunteer}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VolunteerController::show
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers/{volunteer}'
*/
show.url = (args: { volunteer: string | number } | [volunteer: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { volunteer: args }
    }

    if (Array.isArray(args)) {
        args = {
            volunteer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        volunteer: args.volunteer,
    }

    return show.definition.url
            .replace('{volunteer}', parsedArgs.volunteer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VolunteerController::show
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers/{volunteer}'
*/
show.get = (args: { volunteer: string | number } | [volunteer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\VolunteerController::show
* @see app/Http/Controllers/VolunteerController.php:0
* @route '/volunteers/{volunteer}'
*/
show.head = (args: { volunteer: string | number } | [volunteer: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\VolunteerController::edit
* @see app/Http/Controllers/VolunteerController.php:65
* @route '/volunteers/{volunteer}/edit'
*/
export const edit = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/volunteers/{volunteer}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VolunteerController::edit
* @see app/Http/Controllers/VolunteerController.php:65
* @route '/volunteers/{volunteer}/edit'
*/
edit.url = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { volunteer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { volunteer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            volunteer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        volunteer: typeof args.volunteer === 'object'
        ? args.volunteer.id
        : args.volunteer,
    }

    return edit.definition.url
            .replace('{volunteer}', parsedArgs.volunteer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VolunteerController::edit
* @see app/Http/Controllers/VolunteerController.php:65
* @route '/volunteers/{volunteer}/edit'
*/
edit.get = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\VolunteerController::edit
* @see app/Http/Controllers/VolunteerController.php:65
* @route '/volunteers/{volunteer}/edit'
*/
edit.head = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\VolunteerController::update
* @see app/Http/Controllers/VolunteerController.php:98
* @route '/volunteers/{volunteer}'
*/
export const update = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/volunteers/{volunteer}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\VolunteerController::update
* @see app/Http/Controllers/VolunteerController.php:98
* @route '/volunteers/{volunteer}'
*/
update.url = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { volunteer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { volunteer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            volunteer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        volunteer: typeof args.volunteer === 'object'
        ? args.volunteer.id
        : args.volunteer,
    }

    return update.definition.url
            .replace('{volunteer}', parsedArgs.volunteer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VolunteerController::update
* @see app/Http/Controllers/VolunteerController.php:98
* @route '/volunteers/{volunteer}'
*/
update.put = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\VolunteerController::update
* @see app/Http/Controllers/VolunteerController.php:98
* @route '/volunteers/{volunteer}'
*/
update.patch = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\VolunteerController::destroy
* @see app/Http/Controllers/VolunteerController.php:116
* @route '/volunteers/{volunteer}'
*/
export const destroy = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/volunteers/{volunteer}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\VolunteerController::destroy
* @see app/Http/Controllers/VolunteerController.php:116
* @route '/volunteers/{volunteer}'
*/
destroy.url = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { volunteer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { volunteer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            volunteer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        volunteer: typeof args.volunteer === 'object'
        ? args.volunteer.id
        : args.volunteer,
    }

    return destroy.definition.url
            .replace('{volunteer}', parsedArgs.volunteer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VolunteerController::destroy
* @see app/Http/Controllers/VolunteerController.php:116
* @route '/volunteers/{volunteer}'
*/
destroy.delete = (args: { volunteer: number | { id: number } } | [volunteer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

const volunteers = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default volunteers