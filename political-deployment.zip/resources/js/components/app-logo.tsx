import { usePage } from '@inertiajs/react';
import AppLogoIcon from './app-logo-icon';

export default function AppLogo() {
    const { props } = usePage<any>();
    const settings = props.settings || {};
    const partyName = settings.party_name || props.name || 'राजनीतिक दल';
    const siteLogo = settings.site_logo;

    return (
        <>
            <div className="flex aspect-square size-8 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground overflow-hidden">
                {siteLogo ? (
                    <img src={`/storage/${siteLogo}`} alt={partyName} className="size-full object-cover" />
                ) : (
                    <AppLogoIcon className="size-5 fill-current text-white dark:text-black" />
                )}
            </div>
            <div className="ml-1 grid flex-1 text-left text-sm">
                <span className="mb-0.5 truncate leading-tight font-semibold">
                    {partyName}
                </span>
            </div>
        </>
    );
}
