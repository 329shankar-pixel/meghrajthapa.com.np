import React from 'react';
import { Calendar, ChevronRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface TimelineItem {
  id: number;
  title: string;
  date: string;
  photo: string | null;
}

interface InteractiveTimelineProps {
  items: TimelineItem[];
}

export default function InteractiveTimeline({ items }: InteractiveTimelineProps) {
  if (!items || items.length === 0) {
    return (
      <div className="text-center py-20 bg-gray-50 dark:bg-gray-900/50 rounded-[3rem] border-2 border-dashed border-gray-100 dark:border-gray-800">
        <div className="w-20 h-20 bg-white dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl border border-gray-100 dark:border-gray-700">
          <Calendar className="w-10 h-10 text-gray-200 dark:text-gray-700" />
        </div>
        <p className="text-gray-400 dark:text-gray-500 font-bold uppercase tracking-widest text-sm">Our journey is just beginning...</p>
      </div>
    );
  }

  return (
    <div className="relative max-w-5xl mx-auto px-4">
      {/* Central Line */}
      <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-[var(--political-red)] via-[var(--political-green)] to-[var(--political-red)] transform md:-translate-x-1/2 opacity-20" />

      <div className="space-y-24">
        {items.map((item, index) => (
          <div
            key={item.id}
            className={`relative flex flex-col md:flex-row items-center gap-8 ${index % 2 === 0 ? '' : 'md:flex-row-reverse'
              }`}
          >
            {/* Animated Dot */}
            <div className="absolute left-0 md:left-1/2 w-8 h-8 rounded-full bg-white dark:bg-gray-950 border-4 border-[var(--political-red)] transform -translate-x-1/2 md:-translate-x-1/2 z-10 shadow-[0_0_20px_rgba(204,0,0,0.3)] animate-pulse" />

            {/* Content Card */}
            <div className={`w-full md:w-[calc(50%-3rem)] ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
              <div
                className={`group p-1 rounded-[2.5rem] bg-gradient-to-br from-gray-100 to-white dark:from-gray-800 dark:to-gray-950 hover:from-[var(--political-red)]/10 hover:to-[var(--political-green)]/10 transition-all duration-500 shadow-sm hover:shadow-2xl hover:-translate-y-2 ${index % 2 === 0 ? 'fade-in-section' : 'fade-in-section'
                  }`}
              >
                <div className="bg-white dark:bg-gray-900 rounded-[2.3rem] overflow-hidden">
                  {item.photo && (
                    <div className="h-64 overflow-hidden relative">
                      <img
                        src={`/storage/${item.photo}`}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      <div className="absolute bottom-6 left-8 right-8 text-left">
                        <div className="flex items-center gap-2 text-[var(--political-red-light)] mb-2">
                          <Calendar className="w-4 h-4" />
                          <span className="text-sm font-black uppercase tracking-widest">
                            {new Date(item.date).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long'
                            })}
                          </span>
                        </div>
                        <h3 className="text-2xl font-black text-white leading-tight">{item.title}</h3>
                      </div>
                    </div>
                  )}
                  {!item.photo && (
                    <div className="p-10 text-left">
                      <div className="flex items-center gap-2 text-[var(--political-red)] mb-4">
                        <Calendar className="w-5 h-5" />
                        <span className="text-sm font-black uppercase tracking-widest">
                          {new Date(item.date).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long'
                          })}
                        </span>
                      </div>
                      <h3 className="text-2xl font-black text-gray-900 dark:text-white leading-tight mb-4">{item.title}</h3>
                      <div className="w-12 h-1 bg-[var(--political-red)] rounded-full group-hover:w-24 transition-all duration-500" />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Year Bubble (Visible on Desktop) */}
            <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 items-center justify-center w-24 h-12 rounded-full bg-white dark:bg-gray-900 border-2 border-gray-100 dark:border-gray-800 shadow-lg z-20 font-black text-[var(--political-red)]">
              {new Date(item.date).getFullYear()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
