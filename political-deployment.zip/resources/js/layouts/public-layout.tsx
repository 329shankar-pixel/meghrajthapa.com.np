import { Link, usePage } from '@inertiajs/react';
import { Facebook as FacebookLucide, Twitter, Instagram, Youtube, Globe, Menu, X as XLucide, ChevronRight, Moon, Sun } from 'lucide-react';
import { FaFacebookF, FaInstagram, FaYoutube, FaXTwitter, FaWhatsapp, FaViber } from 'react-icons/fa6';
import { TbWorld } from 'react-icons/tb';
import { useState, useEffect } from 'react';
import AppearanceToggleDropdown from '@/components/appearance-dropdown';

interface SocialLinks {
  facebook?: string;
  twitter?: string;
  instagram?: string;
  youtube?: string;
  whatsapp?: string;
  viber?: string;
  website?: string;
}

interface Props {
  children: React.ReactNode;
  partyName?: string;
  socialLinks?: SocialLinks;
}

export default function PublicLayout({
  children,
  socialLinks,
}: Props) {
  const { name, settings, leader } = usePage<any>().props;
  const partyName = name || 'राजनीतिक दल';
  const tagline = settings?.site_tagline || 'Movement for Progress';
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [visible, setVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      // Scrolled state for background styling
      setScrolled(currentScrollY > 20);

      // Visible state for hide/show on scroll
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setVisible(false);
      } else {
        setVisible(true);
      }

      setLastScrollY(currentScrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const socialIcons: Record<string, any> = {
    facebook: FaFacebookF,
    twitter: FaXTwitter,
    instagram: FaInstagram,
    youtube: FaYoutube,
    whatsapp: FaWhatsapp,
    viber: FaViber,
    website: TbWorld,
  };

  const navLinks = [
    { href: '/', label: 'Home', isLink: true },
    { href: '/biography', label: 'Biography', isLink: true },
    { href: '/program/events', label: 'Events', isLink: true },
    { href: '/program/activities', label: 'Activities', isLink: true },
    { href: '/community/resources/submit', label: 'Community', isLink: true },
    { href: '/updates/blog', label: 'Posts', isLink: true },
    { href: '/updates/news', label: 'News', isLink: true },
    { href: '/media/galleries', label: 'Gallery', isLink: true },
    { href: '/media/videos', label: 'Videos', isLink: true },
    { href: '/media/infographics', label: 'Infographics', isLink: true },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-950 theme-political font-sans selection:bg-[var(--political-red)] selection:text-white transition-colors duration-500">
      {/* Top Bar - Hidden on scroll to save space */}
      <div
        className={`bg-white dark:bg-gray-950 border-b border-gray-100 dark:border-gray-900 transition-all duration-500 overflow-hidden ${scrolled ? 'h-0 opacity-0' : 'h-10 opacity-100'
          }`}
      >
        <div className="w-full px-4 md:px-12 h-full flex justify-between items-center text-xs font-medium text-gray-500 dark:text-gray-400">
          <div className="flex items-center gap-6">
            {socialLinks && Object.entries(socialLinks).map(([platform, url]) => {
              if (!url) return null;
              const Icon = socialIcons[platform] || Globe;
              return (
                <a
                  key={platform}
                  href={url.startsWith('http') ? url : `https://${url}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[var(--political-red)] transition-colors flex items-center gap-1"
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="capitalize">{platform === 'twitter' ? 'X' : platform}</span>
                </a>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <header
        className={`sticky top-0 z-50 transition-all duration-500 transform ${visible ? 'translate-y-0' : '-translate-y-full'
          } ${scrolled
            ? 'bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] py-2'
            : 'bg-white dark:bg-gray-950 py-4'
          }`}
      >
        <div className="w-full px-4 md:px-12">
          <div className="flex items-center justify-between gap-4">
            {/* Leftmost: Party Flag */}
            {settings.party_flag && (
              <div className="hidden md:block shrink-0">
                <img
                  src={`/storage/${settings.party_flag}`}
                  alt="Party Flag"
                  className="h-12 w-auto object-contain drop-shadow-md hover:scale-105 transition-transform duration-500"
                />
              </div>
            )}

            {/* Logo Group */}
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-4 group">
                <div className="relative">
                  <div className="w-12 h-12 rounded-2xl overflow-hidden shadow-lg group-hover:rotate-6 transition-all duration-300 border-2 border-white dark:border-gray-800">
                    {leader?.image ? (
                      <img src={`/storage/${leader.image}`} alt={leader.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-[var(--political-red)] to-[var(--political-red-dark)] flex items-center justify-center text-white text-xl font-bold">
                        {partyName.charAt(0)}
                      </div>
                    )}
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-lg bg-[var(--political-green)] border-2 border-white dark:border-gray-900 shadow-sm" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-black tracking-tight text-[var(--political-green)] group-hover:text-[var(--political-red)] transition-colors leading-none mb-1">
                    {partyName}
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 dark:text-gray-500">{tagline}</span>
                </div>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden xl:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="relative px-5 py-2 text-[15px] font-semibold text-gray-600 dark:text-gray-400 hover:text-[var(--political-red)] dark:hover:text-white transition-colors group"
                >
                  {link.label}
                  <span className="absolute bottom-0 left-1/2 w-0 h-0.5 bg-[var(--political-red)] group-hover:w-1/2 group-hover:left-1/4 transition-all duration-300" />
                </Link>
              ))}
              <Link
                href="/joinnow"
                className="ml-6 bg-gradient-to-r from-[var(--political-green)] to-[var(--political-green-dark)] text-white px-8 py-3 rounded-2xl font-bold text-sm shadow-lg shadow-green-900/10 hover:shadow-green-900/20 hover:scale-[1.02] active:scale-95 transition-all animate-pulse-cta"
              >
                JOIN THE TEAM
              </Link>
            </nav>

            {/* Action Group: Appearance & Election Symbol & Mobile Menu */}
            <div className="flex items-center gap-4 group/actions">

              {/* Rightmost: Election Symbol */}
              {settings.election_symbol && (
                <div className="hidden md:block shrink-0">
                  <img
                    src={`/storage/${settings.election_symbol}`}
                    alt="Election Symbol"
                    className="h-12 w-auto object-contain drop-shadow-md hover:rotate-12 transition-transform duration-500"
                  />
                </div>
              )}

              {/* Mobile Menu Button */}
              <div className="xl:hidden flex items-center gap-2">
                <button
                  className="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white border border-gray-100 dark:border-gray-800 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                >
                  {mobileMenuOpen ? <XLucide className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
        {/* Mobile Navigation */}
        <div
          className={`xl:hidden fixed inset-x-0 top-[100%] bg-white/95 dark:bg-gray-950/95 backdrop-blur-2xl border-t border-gray-100 dark:border-gray-900 shadow-2xl transition-all duration-500 overflow-hidden ${mobileMenuOpen ? 'max-h-[80vh] py-8 opacity-100' : 'max-h-0 opacity-0'
            }`}
        >
          <div className="flex flex-col px-6 gap-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between px-6 py-4 text-lg font-bold text-gray-800 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-900 rounded-2xl transition-all"
              >
                {link.label}
                <ChevronRight className="w-5 h-5 text-gray-300 dark:text-gray-600" />
              </Link>
            ))}
            <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-900">
              <Link
                href="/joinnow"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-3 bg-[var(--political-red)] text-white px-6 py-5 rounded-2xl font-black text-lg shadow-2xl shadow-red-900/20"
              >
                JOIN THE MOVEMENT
                <ChevronRight className="w-6 h-6" />
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer className="bg-gray-900 dark:bg-black text-white relative overflow-hidden">
        {/* Decorative Top Border */}
        <div className="h-1 bg-gradient-to-r from-[var(--political-red)] via-white to-[var(--political-green)] relative">
        </div>

        <div className="container mx-auto px-4 py-12 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Party Info */}
            <div>
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 rounded-2xl overflow-hidden border border-white/20">
                  {leader?.image ? (
                    <img src={`/storage/${leader.image}`} alt={leader.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-white flex items-center justify-center text-[var(--political-red)] font-black">
                      {partyName.charAt(0)}
                    </div>
                  )}
                </div>
                <span className="text-2xl font-black tracking-tighter">{partyName}</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed max-w-xs uppercase tracking-widest font-black opacity-30">
                Working towards a prosperous and united nation.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4 text-[var(--political-red)]">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/biography" className="hover:text-white hover:pl-1 transition-all inline-block text-sm">About Leader</Link>
                </li>
                <li>
                  <Link href="/program/events" className="hover:text-white hover:pl-1 transition-all inline-block text-sm">Upcoming Events</Link>
                </li>
                <li>
                  <Link href="/updates/news" className="hover:text-white hover:pl-1 transition-all inline-block text-sm">Latest News</Link>
                </li>
                <li>
                  <Link href="/joinnow" className="hover:text-white hover:pl-1 transition-all inline-block text-sm">Join the Party</Link>
                </li>
              </ul>
            </div>

            {/* Social Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4 text-[var(--political-green-light)]">Connect With Us</h4>
              <div className="flex gap-4">
                {socialLinks && Object.entries(socialLinks).map(([platform, url]) => {
                  if (!url) return null;
                  const Icon = socialIcons[platform] || Globe;
                  return (
                    <a
                      key={platform}
                      href={url.startsWith('http') ? url : `https://${url}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full bg-gray-800 dark:bg-gray-900 flex items-center justify-center hover:bg-[var(--political-red)] transition-colors"
                    >
                      <Icon className="w-5 h-5" />
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 dark:border-gray-950 py-4 relative z-10">
          <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
            © {new Date().getFullYear()} {partyName}. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
