import { Head, Link } from '@inertiajs/react';
import PublicLayout from '@/layouts/public-layout';
import React, { useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, ChevronRight, BookOpen, User, ArrowRight, Star } from 'lucide-react';

interface Post {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  featured_image: string | null;
  published_at: string;
  user?: { name: string };
}

interface Leader {
  social_links: Record<string, string> | null;
}

interface Props {
  posts: {
    data: Post[];
    links: any;
    current_page: number;
    last_page: number;
  };
  leader: Leader | null;
}

export default function BlogIndex({ posts, leader }: Props) {
  useEffect(() => {
    const observerOptions = { threshold: 0.1 };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
        }
      });
    }, observerOptions);

    document.querySelectorAll('.fade-in-section').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, [posts.data]);

  return (
    <PublicLayout socialLinks={leader?.social_links ?? undefined}>
      <Head title="Insights & Perspectives - Blog">
        <meta name="description" content="Read our latest insights, policy discussions, and stories from the movement." />
      </Head>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden bg-white dark:bg-gray-950">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-[10%] left-[10%] w-[40%] h-[40%] bg-[var(--political-green)]/5 dark:bg-[var(--political-green)]/10 rounded-full blur-[100px] animate-float-slow" />
          <div className="absolute bottom-[10%] right-[10%] w-[35%] h-[35%] bg-[var(--political-red)]/5 dark:bg-[var(--political-red)]/10 rounded-full blur-[100px] animate-float-slow delay-1000" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="flex items-center gap-3 bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 px-4 py-2 rounded-2xl w-fit mx-auto animate-fade-in-up">
              <BookOpen className="w-4 h-4 text-[var(--political-green)]" />
              <span className="text-xs font-black uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">The Modern Journal</span>
            </div>

            <h1 className="text-5xl md:text-8xl font-black text-[var(--political-green)] tracking-tight">
              <span className="block overflow-hidden">
                <span className="block animate-reveal-text">
                  <span className="text-[var(--political-red)]">Voices of</span>
                </span>
              </span>
              <span className="block overflow-hidden italic">
                <span className="block animate-reveal-text delay-200">
                  The Movement
                </span>
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-400 dark:text-gray-500 max-w-2xl mx-auto leading-relaxed animate-fade-in-up delay-500">
              In-depth analysis, personal stories, and vision for the future. Directly from those leading the charge.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-20 bg-gray-50/50 dark:bg-gray-900/50">
        <div className="container mx-auto px-6">
          {posts.data.length > 0 ? (
            <div className="max-w-7xl mx-auto space-y-20">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
                {posts.data.map((post, i) => (
                  <div
                    key={post.id}
                    className="fade-in-section group"
                  >
                    <div className="relative aspect-[16/10] rounded-[2.5rem] overflow-hidden mb-8 shadow-sm group-hover:shadow-2xl transition-all duration-500">
                      {post.featured_image ? (
                        <img
                          src={`/storage/${post.featured_image}`}
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                        />
                      ) : (
                        <div className="w-full h-full bg-white dark:bg-gray-800 flex items-center justify-center">
                          <BookOpen className="w-12 h-12 text-gray-100 dark:text-gray-700" />
                        </div>
                      )}
                      <div className="absolute top-6 left-6">
                        <span className="px-4 py-2 bg-white/90 dark:bg-gray-900/90 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest text-[var(--political-red)] shadow-xl">
                          {new Date(post.published_at).toLocaleDateString('en-US', { day: '2-digit', month: 'short' })}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-4 px-2">
                      <div className="flex items-center gap-4 text-[10px] font-black uppercase tracking-widest text-gray-400 dark:text-gray-500">
                        {post.user && (
                          <div className="flex items-center gap-2">
                            <User className="w-3 h-3 text-[var(--political-red)]" />
                            {post.user.name}
                          </div>
                        )}
                        <span>•</span>
                        <span>Read Time: 5min</span>
                      </div>

                      <h3 className="text-2xl font-black text-[var(--political-green)] group-hover:text-[var(--political-green)] transition-colors leading-tight">
                        {post.title}
                      </h3>
                      {post.excerpt && (
                        <p className="text-gray-400 dark:text-gray-500 font-medium line-clamp-2 leading-relaxed">{post.excerpt}</p>
                      )}
                      <Link
                        href={`/updates/blog/${post.slug}`}
                        className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-[var(--political-red)] hover:gap-4 transition-all"
                      >
                        Dive Into Article
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {posts.last_page > 1 && (
                <div className="flex justify-center items-center gap-4 pt-10 border-t border-gray-100 dark:border-gray-800">
                  {Array.from({ length: posts.last_page }, (_, i) => i + 1).map((page) => (
                    <Link
                      key={page}
                      href={`/updates/blog?page=${page}`}
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold transition-all ${page === posts.current_page
                        ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-950 shadow-xl scale-110'
                        : 'bg-white dark:bg-gray-800 text-gray-400 dark:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-100 dark:border-gray-800'
                        }`}
                    >
                      {page}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="max-w-xl mx-auto text-center py-32 space-y-6 bg-white dark:bg-gray-900 rounded-[3rem] shadow-xl border border-gray-100 dark:border-gray-800 fade-in-section">
              <div className="w-24 h-24 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                <BookOpen className="w-10 h-10 text-gray-200 dark:text-gray-700" />
              </div>
              <h3 className="text-2xl font-black text-[var(--political-green)]">Journal Currently Empty</h3>
              <p className="text-gray-400 dark:text-gray-500 font-medium">New perspectives are being written. Visit us again soon!</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white dark:bg-gray-950">
        <div className="container mx-auto px-6">
          <div className="rounded-[4rem] bg-gray-900 dark:bg-black p-12 md:p-20 text-center space-y-8 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-[var(--political-green)]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
            <div className="relative z-10 max-w-2xl mx-auto space-y-6">
              <h2 className="text-4xl md:text-6xl font-black text-white tracking-tight leading-tight">Your Voice <span className="text-[var(--political-green-light)]">Matters</span>.</h2>
              <p className="text-xl text-white/50 font-medium">Subscribe to receive long-form articles and policy deep-dives directly in your inbox.</p>
              <div className="pt-6">
                <Link
                  href="/joinnow"
                  className="inline-flex items-center gap-3 bg-white text-gray-900 px-10 py-5 rounded-[2rem] font-black text-lg shadow-2xl hover:scale-[1.05] transition-all"
                >
                  STAY INFORMED
                  <ArrowRight className="w-6 h-6" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <style>{`
        .fade-in-section {
          opacity: 0;
          transform: translateY(30px);
          transition: all 1s cubic-bezier(0.2, 0.8, 0.2, 1);
        }
        .fade-in-section.is-visible {
          opacity: 1;
          transform: translateY(0);
        }
      `}</style>
    </PublicLayout>
  );
}
