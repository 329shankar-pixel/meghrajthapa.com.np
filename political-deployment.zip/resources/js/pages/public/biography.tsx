import { Head, Link } from '@inertiajs/react';
import PublicLayout from '@/layouts/public-layout';
import React, { useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, Phone, MapPin, Star, User, Heart, Zap, ArrowRight, Globe } from 'lucide-react';
import { FaFacebookF, FaInstagram, FaYoutube, FaXTwitter, FaWhatsapp, FaViber } from 'react-icons/fa6';
import { TbWorld } from 'react-icons/tb';
import InteractiveTimeline from '@/components/public/interactive-timeline';

interface Timeline {
  id: number;
  title: string;
  date: string;
  photo: string | null;
}

interface Leader {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  slug: string;
  image: string | null;
  bio: string | null;
  social_links: Record<string, string> | null;
}

interface Props {
  leader: Leader | null;
  timelines: Timeline[];
}

export default function Biography({ leader, timelines = [] }: Props) {
  useEffect(() => {
    const observerOptions = { threshold: 0.1 };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
        }
      });
    }, observerOptions);

    document.querySelectorAll('.fade-in-section').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <PublicLayout socialLinks={leader?.social_links ?? undefined}>
      <Head title={`${leader?.name || 'Leader'} - Biography`}>
        <meta name="description" content={`Learn about the journey and vision of ${leader?.name || 'our leader'}`} />
      </Head>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden bg-white dark:bg-gray-950">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-[10%] right-[10%] w-[40%] h-[40%] bg-[var(--political-red)]/5 dark:bg-[var(--political-red)]/10 rounded-full blur-[100px] animate-float-slow" />
          <div className="absolute bottom-[10%] left-[10%] w-[30%] h-[30%] bg-[var(--political-green)]/5 dark:bg-[var(--political-green)]/10 rounded-full blur-[100px] animate-float-slow delay-1000" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="flex items-center gap-3 bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 px-4 py-2 rounded-2xl w-fit mx-auto animate-fade-in-up">
              <User className="w-4 h-4 text-[var(--political-red)]" />
              <span className="text-xs font-black uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Service & Leadership</span>
            </div>

            <h1 className="text-5xl md:text-8xl font-black text-[var(--political-green)] tracking-tight">
              <span className="block overflow-hidden">
                <span className="block animate-reveal-text">The Life & Legacy</span>
              </span>
              <span className="block overflow-hidden italic">
                <span className="block animate-reveal-text delay-200 text-transparent bg-clip-text bg-gradient-to-r from-[var(--political-red)] to-[var(--political-red-dark)]">
                  {leader?.name || 'Our Leader'}
                </span>
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-400 dark:text-gray-500 max-w-2xl mx-auto leading-relaxed animate-fade-in-up delay-500">
              Tracing the roots of a leader dedicated to national progress and the well-being of every citizen.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-gray-50/50 dark:bg-gray-950">
        <div className="container mx-auto px-6">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">

              {/* Profile Card Sidebar */}
              <div className="lg:col-span-5 fade-in-section">
                <div className="sticky top-32 space-y-10">
                  <div className="relative group">
                    <div className="absolute -inset-4 bg-gradient-to-br from-[var(--political-red)] to-[var(--political-green)] rounded-[3rem] opacity-20 blur-2xl group-hover:opacity-40 transition-opacity duration-1000" />
                    <div className="relative rounded-[2.5rem] overflow-hidden border-[10px] border-white dark:border-gray-900 shadow-2xl bg-white dark:bg-gray-800">
                      {leader?.image ? (
                        <img
                          src={`/storage/${leader.image}`}
                          alt={leader.name}
                          className="w-full aspect-[4/5] object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-700"
                        />
                      ) : (
                        <div className="w-full aspect-[4/5] bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                          <User className="w-20 h-20 text-gray-200 dark:text-gray-700" />
                        </div>
                      )}
                    </div>

                    {/* Floating Accent */}
                    <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-white dark:bg-gray-900 rounded-[2rem] shadow-2xl flex items-center justify-center animate-bounce-slow border border-gray-100 dark:border-gray-800">
                      <Star className="w-10 h-10 text-[var(--political-red)] fill-current" />
                    </div>
                  </div>

                  <div className="space-y-6 px-4">
                    <div className="flex items-center gap-6 p-6 bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all">
                      <div className="w-12 h-12 bg-red-50 dark:bg-red-950/30 rounded-2xl flex items-center justify-center">
                        <Mail className="w-5 h-5 text-[var(--political-red)]" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Official Email</p>
                        <p className="font-bold text-[var(--political-green)]">{leader?.email || 'contact@leader.com'}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-6 p-6 bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all">
                      <div className="w-12 h-12 bg-green-50 dark:bg-green-950/30 rounded-2xl flex items-center justify-center">
                        <Phone className="w-5 h-5 text-[var(--political-green)]" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Direct Contact</p>
                        <p className="font-bold text-[var(--political-green)]">{leader?.phone || '+977 01-XXXXXX'}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-6 p-6 bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all">
                      <div className="w-12 h-12 bg-red-50 dark:bg-red-950/30 rounded-2xl flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-[var(--political-red)]" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Base of Operations</span>
                        <span className="font-bold text-[var(--political-green)]">Kathmandu, Nepal</span>
                      </div>
                    </div>

                    {leader?.social_links && Object.entries(leader.social_links).filter(([_, url]) => !!url).length > 0 && (
                      <div className="p-6 bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 hover:shadow-xl transition-all">
                        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-4 px-2">Social Connect</p>
                        <div className="flex flex-wrap gap-3">
                          {Object.entries(leader.social_links).map(([platform, url]) => {
                            if (!url) return null;

                            const icons: Record<string, any> = {
                              facebook: FaFacebookF,
                              twitter: FaXTwitter,
                              instagram: FaInstagram,
                              youtube: FaYoutube,
                              whatsapp: FaWhatsapp,
                              viber: FaViber,
                              website: TbWorld,
                            };

                            const Icon = icons[platform] || Globe;

                            return (
                              <a
                                key={platform}
                                href={url.startsWith('http') ? url : `https://${url}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="w-12 h-12 rounded-2xl bg-gray-50 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:bg-[var(--political-red)] hover:text-white hover:scale-110 active:scale-95 transition-all duration-300 shadow-sm"
                                title={platform.charAt(0).toUpperCase() + platform.slice(1)}
                              >
                                <Icon className="w-5 h-5" />
                              </a>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Bio Content */}
              <div className="lg:col-span-7 space-y-12">
                <div className="fade-in-section">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="h-[2px] w-12 bg-[var(--political-red)]" />
                    <span className="text-sm font-black uppercase tracking-[0.4em] text-[var(--political-red)]">Biography</span>
                  </div>

                  <div
                    className="prose prose-2xl prose-gray dark:prose-invert max-w-none 
                    prose-headings:font-black prose-headings:tracking-tight prose-headings:text-[var(--political-green)]
                    prose-p:text-gray-500 dark:prose-p:text-gray-400 prose-p:leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: leader?.bio || '' }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-32 bg-white dark:bg-gray-950">
        <div className="container mx-auto px-6">
          <div className="text-center mb-24 fade-in-section">
            <span className="text-[var(--political-red)] font-black uppercase tracking-[0.3em] text-xs">The Journey</span>
            <h2 className="text-5xl md:text-7xl font-black text-[var(--political-green)] tracking-tight mt-4">
              <span className="text-[var(--political-red)]">Legacy of</span>{' '}
              <span className="text-[var(--political-green)]">Service</span>
            </h2>
            <p className="text-xl text-gray-400 dark:text-gray-500 mt-6 max-w-2xl mx-auto italic">A chronological history of leadership, milestones, and dedicated service to the nation.</p>
          </div>

          <InteractiveTimeline items={timelines} />
        </div>
      </section>

      <style>{`
        .animate-reveal-text {
          animation: revealText 1.5s cubic-bezier(0.77, 0, 0.175, 1) forwards;
        }
        @keyframes revealText {
          0% { transform: translateY(100%); }
          100% { transform: translateY(0); }
        }
        .animate-float-slow {
          animation: float 20s ease-in-out infinite;
        }
        @keyframes float {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(5%, 5%); }
        }
        .fade-in-section {
          opacity: 0;
          transform: translateY(30px);
          transition: all 1s cubic-bezier(0.2, 0.8, 0.2, 1);
        }
        .fade-in-section.is-visible {
          opacity: 1;
          transform: translateY(0);
        }
      `}</style>
    </PublicLayout>
  );
}
