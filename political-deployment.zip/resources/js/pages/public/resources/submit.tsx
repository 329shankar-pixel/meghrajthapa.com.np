import { Head, Link, useForm, usePage } from '@inertiajs/react';
import { useState, useEffect } from 'react';
import PublicLayout from '@/layouts/public-layout';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Image as ImageIcon,
  X,
  MapPin,
  Building2,
  Phone,
  Mail,
  User,
  Check,
  Loader2,
  ChevronLeft,
  ArrowRight,
  Share2,
  Link as LinkIcon
} from 'lucide-react';
import { FaFacebookF, FaXTwitter, FaWhatsapp, FaViber } from 'react-icons/fa6';
import { Card, CardContent } from '@/components/ui/card';

interface Province {
  id: number;
  name: string;
}

interface District {
  id: number;
  name: string;
}

interface Municipality {
  id: number;
  name: string;
}

interface Props {
  provinces: Province[];
  leader?: any;
}

export default function SubmitResource({ provinces, leader }: Props) {
  const { flash } = usePage<any>().props;
  const [selectedProvince, setSelectedProvince] = useState<string>('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [selectedMunicipality, setSelectedMunicipality] = useState<string>('');
  const [districts, setDistricts] = useState<District[]>([]);
  const [municipalities, setMunicipalities] = useState<Municipality[]>([]);
  const [loadingDistricts, setLoadingDistricts] = useState(false);
  const [loadingMunicipalities, setLoadingMunicipalities] = useState(false);
  const [previews, setPreviews] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = (platform: string) => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent("Submit a Community Project - " + partyName);
    let shareUrl = '';

    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
        break;
      case 'twitter':
        shareUrl = `https://x.com/intent/tweet?url=${url}&text=${text}`;
        break;
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${text}%20${url}`;
        break;
      case 'viber':
        shareUrl = `viber://forward?text=${text}%20${url}`;
        break;
    }

    if (shareUrl) {
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
  };

  const partyName = usePage<any>().props.name || 'राजनीतिक दल';

  const { data, setData, post, processing, errors, reset } = useForm({
    title: '',
    description: '',
    province_id: '',
    district_id: '',
    municipality_id: '',
    ward_number: '',
    tole: '',
    person_name: '',
    person_email: '',
    person_phone: '',
    photos: [] as File[],
  });

  // Fetch districts when province changes
  useEffect(() => {
    if (selectedProvince) {
      setLoadingDistricts(true);
      setDistricts([]);
      setSelectedDistrict('');
      setMunicipalities([]);
      setSelectedMunicipality('');
      setData('province_id', selectedProvince);

      fetch(`/api/provinces/${selectedProvince}/districts`)
        .then(res => res.json())
        .then(data => {
          setDistricts(data);
          setLoadingDistricts(false);
        })
        .catch(() => setLoadingDistricts(false));
    }
  }, [selectedProvince]);

  // Fetch municipalities when district changes
  useEffect(() => {
    if (selectedDistrict) {
      setLoadingMunicipalities(true);
      setMunicipalities([]);
      setSelectedMunicipality('');
      setData('district_id', selectedDistrict);

      fetch(`/api/districts/${selectedDistrict}/municipalities`)
        .then(res => res.json())
        .then(data => {
          setMunicipalities(data);
          setLoadingMunicipalities(false);
        })
        .catch(() => setLoadingMunicipalities(false));
    }
  }, [selectedDistrict]);

  useEffect(() => {
    if (selectedMunicipality) {
      setData('municipality_id', selectedMunicipality);
    }
  }, [selectedMunicipality]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const filesArray = Array.from(files);
      setData('photos', [...data.photos, ...filesArray]);

      const newPreviews = filesArray.map(file => URL.createObjectURL(file));
      setPreviews([...previews, ...newPreviews]);
    }
  };

  const removePhoto = (index: number) => {
    const newPhotos = [...data.photos];
    newPhotos.splice(index, 1);
    setData('photos', newPhotos);

    const newPreviews = [...previews];
    URL.revokeObjectURL(newPreviews[index]);
    newPreviews.splice(index, 1);
    setPreviews(newPreviews);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    post('/community/resources/submit', {
      onSuccess: () => {
        reset();
        setPreviews([]);
        setSelectedProvince('');
        setSelectedDistrict('');
        setSelectedMunicipality('');
      },
      forceFormData: true,
    });
  };

  return (
    <PublicLayout socialLinks={leader?.social_links ?? undefined}>
      <Head title="Submit Community Project - Empowerment Through Local Action" />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden bg-white dark:bg-gray-950">
        <div className="absolute inset-0 z-0 text-center">
          <div className="absolute top-[10%] right-[10%] w-[40%] h-[40%] bg-[var(--political-red)]/5 dark:bg-[var(--political-red)]/10 rounded-full blur-[100px] animate-float-slow" />
          <div className="absolute bottom-[10%] left-[10%] w-[35%] h-[35%] bg-[var(--political-green)]/5 dark:bg-[var(--political-green)]/10 rounded-full blur-[100px] animate-float-slow delay-1000" />
        </div>

        <div className="container mx-auto px-6 relative z-10 text-center space-y-8">
          <div className="flex items-center gap-3 bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 px-4 py-2 rounded-2xl w-fit mx-auto animate-fade-in-up">
            <Building2 className="w-4 h-4 text-[var(--political-red)]" />
            <span className="text-xs font-black uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Community Empowerment</span>
          </div>

          <h1 className="text-4xl md:text-7xl font-black text-[var(--political-green)] tracking-tight leading-tight">
            Tell Us About Your <span className="text-[var(--political-red)] italic">Community Project</span>
          </h1>

          <p className="text-xl text-gray-400 dark:text-gray-500 max-w-2xl mx-auto leading-relaxed">
            Have a local project or resource that needs attention? Share the details with us so we can document and support local initiatives.
          </p>

          <div className="flex items-center justify-center gap-4 pt-4 animate-fade-in-up delay-700">
            <span className="text-xs font-black uppercase text-gray-400 tracking-widest mr-2">Share Page:</span>
            <button onClick={() => handleShare('facebook')} className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 flex items-center justify-center text-gray-500 hover:bg-[#1877F2] hover:text-white hover:border-[#1877F2] transition-all shadow-sm">
              <FaFacebookF className="w-4 h-4" />
            </button>
            <button onClick={() => handleShare('twitter')} className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 flex items-center justify-center text-gray-500 hover:bg-black hover:text-white hover:border-black transition-all shadow-sm">
              <FaXTwitter className="w-4 h-4" />
            </button>
            <button onClick={() => handleShare('whatsapp')} className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 flex items-center justify-center text-gray-500 hover:bg-[#25D366] hover:text-white hover:border-[#25D366] transition-all shadow-sm">
              <FaWhatsapp className="w-4 h-4" />
            </button>
            <button onClick={() => handleShare('viber')} className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 flex items-center justify-center text-gray-500 hover:bg-[#7360F2] hover:text-white hover:border-[#7360F2] transition-all shadow-sm">
              <FaViber className="w-4 h-4" />
            </button>
            <button onClick={handleCopyLink} className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 flex items-center justify-center text-gray-500 hover:bg-gray-900 hover:text-white dark:hover:bg-white dark:hover:text-black transition-all shadow-sm relative">
              <LinkIcon className="w-4 h-4" />
              {copied && <span className="absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-black text-white text-[10px] rounded whitespace-nowrap">Copied!</span>}
            </button>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-gray-50/50 dark:bg-gray-900/50">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            {flash?.success ? (
              <Card className="rounded-[3rem] border-0 shadow-2xl overflow-hidden bg-white dark:bg-gray-900 p-20 text-center">
                <div className="w-24 h-24 bg-green-50 dark:bg-green-950/30 rounded-full flex items-center justify-center mx-auto mb-8">
                  <Check className="w-12 h-12 text-[var(--political-green)]" />
                </div>
                <h3 className="text-4xl font-black text-[var(--political-green)] mb-4 tracking-tight">Submission Received!</h3>
                <p className="text-gray-400 dark:text-gray-500 font-medium text-lg leading-relaxed max-w-md mx-auto">
                  {flash.success}
                </p>
                <div className="pt-10 flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    onClick={() => window.location.reload()}
                    className="rounded-2xl px-10 py-6 bg-[var(--political-red)] text-white font-black text-sm uppercase tracking-widest hover:scale-[1.05] transition-all"
                  >
                    SUBMIT ANOTHER
                  </Button>
                  <Link
                    href="/"
                    className="rounded-2xl px-10 py-6 bg-white dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 text-[var(--political-green)] font-black text-sm uppercase tracking-widest hover:bg-gray-50 dark:hover:bg-gray-700 transition-all"
                  >
                    BACK TO HOME
                  </Link>
                </div>
              </Card>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-12">
                {/* General Info */}
                <div className="bg-white dark:bg-gray-900 rounded-[3rem] p-10 md:p-16 shadow-lg border border-gray-100 dark:border-gray-800 space-y-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[var(--political-red)]/10 flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-[var(--political-red)]" />
                    </div>
                    <h2 className="text-2xl font-black text-[var(--political-green)] tracking-tight">Project Overview</h2>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Project Title *</Label>
                      <Input
                        value={data.title}
                        onChange={e => setData('title', e.target.value)}
                        placeholder="e.g. Drinking Water Improvement, School Renovation"
                        className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 focus:bg-white dark:focus:bg-gray-700 focus:ring-[var(--political-red)] transition-all font-bold text-[var(--political-green)] text-lg"
                        required
                      />
                      {errors.title && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.title}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Detailed Description *</Label>
                      <Textarea
                        value={data.description}
                        onChange={e => setData('description', e.target.value)}
                        placeholder="Describe the project, its current status, goals, and who it benefits..."
                        className="rounded-3xl min-h-[200px] px-8 py-6 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 focus:bg-white dark:focus:bg-gray-700 focus:ring-[var(--political-red)] transition-all font-medium text-[var(--political-green)] text-lg"
                        required
                      />
                      {errors.description && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.description}</p>}
                    </div>
                  </div>
                </div>

                {/* Location */}
                <div className="bg-white dark:bg-gray-900 rounded-[3rem] p-10 md:p-16 shadow-lg border border-gray-100 dark:border-gray-800 space-y-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[var(--political-green)]/10 flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-[var(--political-green)]" />
                    </div>
                    <h2 className="text-2xl font-black text-[var(--political-green)] tracking-tight">Location Details</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Province *</Label>
                      <Select value={selectedProvince} onValueChange={setSelectedProvince} required>
                        <SelectTrigger className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 font-bold dark:text-white">
                          <SelectValue placeholder="Select Province" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                          {provinces.map((p) => (
                            <SelectItem key={p.id} value={p.id.toString()} className="dark:text-white">{p.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.province_id && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.province_id}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">District *</Label>
                      <Select value={selectedDistrict} onValueChange={setSelectedDistrict} disabled={!selectedProvince || loadingDistricts} required>
                        <SelectTrigger className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 font-bold dark:text-white">
                          <SelectValue placeholder={loadingDistricts ? "Loading..." : "Select District"} />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                          {districts.map((d) => (
                            <SelectItem key={d.id} value={d.id.toString()} className="dark:text-white">{d.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.district_id && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.district_id}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Municipality *</Label>
                      <Select value={selectedMunicipality} onValueChange={setSelectedMunicipality} disabled={!selectedDistrict || loadingMunicipalities} required>
                        <SelectTrigger className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 font-bold dark:text-white">
                          <SelectValue placeholder={loadingMunicipalities ? "Loading..." : "Select Municipality"} />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                          {municipalities.map((m) => (
                            <SelectItem key={m.id} value={m.id.toString()} className="dark:text-white">{m.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.municipality_id && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.municipality_id}</p>}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Ward *</Label>
                        <Input
                          type="number"
                          value={data.ward_number}
                          onChange={e => setData('ward_number', e.target.value)}
                          placeholder="Ward"
                          className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 focus:bg-white dark:focus:bg-gray-700 focus:ring-[var(--political-red)] transition-all font-bold text-[var(--political-green)]"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Tole</Label>
                        <Input
                          value={data.tole}
                          onChange={e => setData('tole', e.target.value)}
                          placeholder="Location"
                          className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 focus:bg-white dark:focus:bg-gray-700 focus:ring-[var(--political-red)] transition-all font-bold text-[var(--political-green)]"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Photos */}
                <div className="bg-white dark:bg-gray-900 rounded-[3rem] p-10 md:p-16 shadow-lg border border-gray-100 dark:border-gray-800 space-y-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[var(--political-red)]/10 flex items-center justify-center">
                      <ImageIcon className="w-6 h-6 text-[var(--political-red)]" />
                    </div>
                    <h2 className="text-2xl font-black text-[var(--political-green)] tracking-tight">Project Visuals</h2>
                  </div>

                  <div className="space-y-8">
                    <label htmlFor="photos" className="block w-full border-2 border-dashed border-gray-200 dark:border-gray-800 rounded-[2.5rem] p-12 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all group">
                      <div className="w-20 h-20 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                        <ImageIcon className="w-8 h-8 text-gray-400" />
                      </div>
                      <h4 className="text-xl font-bold text-[var(--political-green)] mb-2">Upload Project Photos</h4>
                      <p className="text-gray-400 dark:text-gray-500 font-medium tracking-tight">You can select multiple photos illustrating the project status.</p>
                      <input
                        id="photos"
                        type="file"
                        multiple
                        className="hidden"
                        onChange={handleFileChange}
                        accept="image/*"
                      />
                    </label>

                    {previews.length > 0 && (
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-4">
                        {previews.map((src, i) => (
                          <div key={i} className="relative aspect-square rounded-2xl overflow-hidden border border-gray-100 dark:border-gray-800 group shadow-lg">
                            <img src={src} alt="" className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={() => removePhoto(i)}
                              className="absolute top-2 right-2 w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    {errors.photos && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.photos}</p>}
                  </div>
                </div>

                {/* Contact Information */}
                <div className="bg-white dark:bg-gray-900 rounded-[3rem] p-10 md:p-16 shadow-lg border border-gray-100 dark:border-gray-800 space-y-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[var(--political-green)]/10 flex items-center justify-center">
                      <User className="w-6 h-6 text-[var(--political-green)]" />
                    </div>
                    <h2 className="text-2xl font-black text-[var(--political-green)] tracking-tight">Contact Person</h2>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Full Name *</Label>
                      <Input
                        value={data.person_name}
                        onChange={e => setData('person_name', e.target.value)}
                        placeholder="Your Full Name"
                        className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 focus:bg-white dark:focus:bg-gray-700 focus:ring-[var(--political-red)] transition-all font-bold text-[var(--political-green)]"
                        required
                      />
                      {errors.person_name && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.person_name}</p>}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Email Address *</Label>
                        <Input
                          type="email"
                          value={data.person_email}
                          onChange={e => setData('person_email', e.target.value)}
                          placeholder="your.email@example.com"
                          className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 focus:bg-white dark:focus:bg-gray-700 focus:ring-[var(--political-red)] transition-all font-bold text-[var(--political-green)]"
                          required
                        />
                        {errors.person_email && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.person_email}</p>}
                      </div>

                      <div className="space-y-2">
                        <Label className="text-[10px] font-black uppercase text-gray-400 dark:text-gray-500 tracking-widest ml-4">Phone Number *</Label>
                        <Input
                          value={data.person_phone}
                          onChange={e => setData('person_phone', e.target.value)}
                          placeholder="98XXXXXXXX"
                          className="rounded-2xl h-16 px-8 bg-gray-50 dark:bg-gray-800 border-transparent dark:border-gray-700 focus:bg-white dark:focus:bg-gray-700 focus:ring-[var(--political-red)] transition-all font-bold text-[var(--political-green)]"
                          required
                        />
                        {errors.person_phone && <p className="text-[var(--political-red)] text-[10px] font-bold ml-4">{errors.person_phone}</p>}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-8">
                  <button
                    type="submit"
                    disabled={processing}
                    className="w-full py-8 bg-gradient-to-r from-[var(--political-red)] to-[var(--political-red-dark)] text-white rounded-[2rem] font-black text-xl shadow-2xl shadow-red-900/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-6 disabled:opacity-50 group/btn"
                  >
                    {processing ? <Loader2 className="w-10 h-10 animate-spin" /> : (
                      <>
                        SUBMIT COMMUNITY PROJECT
                        <ArrowRight className="w-8 h-8 group-hover/btn:translate-x-2 transition-transform" />
                      </>
                    )}
                  </button>
                  <p className="mt-8 text-[11px] font-bold text-gray-400 dark:text-gray-500 text-center uppercase tracking-[0.2em] leading-loose">
                    By submitting, you agree to public documentation of this project<br />for community awareness and support.
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>

      <style>{`
        .animate-reveal-text {
          animation: reveal 1s cubic-bezier(0.77, 0, 0.175, 1);
        }
        @keyframes reveal {
          0% { transform: translateY(100%); }
          100% { transform: translateY(0); }
        }
        .animate-fade-in-up {
          animation: fadeInUp 1s cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
        }
        @keyframes fadeInUp {
          0% { opacity: 0; transform: translateY(30px); }
          100% { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </PublicLayout>
  );
}
