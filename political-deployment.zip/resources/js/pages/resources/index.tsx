import { Head, Link, router, usePage } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  index,
  create,
  show,
  edit,
  destroy
} from '@/actions/App/Http/Controllers/ResourceController';
import { Plus, Eye, Trash2, Filter, X, MapPin, Users, Edit2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import SpotlightCard from '@/components/SpotlightCard';

interface ResourcePhoto {
  id: number;
  photo_path: string;
}

interface Resource {
  id: number;
  title: string;
  description: string;
  province_id: number;
  district_id: number;
  municipality_id: number;
  ward_number: number;
  province_name: string;
  district_name: string;
  municipality_name: string;
  person_name: string;
  person_email: string;
  person_phone: string;
  photos: ResourcePhoto[];
  created_at: string;
}

interface PaginatedData {
  data: Resource[];
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
  links: Array<{
    url: string | null;
    label: string;
    active: boolean;
  }>;
}

interface Province {
  id: number;
  name: string;
}

interface District {
  id: number;
  name: string;
}

interface Municipality {
  id: number;
  name: string;
}

interface Stats {
  total: number;
  by_province: Array<{
    name: string;
    count: number;
  }>;
}

interface Props {
  resources: PaginatedData;
  filters: {
    province_id?: string;
    district_id?: string;
    municipality_id?: string;
    ward_number?: string;
  };
  stats: Stats;
  provinces: Province[];
}

const breadcrumbs: BreadcrumbItem[] = [
  { title: 'Dashboard', href: '/dashboard' },
  { title: 'Resources', href: '/resources' },
];

export default function Index({ resources, filters: initialFilters, stats, provinces }: Props) {
  const [filters, setFilters] = useState(initialFilters);
  const [districts, setDistricts] = useState<District[]>([]);
  const [municipalities, setMunicipalities] = useState<Municipality[]>([]);
  const [loadingDistricts, setLoadingDistricts] = useState(false);
  const [loadingMunicipalities, setLoadingMunicipalities] = useState(false);

  useEffect(() => {
    if (filters.province_id) {
      setLoadingDistricts(true);
      fetch(`/api/provinces/${filters.province_id}/districts`)
        .then(res => res.json())
        .then(data => {
          setDistricts(data);
          setLoadingDistricts(false);
        })
        .catch(() => setLoadingDistricts(false));
    } else {
      setDistricts([]);
    }
  }, [filters.province_id]);

  useEffect(() => {
    if (filters.district_id) {
      setLoadingMunicipalities(true);
      fetch(`/api/districts/${filters.district_id}/municipalities`)
        .then(res => res.json())
        .then(data => {
          setMunicipalities(data);
          setLoadingMunicipalities(false);
        })
        .catch(() => setLoadingMunicipalities(false));
    } else {
      setMunicipalities([]);
    }
  }, [filters.district_id]);

  const handleFilterChange = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value };
    if (key === 'province_id') {
      newFilters.district_id = 'all';
      newFilters.municipality_id = 'all';
    }
    if (key === 'district_id') {
      newFilters.municipality_id = 'all';
    }
    setFilters(newFilters);
  };

  const applyFilters = () => {
    const cleanedFilters = { ...filters };
    Object.keys(cleanedFilters).forEach(key => {
      if (cleanedFilters[key as keyof typeof cleanedFilters] === 'all') {
        cleanedFilters[key as keyof typeof cleanedFilters] = '';
      }
    });
    router.get(index().url, cleanedFilters, { preserveState: true });
  };

  const resetFilters = () => {
    setFilters({});
    router.get(index().url, {}, { preserveState: true });
  };

  const handleDelete = (id: number, title: string) => {
    if (confirm(`Are you sure you want to delete ${title}?`)) {
      router.delete(destroy.url(id));
    }
  };

  return (
    <AppLayout breadcrumbs={breadcrumbs}>
      <Head title="Resources" />

      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Resources</h1>
            <p className="text-muted-foreground mt-1">
              Manage local resources and assets ({resources.total} total)
            </p>
          </div>
          <Link href={create().url}>
            <Button size="lg" className="rounded-full px-6">
              <Plus className="mr-2 h-5 w-5" />
              Add Resource
            </Button>
          </Link>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <SpotlightCard className="p-6 flex items-center gap-4 bg-card border rounded-2xl">
            <div className="p-3 bg-primary/10 rounded-xl">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Resources</p>
              <h3 className="text-2xl font-bold">{stats.total}</h3>
            </div>
          </SpotlightCard>

          {stats.by_province.slice(0, 3).map((province, idx) => (
            <SpotlightCard key={idx} className="p-6 flex items-center gap-4 bg-card border rounded-2xl">
              <div className="p-3 bg-secondary/10 rounded-xl">
                <MapPin className="h-6 w-6 text-secondary-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{province.name}</p>
                <h3 className="text-2xl font-bold">{province.count}</h3>
              </div>
            </SpotlightCard>
          ))}
        </div>

        {/* Filters */}
        <div className="rounded-2xl border bg-card/50 backdrop-blur-sm p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Filters</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
            <div className="space-y-2">
              <label className="text-xs font-medium ml-1">Province</label>
              <Select value={filters.province_id || 'all'} onValueChange={(v) => handleFilterChange('province_id', v)}>
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="All Provinces" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Provinces</SelectItem>
                  {provinces.map((p) => (
                    <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium ml-1">District</label>
              <Select
                value={filters.district_id || 'all'}
                onValueChange={(v) => handleFilterChange('district_id', v)}
                disabled={!filters.province_id || filters.province_id === 'all' || loadingDistricts}
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder={loadingDistricts ? "Loading..." : "All Districts"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Districts</SelectItem>
                  {districts.map((d) => (
                    <SelectItem key={d.id} value={d.id.toString()}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium ml-1">Municipality</label>
              <Select
                value={filters.municipality_id || 'all'}
                onValueChange={(v) => handleFilterChange('municipality_id', v)}
                disabled={!filters.district_id || filters.district_id === 'all' || loadingMunicipalities}
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder={loadingMunicipalities ? "Loading..." : "All Municipalities"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Municipalities</SelectItem>
                  {municipalities.map((m) => (
                    <SelectItem key={m.id} value={m.id.toString()}>{m.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium ml-1">Ward</label>
              <Input
                type="number"
                placeholder="Ward No."
                value={filters.ward_number || ''}
                onChange={(e) => handleFilterChange('ward_number', e.target.value)}
                className="bg-background"
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={applyFilters} className="flex-1">Apply</Button>
              <Button onClick={resetFilters} variant="outline" size="icon" className="shrink-0">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Resources Table */}
        {resources.data.length === 0 ? (
          <div className="rounded-3xl border border-dashed p-20 text-center bg-muted/20">
            <div className="inline-flex items-center justify-center p-4 bg-muted rounded-full mb-4">
              <Plus className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold mb-2">No resources found</h2>
            <p className="text-muted-foreground mb-6 max-w-sm mx-auto">Try adjusting your filters or add a new resource to get started.</p>
            <Link href={create().url}>
              <Button variant="outline">
                <Plus className="mr-2 h-4 w-4" />
                Add First Resource
              </Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="rounded-2xl border bg-card overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/40 border-b">
                    <tr>
                      <th className="text-left p-5 font-semibold">Resource Title</th>
                      <th className="text-left p-5 font-semibold">Location</th>
                      <th className="text-left p-5 font-semibold">Contact Person</th>
                      <th className="text-left p-5 font-semibold">Photos</th>
                      <th className="text-right p-5 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {resources.data.map((resource) => (
                      <tr key={resource.id} className="hover:bg-muted/30 transition-colors group">
                        <td className="p-5">
                          <div className="font-semibold text-base">{resource.title}</div>
                          <p className="text-muted-foreground text-xs line-clamp-1 mt-0.5">{resource.description}</p>
                        </td>
                        <td className="p-5 text-muted-foreground">
                          <div className="flex flex-col gap-0.5">
                            <span className="text-foreground font-medium">{resource.municipality_name}, Ward {resource.ward_number}</span>
                            <span className="text-xs">{resource.district_name}, {resource.province_name}</span>
                          </div>
                        </td>
                        <td className="p-5">
                          <div className="font-medium">{resource.person_name}</div>
                          <div className="text-xs text-muted-foreground font-mono">{resource.person_phone}</div>
                        </td>
                        <td className="p-5">
                          <div className="flex -space-x-2">
                            {resource.photos.slice(0, 3).map((photo, i) => (
                              <div key={i} className="h-8 w-8 rounded-full border-2 border-card overflow-hidden bg-muted">
                                <img src={`/storage/${photo.photo_path}`} alt="" className="h-full w-full object-cover" />
                              </div>
                            ))}
                            {resource.photos.length > 3 && (
                              <div className="h-8 w-8 rounded-full border-2 border-card bg-muted flex items-center justify-center text-[10px] font-bold">
                                +{resource.photos.length - 3}
                              </div>
                            )}
                            {resource.photos.length === 0 && <span className="text-muted-foreground italic text-xs">No photos</span>}
                          </div>
                        </td>
                        <td className="p-5 text-right">
                          <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Link href={show.url(resource.id)}>
                              <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Link href={edit.url(resource.id)}>
                              <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full">
                                <Edit2 className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8 rounded-full text-destructive hover:text-destructive hover:bg-destructive/10"
                              onClick={() => handleDelete(resource.id, resource.title)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Pagination */}
            {resources.last_page > 1 && (
              <div className="flex items-center justify-center gap-2 mt-8">
                {resources.links.map((link, index) => (
                  <Link
                    key={index}
                    href={link.url || '#'}
                    className={`px-4 py-2 rounded-xl text-sm transition-all ${link.active
                      ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20 scale-105 font-bold'
                      : link.url
                        ? 'bg-card border hover:border-primary/50 hover:bg-primary/5'
                        : 'opacity-40 cursor-not-allowed bg-muted'
                      }`}
                    dangerouslySetInnerHTML={{ __html: link.label }}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
}
