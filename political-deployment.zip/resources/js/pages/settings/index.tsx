import { Head, useForm } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { FormEventHandler } from 'react';
import { Loader2, Settings, Layout, Type } from 'lucide-react';
import InputError from '@/components/input-error';
import { update } from '@/actions/App/Http/Controllers/Settings/SiteSettingController';

interface Props {
  settings: Record<string, string>;
}

export default function SiteSettings({ settings }: Props) {
  const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Dashboard', href: '/dashboard' },
    { title: 'Settings', href: '#' },
    { title: 'Site Configuration', href: '#' },
  ];

  const { data, setData, post, processing, errors } = useForm({
    party_name: settings.party_name || '',
    hero_title: settings.hero_title || '',
    hero_subtitle: settings.hero_subtitle || '',
    hero_description: settings.hero_description || '',
    hero_image: null as File | null,
    unity_title: settings.unity_title || '',
    unity_subtitle: settings.unity_subtitle || '',
    unity_description: settings.unity_description || '',
    unity_image: null as File | null,
    experience_years: settings.experience_years || '25',
    experience_label_1: settings.experience_label_1 || 'Years Active',
    experience_years_2: settings.experience_years_2 || '100',
    experience_label_2: settings.experience_label_2 || 'Policy Impacts',
    marquee_keywords: settings.marquee_keywords || 'Prosperity, Unity, Progress',
    cta_title: settings.cta_title || 'Be the Change You Want to See.',
    cta_description: settings.cta_description || 'Our strength comes from the people. Sign up today to volunteer, donate, or simply stay updated with our progress.',
    unity_label: settings.unity_label || 'Unity',
    unity_quote: settings.unity_quote || 'Unity is our greatest strength.',
    legacy_number: settings.legacy_number || '25',
    legacy_label: settings.legacy_label || 'Years of Leadership',
    news_label: settings.news_label || 'Stay Informed',
    news_title: settings.news_title || 'Latest Movement',
    marquee_name: settings.marquee_name || '',
    site_tagline: settings.site_tagline || 'Movement for Progress',
    favicon: null as File | null,
    site_logo: null as File | null,
    party_flag: null as File | null,
    election_symbol: null as File | null,
  });

  const submit: FormEventHandler = (e) => {
    e.preventDefault();
    post(update.url(), {
      forceFormData: true,
    });
  };

  return (
    <AppLayout breadcrumbs={breadcrumbs}>
      <Head title="Site Settings" />

      <div className="mx-auto max-w-4xl p-6">
        <div className="mb-8 items-start justify-between flex flex-col md:flex-row gap-4">
          <div className="space-y-1">
            <h1 className="text-3xl font-black text-foreground tracking-tight flex items-center gap-3">
              <Settings className="w-8 h-8 text-primary" />
              Homepage & Branding
            </h1>
            <p className="text-muted-foreground">
              Manage global branding and all homepage sections dynamically.
            </p>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-10">
          {/* General Branding */}
          <div className="space-y-6 rounded-[2.5rem] border bg-card p-10 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-[4rem]" />

            <div className="flex items-center gap-3 mb-6 relative z-10">
              <Layout className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">General Branding</h2>
            </div>

            <div className="grid gap-6 relative z-10">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="grid w-full gap-2">
                  <Label htmlFor="party_name" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Party / Movement Name</Label>
                  <Input
                    id="party_name"
                    value={data.party_name}
                    onChange={(e) => setData('party_name', e.target.value)}
                    placeholder="Enter Party Name"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.party_name} />
                </div>

                <div className="grid w-full gap-2">
                  <Label htmlFor="site_tagline" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Site Tagline / Slogan</Label>
                  <Input
                    id="site_tagline"
                    value={data.site_tagline}
                    onChange={(e) => setData('site_tagline', e.target.value)}
                    placeholder="e.g., Movement for Progress"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.site_tagline} />
                </div>

                <div className="grid w-full gap-2">
                  <Label htmlFor="marquee_name" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Marquee Display Name (Optional)</Label>
                  <Input
                    id="marquee_name"
                    value={data.marquee_name}
                    onChange={(e) => setData('marquee_name', e.target.value)}
                    placeholder="e.g., Lee Adams"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.marquee_name} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="grid w-full gap-2">
                  <Label htmlFor="favicon" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Site Favicon (Tab Icon)</Label>
                  <Input
                    id="favicon"
                    type="file"
                    onChange={(e) => setData('favicon', e.target.files?.[0] || null)}
                    className="h-12 rounded-xl pt-2"
                  />
                  {settings.favicon && (
                    <p className="text-[10px] text-muted-foreground mt-1 ml-1">Current: {settings.favicon}</p>
                  )}
                  <InputError message={errors.favicon} />
                </div>

                <div className="grid w-full gap-2">
                  <Label htmlFor="site_logo" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Administration Logo</Label>
                  <Input
                    id="site_logo"
                    type="file"
                    onChange={(e) => setData('site_logo', e.target.files?.[0] || null)}
                    className="h-12 rounded-xl pt-2"
                  />
                  {settings.site_logo && (
                    <p className="text-[10px] text-muted-foreground mt-1 ml-1">Current: {settings.site_logo}</p>
                  )}
                  <InputError message={errors.site_logo} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="grid w-full gap-2">
                  <Label htmlFor="party_flag" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Party Flag</Label>
                  <Input
                    id="party_flag"
                    type="file"
                    onChange={(e) => setData('party_flag', e.target.files?.[0] || null)}
                    className="h-12 rounded-xl pt-2"
                  />
                  {settings.party_flag && (
                    <p className="text-[10px] text-muted-foreground mt-1 ml-1">Current: {settings.party_flag}</p>
                  )}
                  <InputError message={errors.party_flag} />
                </div>

                <div className="grid w-full gap-2">
                  <Label htmlFor="election_symbol" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Election Symbol</Label>
                  <Input
                    id="election_symbol"
                    type="file"
                    onChange={(e) => setData('election_symbol', e.target.files?.[0] || null)}
                    className="h-12 rounded-xl pt-2"
                  />
                  {settings.election_symbol && (
                    <p className="text-[10px] text-muted-foreground mt-1 ml-1">Current: {settings.election_symbol}</p>
                  )}
                  <InputError message={errors.election_symbol} />
                </div>
              </div>

              <div className="grid w-full gap-2">
                <Label htmlFor="marquee_keywords" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Marquee Keywords (Comma separated)</Label>
                <Input
                  id="marquee_keywords"
                  value={data.marquee_keywords}
                  onChange={(e) => setData('marquee_keywords', e.target.value)}
                  placeholder="e.g., Prosperity, Unity, Progress"
                  className="h-12 rounded-xl"
                />
                <InputError message={errors.marquee_keywords} />
              </div>
            </div>
          </div>

          {/* Hero Section */}
          <div className="space-y-6 rounded-[2.5rem] border bg-card p-10 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-[4rem]" />

            <div className="flex items-center gap-3 mb-6 relative z-10">
              <Type className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">Homepage Hero Content</h2>
            </div>

            <div className="grid gap-8 relative z-10">
              <div className="grid w-full gap-2">
                <Label htmlFor="hero_title" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Hero Title (Main)</Label>
                <Input
                  id="hero_title"
                  value={data.hero_title}
                  onChange={(e) => setData('hero_title', e.target.value)}
                  placeholder="e.g., Visionary Leadership"
                  className="h-12 rounded-xl"
                />
                <InputError message={errors.hero_title} />
              </div>

              <div className="grid w-full gap-2">
                <Label htmlFor="hero_subtitle" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Hero Subtitle (Animated Reveal)</Label>
                <Input
                  id="hero_subtitle"
                  value={data.hero_subtitle}
                  onChange={(e) => setData('hero_subtitle', e.target.value)}
                  placeholder="e.g., Leading with Vision & Integrity"
                  className="h-12 rounded-xl"
                />
                <InputError message={errors.hero_subtitle} />
              </div>

              <div className="grid w-full gap-2">
                <Label htmlFor="hero_description" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Hero Description</Label>
                <Textarea
                  id="hero_description"
                  value={data.hero_description}
                  onChange={(e) => setData('hero_description', e.target.value)}
                  placeholder="Enter deep vision description..."
                  className="min-h-[120px] rounded-[1.5rem] p-4"
                />
                <InputError message={errors.hero_description} />
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="grid w-full gap-2">
                  <Label htmlFor="hero_image" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Hero Image</Label>
                  <Input
                    id="hero_image"
                    type="file"
                    onChange={(e) => setData('hero_image', e.target.files?.[0] || null)}
                    className="h-12 rounded-xl pt-2"
                  />
                  {settings.hero_image && (
                    <p className="text-[10px] text-muted-foreground mt-1 ml-1">Current: {settings.hero_image}</p>
                  )}
                  <InputError message={errors.hero_image} />
                </div>

                <div className="grid w-full gap-2">
                  <Label htmlFor="experience_years" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Legacy Count 1 (e.g. 25)</Label>
                  <Input
                    id="experience_years"
                    value={data.experience_years}
                    onChange={(e) => setData('experience_years', e.target.value)}
                    placeholder="e.g., 25"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.experience_years} />
                </div>

                <div className="grid w-full gap-2">
                  <Label htmlFor="experience_years_2" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Legacy Count 2 (e.g. 100)</Label>
                  <Input
                    id="experience_years_2"
                    value={data.experience_years_2}
                    onChange={(e) => setData('experience_years_2', e.target.value)}
                    placeholder="e.g., 100"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.experience_years_2} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="grid w-full gap-2">
                  <Label htmlFor="experience_label_1" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Legacy Label 1</Label>
                  <Input
                    id="experience_label_1"
                    value={data.experience_label_1}
                    onChange={(e) => setData('experience_label_1', e.target.value)}
                    placeholder="e.g., Years Active"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.experience_label_1} />
                </div>

                <div className="grid w-full gap-2">
                  <Label htmlFor="experience_label_2" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Legacy Label 2</Label>
                  <Input
                    id="experience_label_2"
                    value={data.experience_label_2}
                    onChange={(e) => setData('experience_label_2', e.target.value)}
                    placeholder="e.g., Policy Impacts"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.experience_label_2} />
                </div>
              </div>
            </div>
          </div>

          {/* Unity Section */}
          <div className="space-y-6 rounded-[2.5rem] border bg-card p-10 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-[4rem]" />

            <div className="flex items-center gap-3 mb-6 relative z-10">
              <Layout className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">Unity & Legacy Section</h2>
            </div>

            <div className="grid gap-8 relative z-10">
              <div className="grid w-full gap-2">
                <Label htmlFor="unity_title" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Unity Section Title</Label>
                <Input
                  id="unity_title"
                  value={data.unity_title}
                  onChange={(e) => setData('unity_title', e.target.value)}
                  placeholder="e.g., Building a Foundation..."
                  className="h-12 rounded-xl"
                />
                <InputError message={errors.unity_title} />
              </div>

              <div className="grid w-full gap-2">
                <Label htmlFor="unity_description" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Unity Section Description</Label>
                <Textarea
                  id="unity_description"
                  value={data.unity_description}
                  onChange={(e) => setData('unity_description', e.target.value)}
                  placeholder="Enter Unity description..."
                  className="min-h-[100px] rounded-xl"
                />
                <InputError message={errors.unity_description} />
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="grid w-full gap-2">
                  <Label htmlFor="unity_label" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Unity Sub-label</Label>
                  <Input
                    id="unity_label"
                    value={data.unity_label}
                    onChange={(e) => setData('unity_label', e.target.value)}
                    placeholder="e.g., Unity"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.unity_label} />
                </div>
                <div className="grid w-full gap-2">
                  <Label htmlFor="unity_quote" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Unity Quote (Overlay)</Label>
                  <Input
                    id="unity_quote"
                    value={data.unity_quote}
                    onChange={(e) => setData('unity_quote', e.target.value)}
                    placeholder="e.g., Unity is our greatest strength."
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.unity_quote} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="grid w-full gap-2">
                  <Label htmlFor="legacy_number" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Badge Number (e.g. 25)</Label>
                  <Input
                    id="legacy_number"
                    value={data.legacy_number}
                    onChange={(e) => setData('legacy_number', e.target.value)}
                    placeholder="e.g., 25"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.legacy_number} />
                </div>
                <div className="grid w-full gap-2">
                  <Label htmlFor="legacy_label" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Badge Label (e.g. Years of Leadership)</Label>
                  <Input
                    id="legacy_label"
                    value={data.legacy_label}
                    onChange={(e) => setData('legacy_label', e.target.value)}
                    placeholder="e.g., Years of Leadership"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.legacy_label} />
                </div>
              </div>

              <div className="grid w-full gap-2">
                <Label htmlFor="unity_image" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Unity Section Image</Label>
                <Input
                  id="unity_image"
                  type="file"
                  onChange={(e) => setData('unity_image', e.target.files?.[0] || null)}
                  className="h-12 rounded-xl pt-2"
                />
                {settings.unity_image && (
                  <p className="text-[10px] text-muted-foreground mt-1 ml-1">Current: {settings.unity_image}</p>
                )}
                <InputError message={errors.unity_image} />
              </div>
            </div>
          </div>

          {/* News Section */}
          <div className="space-y-6 rounded-[2.5rem] border bg-card p-10 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-[4rem]" />

            <div className="flex items-center gap-3 mb-6 relative z-10">
              <Layout className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">News Section Content</h2>
            </div>

            <div className="grid gap-8 relative z-10">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="grid w-full gap-2">
                  <Label htmlFor="news_label" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">News Sub-label</Label>
                  <Input
                    id="news_label"
                    value={data.news_label}
                    onChange={(e) => setData('news_label', e.target.value)}
                    placeholder="e.g., Stay Informed"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.news_label} />
                </div>
                <div className="grid w-full gap-2">
                  <Label htmlFor="news_title" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">News Title</Label>
                  <Input
                    id="news_title"
                    value={data.news_title}
                    onChange={(e) => setData('news_title', e.target.value)}
                    placeholder="e.g., Latest Movement"
                    className="h-12 rounded-xl"
                  />
                  <InputError message={errors.news_title} />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4 pt-4">
            <Button type="submit" size="lg" disabled={processing} className="rounded-2xl px-12 h-14 font-bold shadow-xl shadow-primary/20">
              {processing && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              Save All Changes
            </Button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
