import AppLayout from '@/layouts/app-layout';
import { dashboard } from '@/routes';
import { type BreadcrumbItem } from '@/types';
import { Head, router, usePage } from '@inertiajs/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Tags, Calendar, Camera, Newspaper, User, MapPin, Building, Home, Filter, X, Shield } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useState } from 'react';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Dashboard',
        href: dashboard().url,
    },
];

interface Stats {
    partyMembers: number;
    partyMemberTypes: number;
    events: number;
    volunteers: number;
    activities: number;
    news: number;
}

interface PartyMember {
    id: number;
    full_name: string;
    email: string;
    created_at: string;
}

interface LocationStat {
    id: number;
    name: string;
    count: number;
}

interface FilterOption {
    id: number;
    name: string;
}

interface Filters {
    province_id: string | null;
    district_id: string | null;
    municipality_id: string | null;
    ward_number: string | null;
}

interface FilterOptions {
    provinces: FilterOption[];
    districts: FilterOption[];
    municipalities: FilterOption[];
    wards: number[];
}

interface Props {
    stats: Stats;
    filteredMemberCount: number;
    districtStats: LocationStat[];
    municipalityStats: LocationStat[];
    recentMembers: PartyMember[];
    filters: Filters;
    filterOptions: FilterOptions;
    noAccess?: boolean;
}

export default function Dashboard({ stats, filteredMemberCount, districtStats, municipalityStats, recentMembers, filters, filterOptions, noAccess }: Props) {
    const { props } = usePage<any>();
    const partyName = props.settings?.party_name || 'Organization';

    const [localFilters, setLocalFilters] = useState({
        province_id: filters.province_id || '',
        district_id: filters.district_id || '',
        municipality_id: filters.municipality_id || '',
    });

    const handleFilterChange = (key: string, value: string) => {
        const newFilters = { ...localFilters, [key]: value };

        // Reset dependent filters
        if (key === 'province_id') {
            newFilters.district_id = '';
            newFilters.municipality_id = '';
        } else if (key === 'district_id') {
            newFilters.municipality_id = '';
        }

        setLocalFilters(newFilters as any);

        // Apply filters via URL
        const queryParams = new URLSearchParams();
        Object.entries(newFilters).forEach(([k, v]) => {
            if (v && v !== 'all') queryParams.set(k, v);
        });

        router.get(`/dashboard?${queryParams.toString()}`, {}, { preserveState: true, preserveScroll: true });
    };

    const clearFilters = () => {
        setLocalFilters({
            province_id: '',
            district_id: '',
            municipality_id: '',
        });
        router.get('/dashboard', {}, { preserveState: true, preserveScroll: true });
    };

    const hasActiveFilters = localFilters.province_id || localFilters.district_id || localFilters.municipality_id;

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Dashboard" />
            <div className="flex h-full flex-1 flex-col gap-6 overflow-x-auto p-4 md:p-6 lg:p-8">
                {noAccess ? (
                    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6 max-w-2xl mx-auto animate-in fade-in zoom-in-95 duration-500">
                        <div className="bg-primary/10 p-6 rounded-full ring-8 ring-primary/5 mb-4">
                            <Home className="h-12 w-12 text-primary" />
                        </div>
                        <div className="space-y-2">
                            <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">
                                Welcome to {partyName}
                            </h1>
                            <p className="text-xl text-muted-foreground font-medium">
                                We're glad to have you here.
                            </p>
                        </div>
                        <div className="p-6 bg-card border rounded-2xl shadow-sm text-left relative overflow-hidden group">
                            <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
                            <p className="text-muted-foreground leading-relaxed">
                                Your account is active. You can navigate through the system using the sidebar on the left to access your modules and assigned tasks.
                                If you need additional permissions to view statistics, please contact your system administrator.
                            </p>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 w-full pt-4">
                            <div className="p-4 rounded-xl border bg-muted/30 flex flex-col items-center gap-2">
                                <Shield className="h-5 w-5 text-muted-foreground" />
                                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Secure Access</span>
                            </div>
                            <div className="p-4 rounded-xl border bg-muted/30 flex flex-col items-center gap-2">
                                <Users className="h-5 w-5 text-muted-foreground" />
                                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Team Member</span>
                            </div>
                            <div className="p-4 rounded-xl border bg-muted/30 flex flex-col items-center gap-2 col-span-2 md:col-span-1">
                                <Calendar className="h-5 w-5 text-muted-foreground" />
                                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Active Status</span>
                            </div>
                        </div>
                    </div>
                ) : (
                    <>
                        {/* General Stats */}
                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Total Party Members</CardTitle>
                                    <Users className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.partyMembers}</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Member Types</CardTitle>
                                    <Tags className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.partyMemberTypes}</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Events</CardTitle>
                                    <Calendar className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.events}</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Volunteers</CardTitle>
                                    <User className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.volunteers}</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Activities</CardTitle>
                                    <Camera className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.activities}</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">News Articles</CardTitle>
                                    <Newspaper className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.news}</div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Location Filters */}
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between">
                                <CardTitle className="flex items-center gap-2">
                                    <Filter className="h-5 w-5" />
                                    Filter Members by Location
                                </CardTitle>
                                {hasActiveFilters && (
                                    <Button variant="ghost" size="sm" onClick={clearFilters}>
                                        <X className="h-4 w-4 mr-1" />
                                        Clear Filters
                                    </Button>
                                )}
                            </CardHeader>
                            <CardContent>
                                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                                    <div className="space-y-2">
                                        <Label>Province</Label>
                                        <div className="mt-1">
                                            <Select
                                                value={localFilters.province_id}
                                                onValueChange={(val) => handleFilterChange('province_id', val)}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="All Provinces" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="all">All Provinces</SelectItem>
                                                    {filterOptions.provinces.map((p) => (
                                                        <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>District</Label>
                                        <div className="mt-1">
                                            <Select
                                                value={localFilters.district_id}
                                                onValueChange={(val) => handleFilterChange('district_id', val)}
                                                disabled={!localFilters.province_id}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="All Districts" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="all">All Districts</SelectItem>
                                                    {filterOptions.districts.map((d) => (
                                                        <SelectItem key={d.id} value={d.id.toString()}>{d.name}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Municipality</Label>
                                        <div className="mt-1">
                                            <Select
                                                value={localFilters.municipality_id}
                                                onValueChange={(val) => handleFilterChange('municipality_id', val)}
                                                disabled={!localFilters.district_id}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="All Municipalities" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="all">All Municipalities</SelectItem>
                                                    {filterOptions.municipalities.map((m) => (
                                                        <SelectItem key={m.id} value={m.id.toString()}>{m.name}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                </div>
                                {hasActiveFilters && (
                                    <div className="mt-4 p-4 bg-primary/10 rounded-lg">
                                        <p className="text-lg font-semibold">
                                            Filtered Members: <span className="text-primary">{filteredMemberCount}</span>
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>

                        {/* Location Statistics */}
                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
                            {/* District Stats */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <MapPin className="h-5 w-5" />
                                        Members by District
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    {districtStats.length > 0 ? (
                                        <div className="space-y-3">
                                            {districtStats.map((d, i) => (
                                                <div key={d.id} className="flex items-center justify-between">
                                                    <div className="flex items-center gap-2">
                                                        <span className="text-xs text-muted-foreground w-4">{i + 1}.</span>
                                                        <span className="font-medium truncate max-w-[150px]">{d.name}</span>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                                                            <div
                                                                className="h-full bg-primary rounded-full"
                                                                style={{ width: `${Math.min((d.count / (districtStats[0]?.count || 1)) * 100, 100)}%` }}
                                                            />
                                                        </div>
                                                        <span className="text-sm font-bold w-8 text-right">{d.count}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <p className="text-muted-foreground text-sm">No data available.</p>
                                    )}
                                </CardContent>
                            </Card>

                            {/* Municipality Stats */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Building className="h-5 w-5" />
                                        Members by Municipality
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    {municipalityStats.length > 0 ? (
                                        <div className="space-y-3">
                                            {municipalityStats.map((m, i) => (
                                                <div key={m.id} className="flex items-center justify-between">
                                                    <div className="flex items-center gap-2">
                                                        <span className="text-xs text-muted-foreground w-4">{i + 1}.</span>
                                                        <span className="font-medium truncate max-w-[150px]">{m.name}</span>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                                                            <div
                                                                className="h-full bg-chart-2 rounded-full"
                                                                style={{ width: `${Math.min((m.count / (municipalityStats[0]?.count || 1)) * 100, 100)}%` }}
                                                            />
                                                        </div>
                                                        <span className="text-sm font-bold w-8 text-right">{m.count}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <p className="text-muted-foreground text-sm">No data available.</p>
                                    )}
                                </CardContent>
                            </Card>
                        </div>

                        {/* Recent Members */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Recent Party Members</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {recentMembers.length > 0 ? (
                                    <div className="space-y-4">
                                        {recentMembers.map((member) => (
                                            <div key={member.id} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                                                <div className="space-y-1">
                                                    <p className="text-sm font-medium leading-none">{member.full_name}</p>
                                                    <p className="text-sm text-muted-foreground">{member.email}</p>
                                                </div>
                                                <div className="text-sm text-muted-foreground">
                                                    {new Date(member.created_at).toLocaleDateString()}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <p className="text-muted-foreground">No members found.</p>
                                )}
                            </CardContent>
                        </Card>
                    </>
                )}
            </div>
        </AppLayout>
    );
}
