<?php

namespace App\Http\Controllers;

use App\Http\Requests\ResourceRequest;
use App\Models\Resource;
use App\Models\ResourcePhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Sagautam5\LocalStateNepal\Entities\District;
use Sagautam5\LocalStateNepal\Entities\Municipality;
use Sagautam5\LocalStateNepal\Entities\Province;

class ResourceController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:view-resources')->only(['index', 'show']);
        $this->middleware('permission:create-resources')->only(['create', 'store']);
        $this->middleware('permission:update-resources')->only(['edit', 'update']);
        $this->middleware('permission:delete-resources')->only(['destroy', 'destroyPhoto']);
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Resource::query()->with('photos');

        // Filtering
        if ($request->filled('province_id')) {
            $query->where('province_id', $request->province_id);
        }
        if ($request->filled('district_id')) {
            $query->where('district_id', $request->district_id);
        }
        if ($request->filled('municipality_id')) {
            $query->where('municipality_id', $request->municipality_id);
        }
        if ($request->filled('ward_number')) {
            $query->where('ward_number', $request->ward_number);
        }

        $resources = $query->latest()->paginate(10)->withQueryString();

        // Location data for names
        $provinceHelper = new Province('en');
        $districtHelper = new District('en');
        $municipalityHelper = new Municipality('en');

        $resources->getCollection()->transform(function ($resource) use ($provinceHelper, $districtHelper, $municipalityHelper) {
            $resource->province_name = $this->getLocationName($provinceHelper->find($resource->province_id));
            $resource->district_name = $this->getLocationName($districtHelper->find($resource->district_id));
            $resource->municipality_name = $this->getLocationName($municipalityHelper->find($resource->municipality_id));
            return $resource;
        });

        // Stats
        $stats = [
            'total' => Resource::count(),
            'by_province' => Resource::select('province_id')
                ->selectRaw('count(*) as count')
                ->groupBy('province_id')
                ->get()
                ->map(function($item) use ($provinceHelper) {
                    $province = $provinceHelper->find($item->province_id);
                    return [
                        'name' => is_object($province) ? $province->name : (is_array($province) ? $province['name'] : 'Unknown'),
                        'count' => $item->count,
                    ];
                }),
        ];

        return Inertia::render('resources/index', [
            'resources' => $resources,
            'filters' => $request->only(['province_id', 'district_id', 'municipality_id', 'ward_number']),
            'stats' => $stats,
            'provinces' => collect($provinceHelper->allProvinces())->map(fn($p) => [
                'id' => is_array($p) ? $p['id'] : $p->id,
                'name' => is_array($p) ? $p['name'] : $p->name
            ]),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $provinceHelper = new Province('en');
        return Inertia::render('resources/create', [
            'provinces' => collect($provinceHelper->allProvinces())->map(fn($p) => [
                'id' => is_array($p) ? $p['id'] : $p->id,
                'name' => is_array($p) ? $p['name'] : $p->name
            ]),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ResourceRequest $request)
    {
        $resource = Resource::create($request->validated());

        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $photo) {
                $path = $photo->store('resources/photos', 'public');
                $resource->photos()->create(['photo_path' => $path]);
            }
        }

        if ($request->user()->hasPermission('view-resources') || $request->user()->hasRole('administrator')) {
            return redirect()->route('resources.index')->with('success', 'Resource created successfully.');
        }

        return redirect()->route('dashboard')->with('success', 'Resource created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Resource $resource)
    {
        $provinceHelper = new Province('en');
        $districtHelper = new District('en');
        $municipalityHelper = new Municipality('en');

        $resource->load('photos');
        $resource->province_name = $this->getLocationName($provinceHelper->find($resource->province_id));
        $resource->district_name = $this->getLocationName($districtHelper->find($resource->district_id));
        $resource->municipality_name = $this->getLocationName($municipalityHelper->find($resource->municipality_id));

        return Inertia::render('resources/show', [
            'resource' => $resource,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Resource $resource)
    {
        $provinceHelper = new Province('en');
        $districtHelper = new District('en');
        $municipalityHelper = new Municipality('en');

        $resource->load('photos');

        // Get initial lists for editing
        $provinces = collect($provinceHelper->allProvinces())->map(fn($p) => [
            'id' => is_array($p) ? $p['id'] : $p->id,
            'name' => is_array($p) ? $p['name'] : $p->name
        ]);
        $districts = collect($districtHelper->getDistrictsByProvince($resource->province_id))->map(fn($d) => [
            'id' => is_array($d) ? $d['id'] : $d->id,
            'name' => is_array($d) ? $d['name'] : $d->name
        ]);
        $municipalities = collect($municipalityHelper->getMunicipalitiesByDistrict($resource->district_id))->map(fn($m) => [
            'id' => is_array($m) ? $m['id'] : $m->id,
            'name' => is_array($m) ? $m['name'] : $m->name
        ]);

        return Inertia::render('resources/edit', [
            'resource' => $resource,
            'provinces' => $provinces,
            'initialDistricts' => $districts,
            'initialMunicipalities' => $municipalities,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ResourceRequest $request, Resource $resource)
    {
        $resource->update($request->validated());

        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $photo) {
                $path = $photo->store('resources/photos', 'public');
                $resource->photos()->create(['photo_path' => $path]);
            }
        }

        if ($request->user()->hasPermission('view-resources') || $request->user()->hasRole('administrator')) {
            return redirect()->route('resources.index')->with('success', 'Resource updated successfully.');
        }

        return redirect()->route('dashboard')->with('success', 'Resource updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Resource $resource)
    {
        foreach ($resource->photos as $photo) {
            Storage::disk('public')->delete($photo->photo_path);
            $photo->delete();
        }

        $resource->delete();

        if (request()->user()->hasPermission('view-resources') || request()->user()->hasRole('administrator')) {
            return redirect()->route('resources.index')->with('success', 'Resource deleted successfully.');
        }

        return redirect()->route('dashboard')->with('success', 'Resource deleted successfully.');
    }

    /**
     * Remove a specific photo.
     */
    public function destroyPhoto(ResourcePhoto $photo)
    {
        Storage::disk('public')->delete($photo->photo_path);
        $photo->delete();

        return back()->with('success', 'Photo deleted successfully.');
    }

    /**
     * Get name from location object/array safely.
     */
    private function getLocationName(mixed $location): string
    {
        if (is_object($location)) {
            return $location->name ?? 'Unknown';
        }
        if (is_array($location)) {
            return $location['name'] ?? 'Unknown';
        }
        return 'Unknown';
    }
}
