<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePartyMemberRequest;
use App\Models\PartyMember;
use App\Models\PartyMemberType;
use Illuminate\Http\RedirectResponse;
use Inertia\Inertia;
use Inertia\Response;
use Sagautam5\LocalStateNepal\Entities\District;
use Sagautam5\LocalStateNepal\Entities\Municipality;
use Sagautam5\LocalStateNepal\Entities\Province;

class PartyMemberController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:view-members')->only(['index', 'show', 'exportExcel', 'exportPdf', 'getCountries', 'sendEmail']);
        $this->middleware('permission:create-members')->only(['create', 'store']);
        $this->middleware('permission:update-members')->only(['edit', 'update']);
        $this->middleware('permission:delete-members')->only(['destroy']);
    }

    /**
     * Display a listing of the resource.
     */
    public function index(): Response
    {
        $query = PartyMember::with('partyMemberType')
            ->filter(request()->only(['province_id', 'district_id', 'municipality_id', 'ward_number', 'party_member_type_id', 'lives_abroad']))
            ->latest();

        $partyMembers = $query->paginate(15)->withQueryString();

        // Calculate Stats
        $stats = [
            'total_members' => PartyMember::count(),
            'by_gender' => PartyMember::selectRaw('gender, count(*) as count')
                ->groupBy('gender')
                ->pluck('count', 'gender'),
            'by_type' => PartyMember::selectRaw('party_member_types.name, count(*) as count')
                ->join('party_member_types', 'party_members.party_member_type_id', '=', 'party_member_types.id')
                ->groupBy('party_member_types.name')
                ->pluck('count', 'name'),
            'lives_abroad' => PartyMember::where('lives_abroad', true)->count(),
        ];

        // Get provinces for filter
        $provinceHelper = new Province('en');
        $provinces = collect($provinceHelper->allProvinces())->map(fn($p) => [
            'id' => is_array($p) ? $p['id'] : $p->id,
            'name' => is_array($p) ? $p['name'] : $p->name
        ])->values();

        // Get member types for filter
        $memberTypes = PartyMemberType::select('id', 'name')->get();

        return Inertia::render('party-members/index', [
            'partyMembers' => $partyMembers,
            'filters' => request()->all(['province_id', 'district_id', 'municipality_id', 'ward_number', 'party_member_type_id', 'lives_abroad']),
            'stats' => $stats,
            'provinces' => $provinces,
            'memberTypes' => $memberTypes,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): Response
    {
        $province = new Province('en');
        $provinces = collect($province->allProvinces())->map(fn ($p) => [
            'id' => is_array($p) ? $p['id'] : $p->id,
            'name' => is_array($p) ? $p['name'] : $p->name,
        ]);

        $partyMemberTypes = PartyMemberType::all(['id', 'name', 'description']);

        return Inertia::render('party-members/create', [
            'provinces' => $provinces,
            'partyMemberTypes' => $partyMemberTypes,
            'countries' => $this->getCountries(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePartyMemberRequest $request): RedirectResponse
    {
        PartyMember::create($request->validated());

        if ($request->user()->hasPermission('view-members') || $request->user()->hasRole('administrator')) {
            return redirect()
                ->route('party-members.index')
                ->with('success', 'Party member created successfully.');
        }

        return redirect()
            ->route('dashboard')
            ->with('success', 'Party member created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(PartyMember $partyMember): Response
    {
        $partyMember->load('partyMemberType');

        // Default values
        $provinceName = 'N/A';
        $districtName = 'N/A';
        $municipalityName = 'N/A';

        if (!$partyMember->lives_abroad) {
            $province = new Province('en');
            $district = new District('en');
            $municipality = new Municipality('en');

            $provinceData = collect($province->allProvinces())
                ->first(fn ($p) => (is_array($p) ? $p['id'] : $p->id) == $partyMember->province_id);
            $provinceName = $provinceData ? (is_array($provinceData) ? $provinceData['name'] : $provinceData->name) : 'N/A';

            $districtData = collect($district->allDistricts())
                ->first(fn ($d) => (is_array($d) ? $d['id'] : $d->id) == $partyMember->district_id);
            $districtName = $districtData ? (is_array($districtData) ? $districtData['name'] : $districtName = $districtData->name) : 'N/A';

            $municipalityData = collect($municipality->allMunicipalities())
                ->first(fn ($m) => (is_array($m) ? $m['id'] : $m->id) == $partyMember->municipality_id);
            $municipalityName = $municipalityData ? (is_array($municipalityData) ? $municipalityData['name'] : $municipalityData->name) : 'N/A';
        }

        // Permanent address
        $permProvinceName = 'N/A';
        $permDistrictName = 'N/A';
        $permMunicipalityName = 'N/A';

        if ($partyMember->permanent_province_id) {
            $province = new Province('en');
            $district = new District('en');
            $municipality = new Municipality('en');

            $pData = collect($province->allProvinces())->first(fn($p) => (is_array($p) ? $p['id'] : $p->id) == $partyMember->permanent_province_id);
            $permProvinceName = $pData ? (is_array($pData) ? $pData['name'] : $pData->name) : 'N/A';

            $dData = collect($district->allDistricts())->first(fn($d) => (is_array($d) ? $d['id'] : $d->id) == $partyMember->permanent_district_id);
            $permDistrictName = $dData ? (is_array($dData) ? $dData['name'] : $dData->name) : 'N/A';

            $mData = collect($municipality->allMunicipalities())->first(fn($m) => (is_array($m) ? $m['id'] : $m->id) == $partyMember->permanent_municipality_id);
            $permMunicipalityName = $mData ? (is_array($mData) ? $mData['name'] : $mData->name) : 'N/A';
        }

        return Inertia::render('party-members/show', [
            'partyMember' => $partyMember,
            'location' => [
                'province' => $provinceName,
                'district' => $districtName,
                'municipality' => $municipalityName,
            ],
            'permLocation' => [
                'province' => $permProvinceName,
                'district' => $permDistrictName,
                'municipality' => $permMunicipalityName,
            ],
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PartyMember $partyMember): Response
    {
        $province = new Province('en');
        $district = new District('en');
        $municipality = new Municipality('en');

        $provinces = collect($province->allProvinces())->map(fn ($p) => [
            'id' => is_array($p) ? $p['id'] : $p->id,
            'name' => is_array($p) ? $p['name'] : $p->name,
        ]);

        $districts = collect($district->getDistrictsByProvince($partyMember->province_id))->map(fn ($d) => [
            'id' => is_array($d) ? $d['id'] : $d->id,
            'name' => is_array($d) ? $d['name'] : $d->name,
        ]);

        $municipalities = collect($municipality->getMunicipalitiesByDistrict($partyMember->district_id))->map(fn ($m) => [
            'id' => is_array($m) ? $m['id'] : $m->id,
            'name' => is_array($m) ? $m['name'] : $m->name,
        ]);

        // Permanent address locations
        $permDistricts = collect($district->getDistrictsByProvince($partyMember->permanent_province_id))->map(fn ($d) => [
            'id' => is_array($d) ? $d['id'] : $d->id,
            'name' => is_array($d) ? $d['name'] : $d->name,
        ]);

        $permMunicipalities = collect($municipality->getMunicipalitiesByDistrict($partyMember->permanent_district_id))->map(fn ($m) => [
            'id' => is_array($m) ? $m['id'] : $m->id,
            'name' => is_array($m) ? $m['name'] : $m->name,
        ]);

        $partyMemberTypes = PartyMemberType::all(['id', 'name', 'description']);

        return Inertia::render('party-members/edit', [
            'partyMember' => $partyMember,
            'provinces' => $provinces,
            'districts' => $districts,
            'municipalities' => $municipalities,
            'permDistricts' => $permDistricts,
            'permMunicipalities' => $permMunicipalities,
            'partyMemberTypes' => $partyMemberTypes,
            'countries' => $this->getCountries(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(StorePartyMemberRequest $request, PartyMember $partyMember): RedirectResponse
    {
        $partyMember->update($request->validated());

        if ($request->user()->hasPermission('view-members') || $request->user()->hasRole('administrator')) {
            return redirect()
                ->route('party-members.index')
                ->with('success', 'Party member updated successfully.');
        }

        return redirect()
            ->route('dashboard')
            ->with('success', 'Party member updated successfully.');
    }

    /**
     * Send email to filtered members.
     */
    public function sendEmail(\Illuminate\Http\Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'subject' => 'required|string|max:255',
            'content' => 'required|string',
            'attachment' => 'nullable|file|max:10240', // Max 10MB
            'filters' => 'nullable|array',
        ]);

        $attachmentPath = null;
        $attachmentName = null;

        if ($request->hasFile('attachment')) {
            $attachmentPath = $request->file('attachment')->store('mail-attachments');
            $attachmentName = $request->file('attachment')->getClientOriginalName();
        }

        \App\Jobs\SendPartyMemberEmails::dispatch(
            $validated['subject'],
            $validated['content'],
            $validated['filters'] ?? [],
            $attachmentPath,
            $attachmentName
        );

        return redirect()
            ->back()
            ->with('success', 'Email sending process has been started for selected members.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PartyMember $partyMember): RedirectResponse
    {
        $partyMember->delete();

        if (request()->user()->hasPermission('view-members') || request()->user()->hasRole('administrator')) {
            return redirect()
                ->route('party-members.index')
                ->with('success', 'Party member deleted successfully.');
        }

        return redirect()
            ->route('dashboard')
            ->with('success', 'Party member deleted successfully.');
    }

    /**
     * Get list of countries for abroad members.
     *
     * @return array<int, array{code: string, name: string}>
     */
    private function getCountries(): array
    {
        return [
            ['code' => 'AF', 'name' => 'Afghanistan'],
            ['code' => 'AL', 'name' => 'Albania'],
            ['code' => 'DZ', 'name' => 'Algeria'],
            ['code' => 'AR', 'name' => 'Argentina'],
            ['code' => 'AU', 'name' => 'Australia'],
            ['code' => 'AT', 'name' => 'Austria'],
            ['code' => 'BD', 'name' => 'Bangladesh'],
            ['code' => 'BE', 'name' => 'Belgium'],
            ['code' => 'BT', 'name' => 'Bhutan'],
            ['code' => 'BR', 'name' => 'Brazil'],
            ['code' => 'BN', 'name' => 'Brunei'],
            ['code' => 'KH', 'name' => 'Cambodia'],
            ['code' => 'CA', 'name' => 'Canada'],
            ['code' => 'CN', 'name' => 'China'],
            ['code' => 'CY', 'name' => 'Cyprus'],
            ['code' => 'CZ', 'name' => 'Czech Republic'],
            ['code' => 'DK', 'name' => 'Denmark'],
            ['code' => 'EG', 'name' => 'Egypt'],
            ['code' => 'FI', 'name' => 'Finland'],
            ['code' => 'FR', 'name' => 'France'],
            ['code' => 'DE', 'name' => 'Germany'],
            ['code' => 'GR', 'name' => 'Greece'],
            ['code' => 'HK', 'name' => 'Hong Kong'],
            ['code' => 'HU', 'name' => 'Hungary'],
            ['code' => 'IS', 'name' => 'Iceland'],
            ['code' => 'IN', 'name' => 'India'],
            ['code' => 'ID', 'name' => 'Indonesia'],
            ['code' => 'IE', 'name' => 'Ireland'],
            ['code' => 'IL', 'name' => 'Israel'],
            ['code' => 'IT', 'name' => 'Italy'],
            ['code' => 'JP', 'name' => 'Japan'],
            ['code' => 'JO', 'name' => 'Jordan'],
            ['code' => 'KW', 'name' => 'Kuwait'],
            ['code' => 'LV', 'name' => 'Latvia'],
            ['code' => 'LB', 'name' => 'Lebanon'],
            ['code' => 'LT', 'name' => 'Lithuania'],
            ['code' => 'LU', 'name' => 'Luxembourg'],
            ['code' => 'MO', 'name' => 'Macau'],
            ['code' => 'MY', 'name' => 'Malaysia'],
            ['code' => 'MV', 'name' => 'Maldives'],
            ['code' => 'MT', 'name' => 'Malta'],
            ['code' => 'MX', 'name' => 'Mexico'],
            ['code' => 'MM', 'name' => 'Myanmar'],
            ['code' => 'NL', 'name' => 'Netherlands'],
            ['code' => 'NZ', 'name' => 'New Zealand'],
            ['code' => 'NO', 'name' => 'Norway'],
            ['code' => 'OM', 'name' => 'Oman'],
            ['code' => 'PK', 'name' => 'Pakistan'],
            ['code' => 'PH', 'name' => 'Philippines'],
            ['code' => 'PL', 'name' => 'Poland'],
            ['code' => 'PT', 'name' => 'Portugal'],
            ['code' => 'QA', 'name' => 'Qatar'],
            ['code' => 'RO', 'name' => 'Romania'],
            ['code' => 'RU', 'name' => 'Russia'],
            ['code' => 'SA', 'name' => 'Saudi Arabia'],
            ['code' => 'SG', 'name' => 'Singapore'],
            ['code' => 'SK', 'name' => 'Slovakia'],
            ['code' => 'SI', 'name' => 'Slovenia'],
            ['code' => 'ZA', 'name' => 'South Africa'],
            ['code' => 'KR', 'name' => 'South Korea'],
            ['code' => 'ES', 'name' => 'Spain'],
            ['code' => 'LK', 'name' => 'Sri Lanka'],
            ['code' => 'SE', 'name' => 'Sweden'],
            ['code' => 'CH', 'name' => 'Switzerland'],
            ['code' => 'TW', 'name' => 'Taiwan'],
            ['code' => 'TH', 'name' => 'Thailand'],
            ['code' => 'TR', 'name' => 'Turkey'],
            ['code' => 'AE', 'name' => 'United Arab Emirates'],
            ['code' => 'GB', 'name' => 'United Kingdom'],
            ['code' => 'US', 'name' => 'United States'],
            ['code' => 'VN', 'name' => 'Vietnam'],
        ];
    }
}
