<?php

namespace App\Http\Controllers;

use App\Http\Requests\ResourceRequest;
use App\Models\Leader;
use App\Models\Resource;
use Illuminate\Http\RedirectResponse;
use Inertia\Inertia;
use Inertia\Response;
use Sagautam5\LocalStateNepal\Entities\Province;

class PublicResourceController extends Controller
{
    /**
     * Show the form for creating a new community resource.
     */
    public function create(): Response
    {
        $provinceHelper = new Province('en');
        return Inertia::render('public/resources/submit', [
            'provinces' => collect($provinceHelper->allProvinces())->map(fn($p) => [
                'id' => is_array($p) ? $p['id'] : $p->id,
                'name' => is_array($p) ? $p['name'] : $p->name
            ]),
            'leader' => Leader::first(),
        ]);
    }

    /**
     * Store a newly created community resource.
     */
    public function store(ResourceRequest $request): RedirectResponse
    {
        $resource = Resource::create($request->validated());

        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $photo) {
                $path = $photo->store('resources/photos', 'public');
                $resource->photos()->create(['photo_path' => $path]);
            }
        }

        return redirect()->route('community.resources.create')->with('success', 'Thank you for submitting your community project! We will review it shortly.');
    }
}
