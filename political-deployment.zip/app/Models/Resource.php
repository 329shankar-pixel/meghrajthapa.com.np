<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Resource extends Model
{
    /** @use HasFactory<\Database\Factories\ResourceFactory> */
    use HasFactory;

    protected $fillable = [
        'title',
        'description',
        'province_id',
        'district_id',
        'municipality_id',
        'ward_number',
        'tole',
        'person_name',
        'person_email',
        'person_phone',
    ];

    /**
     * @return HasMany<ResourcePhoto, $this>
     */
    public function photos(): HasMany
    {
        return $this->hasMany(ResourcePhoto::class);
    }
}
