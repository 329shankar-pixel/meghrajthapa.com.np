<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Volunteer extends Model
{
    /** @use HasFactory<\Database\Factories\VolunteerFactory> */
    use HasFactory;

    protected $fillable = [
        'event_id',
        'full_name',
        'phone',
        'email',
        'province_id',
        'district_id',
        'municipality_id',
        'ward_number',
    ];

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class);
    }
}
