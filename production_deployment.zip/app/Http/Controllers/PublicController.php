<?php

namespace App\Http\Controllers;

use App\Models\Leader;
use App\Models\News;
use App\Models\TeamMember;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class PublicController extends Controller
{
    /**
     * Display the public homepage.
     */
    public function index(): Response
    {
        $leader = Leader::with(['timelines' => function ($query) {
            $query->orderBy('date', 'desc');
        }])->first();

        $stats = \App\Models\Stat::orderBy('sort_order')->get();
        $missions = \App\Models\Mission::orderBy('sort_order')->get();
        $news = News::where('is_published', true)->latest('published_at')->take(6)->get();
        $activities = \App\Models\Activity::with('photos')->latest('date')->take(3)->get();

        return Inertia::render('public/index', [
            'leader' => $leader,
            'timelines' => $leader?->timelines ?? [],
            'news' => $news,
            'activities' => $activities,
            'stats' => $stats,
            'missions' => $missions,
            'partyName' => \App\Models\Setting::get('party_name', config('app.name', 'राजनीतिक दल')),
            'settings' => \App\Models\Setting::all()->pluck('value', 'key'),
        ]);
    }

    /**
     * Handle join team form submission.
     */
    public function joinTeam(\App\Http\Requests\JoinTeamRequest $request): \Illuminate\Http\RedirectResponse
    {
        TeamMember::create([
            'full_name' => $request->full_name,
            'email' => $request->email,
            'phone' => $request->phone,
            'address' => $request->address,
            'message' => $request->message,
        ]);

        return redirect()->back()->with('success', 'Thank you for joining! We will contact you soon.');
    }

    public function biography(): Response
    {
        $leader = Leader::with(['timelines' => function ($query) {
            $query->orderBy('date', 'desc');
        }])->first();

        return Inertia::render('public/biography', [
            'leader' => $leader,
            'timelines' => $leader?->timelines ?? [],
        ]);
    }

    public function news(): Response
    {
        return Inertia::render('public/news/index', [
            'news' => News::where('is_published', true)->latest('published_at')->paginate(12),
            'leader' => Leader::first(),
        ]);
    }

    public function newsShow(News $news): Response
    {
        return Inertia::render('public/news/show', [
            'news' => $news,
            'leader' => Leader::first(),
        ]);
    }

    public function blog(): Response
    {
        return Inertia::render('public/blog/index', [
            'posts' => \App\Models\Post::where('is_published', true)->latest('published_at')->paginate(12),
            'leader' => Leader::first(),
        ]);
    }

    public function blogShow(\App\Models\Post $post): Response
    {
        return Inertia::render('public/blog/show', [
            'post' => $post,
            'leader' => Leader::first(),
        ]);
    }

    public function events(): Response
    {
        return Inertia::render('public/events/index', [
            'events' => \App\Models\Event::latest('event_date')->paginate(12),
            'leader' => Leader::first(),
        ]);
    }

    public function activities(): Response
    {
        return Inertia::render('public/activities/index', [
            'activities' => \App\Models\Activity::with('photos')->latest('date')->paginate(12),
            'leader' => Leader::first(),
        ]);
    }

    public function activityShow(\App\Models\Activity $activity): Response
    {
        return Inertia::render('public/activities/show', [
            'activity' => $activity->load('photos'),
            'leader' => Leader::first(),
        ]);
    }

    public function galleries(Request $request): Response
    {
        $query = \App\Models\LeaderGallery::query()->latest()->with(['photos', 'category']);

        if ($request->filled('category_id') && $request->category_id !== 'all') {
            $query->where('leader_category_id', $request->category_id);
        }

        return Inertia::render('public/galleries/index', [
            'galleries' => $query->paginate(12)->withQueryString(),
            'categories' => \App\Models\LeaderCategory::whereHas('galleries')->get(['id', 'name']),
            'leader' => Leader::first(),
            'filters' => $request->only(['category_id']),
        ]);
    }

    public function infographics(): Response
    {
        return Inertia::render('public/infographics/index', [
            'infographics' => \App\Models\Infographic::latest()->paginate(12),
            'leader' => Leader::first(),
        ]);
    }

    public function resources(): Response
    {
        return Inertia::render('public/resources/index', [
            'resources' => \App\Models\Resource::latest()->paginate(12),
            'leader' => Leader::first(),
        ]);
    }

    public function videos(): Response
    {
        return Inertia::render('public/videos/index', [
            'videos' => \App\Models\LeaderVideo::latest()->paginate(12),
            'leader' => Leader::first(),
        ]);
    }

    public function resourceSubmit(): Response
    {
        $province = new \Sagautam5\LocalStateNepal\Entities\Province('en');
        $provinces = collect($province->allProvinces())->map(fn ($p) => [
            'id' => is_array($p) ? $p['id'] : $p->id,
            'name' => is_array($p) ? $p['name'] : $p->name,
        ]);

        return Inertia::render('public/resources/submit', [
            'provinces' => $provinces,
            'leader' => Leader::first(),
        ]);
    }

    public function resourceStore(\App\Http\Requests\ResourceRequest $request): \Illuminate\Http\RedirectResponse
    {
        $resource = \App\Models\Resource::create($request->validated());

        if ($request->hasFile('photos')) {
            foreach ($request->file('photos') as $photo) {
                $path = $photo->store('resources/photos', 'public');
                $resource->photos()->create(['photo_path' => $path]);
            }
        }

        return redirect()->route('public.resources.submit')->with('success', 'Resource submitted successfully. Thank you!');
    }

    public function eventShow(\App\Models\Event $event): Response
    {
        $province = new \Sagautam5\LocalStateNepal\Entities\Province('en');
        $provinces = collect($province->allProvinces())->map(fn ($p) => [
            'id' => is_array($p) ? $p['id'] : $p->id,
            'name' => is_array($p) ? $p['name'] : $p->name,
        ]);

        return Inertia::render('public/events/show', [
            'event' => $event,
            'provinces' => $provinces,
            'leader' => Leader::first(),
        ]);
    }

    public function volunteerStore(\App\Http\Requests\StoreVolunteerRequest $request, \App\Models\Event $event): \Illuminate\Http\RedirectResponse
    {
        \App\Models\Volunteer::create([
            'event_id' => $event->id,
            'full_name' => $request->full_name,
            'phone' => $request->phone,
            'email' => $request->email,
            'province_id' => $request->province_id,
            'district_id' => $request->district_id,
            'municipality_id' => $request->municipality_id,
            'ward_number' => $request->ward_number,
        ]);

        return redirect()->route('public.events.show', $event)->with('success', 'Thank you for volunteering! We will contact you soon.');
    }
}
