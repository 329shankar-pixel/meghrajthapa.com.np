import { Head, useForm, Link } from '@inertiajs/react';
import PublicLayout from '@/layouts/public-layout';
import React, { FormEventHandler, useState, useEffect, useRef } from 'react';
import {
  CheckCircle,
  Calendar,
  ChevronRight,
  Loader2,
  Sparkles,
  Users,
  Target,
  Award,
  ArrowDown,
  Play,
  Heart,
  Zap,
  Shield,
  MessageCircle,
  ArrowRight,
  Star,
  Newspaper,
  Camera,
  MapPin,
  Building2
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import AnimatedStat from '@/components/public/animated-stat';
import InteractiveTimeline from '@/components/public/interactive-timeline';

interface Timeline {
  id: number;
  title: string;
  date: string;
  photo: string | null;
}

interface News {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  featured_image: string | null;
  published_at: string;
}

interface Activity {
  id: number;
  title: string;
  slug: string;
  location: string;
  date: string | null;
  cover_image: string | null;
  photos?: { id: number; photo_path: string }[];
}

interface Leader {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  slug: string;
  image: string | null;
  bio: string | null;
  social_links: Record<string, string> | null;
}

interface Props {
  leader: Leader | null;
  timelines: Timeline[];
  news: News[];
  activities: Activity[];
  stats: StatItem[];
  missions: MissionItem[];
  partyName?: string;
  settings: Record<string, string>;
}

interface StatItem {
  icon: string | null;
  value: string;
  label: string;
}

interface MissionItem {
  title: string;
  description: string;
  icon: string | null;
  color: string;
}

export default function PublicHome({ leader, timelines = [], news = [], activities = [], stats = [], missions = [], partyName = 'राजनीतिक दल', settings }: Props) {
  const [formSuccess, setFormSuccess] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);

    // Intersection Observer for scroll animations
    const observerOptions = {
      threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
        }
      });
    }, observerOptions);

    document.querySelectorAll('.fade-in-section').forEach(el => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const { data, setData, post, processing, errors, reset } = useForm({
    full_name: '',
    email: '',
    phone: '',
    address: '',
    message: '',
  });

  const handleSubmit: FormEventHandler = (e) => {
    e.preventDefault();
    post('/join-team', {
      onSuccess: () => {
        setFormSuccess(true);
        reset();
        setTimeout(() => setFormSuccess(false), 5000);
      },
    });
  };

  const getIcon = (name: string | null) => {
    const icons: Record<string, any> = {
      Users, Target, Heart, Zap, Star, Shield, Award, Play, MessageCircle, Newspaper
    };
    return icons[name || ''] || Star;
  };

  const dynamicStats = stats.length > 0 ? stats.map(s => ({
    icon: getIcon(s.icon),
    value: s.value,
    label: s.label
  })) : [
    { icon: Users, value: '1,00,000+', label: 'Supporters' },
    { icon: Target, value: '77', label: 'Districts' },
    { icon: Heart, value: '500+', label: 'Volunteers' },
    { icon: Zap, value: '250+', label: 'Initiatives' },
  ];

  const dynamicMissions = missions.length > 0 ? missions.map(m => ({
    title: m.title,
    desc: m.description,
    icon: getIcon(m.icon),
    color: m.color
  })) : [
    {
      title: 'Economic Growth',
      desc: 'Promoting sustainable development and industrial modernization.',
      icon: Zap,
      color: 'red'
    },
    {
      title: 'Social Justice',
      desc: 'Ensuring equality and opportunities for every citizen.',
      icon: Shield,
      color: 'green'
    },
    {
      title: 'Good Governance',
      desc: 'Transparency and accountability in every public service.',
      icon: Target,
      color: 'red'
    }
  ];

  const heroTitle = settings?.hero_title || 'Leading with';
  const heroSubtitle = settings?.hero_subtitle || 'Vision & Integrity';
  const heroDescription = settings?.hero_description || 'Join our movement in building a modern, prosperous, and inclusive nation. Together, we can shape the future we deserve.';
  const heroImage = settings?.hero_image ? `/storage/${settings.hero_image}` : (leader?.image ? `/storage/${leader.image}` : null);

  const experienceYears = settings?.experience_years || '25';
  const experienceLabel1 = settings?.experience_label_1 || 'Years Active';
  const experienceYears2 = settings?.experience_years_2 || '100';
  const experienceLabel2 = settings?.experience_label_2 || 'Policy Impacts';

  const unityLabel = settings?.unity_label || 'Our Commitment';
  const unityTitle = settings?.unity_title || 'Building a Foundation for Generations.';
  const unityDescription = settings?.unity_description || 'We don\'t just plan for the next election; we plan for the next century. Our vision is built on progress, equality, and prosperity for all.';
  const unityImage = settings?.unity_image ? `/storage/${settings.unity_image}` : "https://images.unsplash.com/photo-1541872703-74c5e443d1f5?q=80&w=2000&auto=format&fit=crop";
  const unityQuote = settings?.unity_quote || '"Unity is our greatest strength."';

  const legacyNumber = settings?.legacy_number || '25';
  const legacyLabel = settings?.legacy_label || 'Years of Leadership';

  const marqueeKeywords = settings?.marquee_keywords
    ? settings.marquee_keywords.split(',').map(s => s.trim())
    : ['Prosperity', 'Unity', 'Progress'];

  const newsLabel = settings?.news_label || 'Stay Informed';
  const newsTitle = settings?.news_title || 'Latest Movement';

  const ctaTitle = settings?.cta_title || 'Be the Change You Want to See.';
  const ctaDescription = settings?.cta_description || 'Our strength comes from the people. Sign up today to volunteer, donate, or simply stay updated with our progress.';

  return (
    <PublicLayout partyName={partyName} socialLinks={leader?.social_links ?? undefined}>
      <Head title="Homepage">
        <meta name="description" content={`Welcome to ${partyName} - Working towards a prosperous nation`} />
      </Head>

      {/* Hero Section */}
      <section className="relative min-h-[95vh] flex items-center pt-20 overflow-hidden bg-white dark:bg-gray-950">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 z-0">
          {/* Blob Gradients */}
          <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-[var(--political-red)]/5 dark:bg-[var(--political-red)]/10 rounded-full blur-[100px] animate-float-slow" />
          <div className="absolute top-[20%] -right-[10%] w-[40%] h-[40%] bg-[var(--political-green)]/5 dark:bg-[var(--political-green)]/10 rounded-full blur-[100px] animate-float-slow delay-1000" />

          {/* Grid Pattern */}
          <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
            backgroundSize: '40px 40px',
          }} />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            {/* Text Content */}
            <div className="lg:col-span-7 space-y-10">
              <div className="flex items-center gap-3 bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 px-4 py-2 rounded-2xl w-fit animate-fade-in-up">
                <Star className="w-4 h-4 text-[var(--political-red)] fill-[var(--political-red)]" />
                <span className="text-xs font-black uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">The People's Choice</span>
              </div>

              <div className="space-y-4">
                <h1 className="text-6xl md:text-8xl font-black leading-[1.1] tracking-tight text-[var(--political-green)]">
                  <span className="block overflow-hidden">
                    <span className="block animate-reveal-text">
                      {heroTitle === 'Visionary Leadership' ? (
                        <>
                          <span className="text-[var(--political-green)]">Visionary</span>{' '}
                          <span className="text-[var(--political-green)]">Leadership</span>
                        </>
                      ) : (
                        heroTitle
                      )}
                    </span>
                  </span>
                  <span className="block overflow-hidden italic">
                    <span className="block animate-reveal-text delay-200">
                      {heroSubtitle === 'Vision & Integrity' ? (
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-[var(--political-red)] to-[var(--political-red)]">
                          Vision & Integrity
                        </span>
                      ) : (
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-[var(--political-red)] to-[var(--political-red)]">
                          {heroSubtitle}
                        </span>
                      )}
                    </span>
                  </span>
                </h1>
                <p className="text-xl md:text-2xl text-gray-400 dark:text-gray-400 max-w-2xl leading-relaxed animate-fade-in-up delay-500">
                  {heroDescription}
                </p>
              </div>

              <div className="flex flex-wrap gap-6 pt-4 animate-fade-in-up delay-700">
                <Link
                  href="/joinnow"
                  className="group relative bg-[var(--political-red)] text-white px-10 py-5 rounded-[2rem] font-black text-lg shadow-2xl shadow-red-900/20 hover:scale-[1.05] active:scale-95 transition-all flex items-center gap-3 animate-pulse-cta"
                >
                  Get Involved
                  <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link
                  href="/biography"
                  className="bg-gray-100 dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 px-10 py-5 rounded-[2rem] font-black text-lg hover:shadow-xl transition-all"
                >
                  <span className="text-[var(--political-green)]">The</span>{' '}
                  <span className="text-[var(--political-green)]">Story</span>
                </Link>
              </div>

              {/* Stats Row in Hero */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-8 pt-10 border-t border-gray-100 dark:border-gray-800 animate-fade-in-up delay-1000">
                <div>
                  <div className="text-3xl font-black text-[var(--political-green)]">{experienceYears}+</div>
                  <div className="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">{experienceLabel1}</div>
                </div>
                <div>
                  <div className="text-3xl font-black text-[var(--political-green)]">{experienceYears2}+</div>
                  <div className="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">{experienceLabel2}</div>
                </div>
              </div>
            </div>

            {/* Image Content */}
            <div className="lg:col-span-5 relative mt-12 lg:mt-0">
              <div className="relative z-10 animate-float-slow max-w-lg mx-auto">
                <div className="absolute inset-0 bg-gradient-to-br from-[var(--political-red)] to-[var(--political-green)] rounded-[4rem] blur-[60px] opacity-20 -rotate-6 scale-90" />
                <div className="relative aspect-[4/5] rounded-[3.5rem] overflow-hidden border-[12px] border-white shadow-2xl">
                  {heroImage ? (
                    <img
                      src={heroImage}
                      alt={leader?.name || 'Party Leader'}
                      className="w-full h-full object-cover grayscale-[0.2] hover:grayscale-0 transition-all duration-700"
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                      <Users className="w-20 h-20 text-gray-200" />
                    </div>
                  )}
                  {/* Overlay info */}
                  <div className="absolute bottom-10 left-10 p-6 bg-white/10 backdrop-blur-2xl rounded-3xl border border-white/20">
                    <h3 className="text-2xl font-black text-white leading-none">{leader?.name || 'Party Leader'}</h3>
                    <p className="text-white/70 font-bold uppercase text-[10px] tracking-widest mt-2">{partyName}</p>
                  </div>
                </div>
              </div>

              {/* Decorative floating elements */}
              <div className="absolute -top-10 -right-10 w-24 h-24 bg-white rounded-3xl shadow-2xl flex items-center justify-center animate-bounce-slow delay-300 border border-gray-100 dark:border-gray-800">
                <Heart className="w-10 h-10 text-[var(--political-red)]" />
              </div>
              <div className="absolute top-1/2 -left-10 w-20 h-20 bg-white rounded-full shadow-2xl flex items-center justify-center animate-bounce-slow border border-gray-100 dark:border-gray-800">
                <Zap className="w-8 h-8 text-[var(--political-green)]" />
              </div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
          <div className="w-6 h-10 border-2 border-gray-100 rounded-full flex items-start justify-center p-1">
            <div className="w-1 h-2 bg-[var(--political-red)] rounded-full animate-bounce" />
          </div>
        </div>
      </section>

      {/* Impact Stats Section */}
      <section className="py-32 bg-gray-50/50 dark:bg-gray-900/50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {dynamicStats.map((stat, i) => (
              <AnimatedStat
                key={stat.label}
                icon={stat.icon}
                value={stat.value}
                label={stat.label}
                delay={i * 100}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-24 md:py-32 bg-white dark:bg-gray-950 overflow-hidden relative">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-16 lg:gap-32 items-center">
            <div className="w-full lg:w-1/2 space-y-12 order-1 lg:order-2">
              <div className="fade-in-section space-y-6">
                <span className="text-[var(--political-red)] font-black uppercase tracking-[0.3em] text-xs">{unityLabel}</span>
                <h2 className="text-5xl md:text-7xl font-black text-[var(--political-green)] tracking-tight leading-tight">
                  {unityTitle.includes('Foundation') ? (
                    <>
                      Building a Foundation for <span className="text-[var(--political-green)] underline decoration-[var(--political-red)] decoration-8 underline-offset-8">Generations</span>.
                    </>
                  ) : unityTitle}
                </h2>
                <p className="text-xl text-gray-400 dark:text-gray-500 leading-relaxed max-w-xl">
                  {unityDescription}
                </p>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {dynamicMissions.map((item, i) => (
                  <div key={item.title} className="fade-in-section group flex gap-6 p-8 rounded-[2.5rem] bg-gray-50 dark:bg-gray-900 hover:bg-white dark:hover:bg-gray-800 transition-all duration-500 border border-transparent hover:border-gray-100 dark:hover:border-gray-700 hover:shadow-2xl">
                    <div className={`w-16 h-16 shrink-0 rounded-2xl flex items-center justify-center transition-all duration-500 ${item.color === 'red' ? 'bg-red-50 dark:bg-red-950/30 text-[var(--political-red)] group-hover:bg-[var(--political-red)]' : 'bg-green-50 dark:bg-green-950/30 text-[var(--political-green)] group-hover:bg-[var(--political-green)]'
                      } group-hover:text-white`}>
                      <item.icon className="w-8 h-8" />
                    </div>
                    <div className="space-y-2">
                      <h4 className="text-xl font-black text-[var(--political-green)]">{item.title}</h4>
                      <p className="text-gray-400 dark:text-gray-500 font-medium leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full lg:w-1/2 relative order-2 lg:order-1">
              <div className="fade-in-section relative z-10 group">
                <div className="absolute -inset-4 bg-gradient-to-br from-[var(--political-red)] via-white to-[var(--political-green)] rounded-[3rem] opacity-20 blur-2xl group-hover:opacity-40 transition-opacity duration-1000" />
                <div className="relative aspect-square md:aspect-[3/4] rounded-[2.5rem] overflow-hidden shadow-2xl border-[8px] border-white dark:border-gray-900 bg-gray-100">
                  <img
                    src={unityImage}
                    alt="Unity"
                    className="w-full h-full object-cover scale-105 group-hover:scale-100 transition-transform duration-1000"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--political-red)]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-12">
                    <p className="text-white text-3xl font-black leading-tight italic">{unityQuote}</p>
                  </div>
                </div>
              </div>

              {/* Experience badge */}
              <div className="fade-in-section absolute -bottom-5 -right-5 md:-bottom-10 md:-right-10 bg-white dark:bg-gray-900 p-6 md:p-8 rounded-[2.5rem] shadow-2xl border border-gray-50 dark:border-gray-800 flex items-center gap-6 z-20">
                <div className="text-4xl md:text-5xl font-black text-[var(--political-red)]">{legacyNumber}</div>
                <div className="text-xs font-black uppercase tracking-widest leading-loose text-gray-400 dark:text-gray-500">
                  {legacyLabel.split(' ').map((word, i) => (
                    <React.Fragment key={i}>
                      {word}
                      {i === 1 && <br />}
                      {' '}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-32 bg-gray-50/50 dark:bg-gray-900/50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-24 fade-in-section">
            <span className="text-[var(--political-red)] font-black uppercase tracking-[0.3em] text-xs">The Journey</span>
            <h2 className="text-5xl md:text-7xl font-black text-[var(--political-green)] tracking-tight mt-4">
              <span className="text-[var(--political-red)]">Legacy of</span>{' '}
              <span className="text-[var(--political-green)]">Service</span>
            </h2>
            <p className="text-xl text-gray-400 dark:text-gray-500 mt-6 max-w-2xl mx-auto italic">Tracking our milestones and dedicated service to the nation over the decades.</p>
          </div>

          <InteractiveTimeline items={timelines.slice(0, 6)} />

          <div className="text-center mt-20 fade-in-section">
            <Link
              href="/biography"
              className="inline-flex items-center gap-2 font-black text-[var(--political-green)] hover:text-[var(--political-red)] dark:hover:text-[var(--political-red)] transition-all group"
            >
              DISCOVER THE FULL BIOGRAPHY
              <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      {/* News & Updates Section */}
      <section className="py-32 bg-white dark:bg-gray-950">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8 fade-in-section">
            <div className="space-y-4">
              <span className="text-[var(--political-green)] font-black uppercase tracking-[0.3em] text-xs">{newsLabel}</span>
              <h2 className="text-5xl md:text-7xl font-black text-[var(--political-green)] tracking-tight">
                {newsTitle === 'Latest Movement' ? (
                  <>
                    <span className="text-[var(--political-green)]">Latest</span>{' '}
                    <span className="text-[var(--political-red)]">Movement</span>
                  </>
                ) : newsTitle}
              </h2>
            </div>
            <Link
              href="/updates/news"
              className="px-8 py-4 rounded-2xl bg-gray-50 dark:bg-gray-900 font-black text-sm hover:bg-gray-900 dark:hover:bg-gray-100 dark:hover:text-gray-900 transition-all text-[var(--political-green)]"
            >
              VIEW ARCHIVES
            </Link>
          </div>

          {activities.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              {activities.slice(0, 3).map((activity, i) => (
                <Link
                  href={`/program/activities/${activity.slug}`}
                  key={activity.id}
                  className="fade-in-section group animate-fade-in-up"
                  style={{ animationDelay: `${i * 100}ms` }}
                >
                  <div className="relative aspect-[16/10] rounded-[2.5rem] overflow-hidden mb-8 shadow-sm group-hover:shadow-2xl transition-all duration-500">
                    {activity.cover_image || (activity.photos && activity.photos.length > 0) ? (
                      <img
                        src={`/storage/${activity.cover_image || activity.photos?.[0].photo_path}`}
                        alt={activity.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                        <Camera className="w-12 h-12 text-gray-300" />
                      </div>
                    )}
                    <div className="absolute top-6 left-6">
                      <span className="px-4 py-2 bg-white/90 dark:bg-gray-900/90 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest text-[var(--political-green)] shadow-xl border border-white/20">
                        {activity.date ? new Date(activity.date).toLocaleDateString('en-US', { day: '2-digit', month: 'short' }) : 'Recent'}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-4 px-2">
                    <h3 className="text-2xl font-black text-[var(--political-green)] group-hover:text-[var(--political-red)] transition-colors leading-tight text-balance">
                      {activity.title}
                    </h3>
                    <div className="text-gray-400 dark:text-gray-400 font-bold text-xs uppercase tracking-[0.2em]">
                      {activity.location}
                    </div>

                    <div className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-[var(--political-red)] hover:gap-4 transition-all">
                      Read Narrative
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-gray-50 dark:bg-gray-900 rounded-[3rem] border-2 border-dashed border-gray-100 dark:border-gray-800 fade-in-section">
              <p className="text-gray-400 font-bold uppercase tracking-widest text-sm">New stories are unfolding...</p>
            </div>
          )}
        </div>
      </section>


      {/* Community Project CTA */}
      <section className="py-20 bg-white dark:bg-gray-950 overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="bg-gray-900 dark:bg-black rounded-[4rem] p-12 md:p-24 text-center space-y-10 relative overflow-hidden group shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] border border-gray-800">
            {/* National Colors Top Border */}
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-[var(--political-red)] via-white to-[var(--political-green)] shadow-[0_0_20px_rgba(255,255,255,0.1)]" />

            {/* Background Glows */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[var(--political-red)]/10 rounded-full -mr-60 -mt-60 blur-[120px] group-hover:bg-[var(--political-red)]/15 transition-all duration-1000" />
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[var(--political-green)]/10 rounded-full -ml-60 -mb-60 blur-[120px] group-hover:bg-[var(--political-green)]/15 transition-all duration-1000" />

            <div className="relative z-10 max-w-4xl mx-auto space-y-10">
              <div className="inline-flex items-center gap-3 bg-white/5 border border-white/10 px-6 py-2.5 rounded-2xl backdrop-blur-md animate-fade-in-up">
                <Building2 className="w-5 h-5 text-white" />
                <span className="text-xs font-black uppercase tracking-[0.3em] text-white/70">Local Initiative</span>
              </div>

              <h2 className="text-5xl md:text-8xl font-black text-white tracking-tighter leading-[0.9] text-balance">
                Submit a <span className="text-[var(--political-red-light)] italic">Community</span> <br />
                <span className="relative">
                  Project
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[var(--political-green)] to-transparent opacity-50" />
                </span>
              </h2>

              <p className="text-xl md:text-2xl text-white/50 font-medium max-w-2xl mx-auto leading-relaxed text-balance">
                Empower your neighborhood! Share local initiatives, infrastructure needs, or community resources that deserve national attention.
              </p>

              <div className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-6">
                <Link
                  href="/community/resources/submit"
                  className="group/btn relative inline-flex items-center gap-4 bg-white text-[var(--political-green)] px-14 py-7 rounded-[2.5rem] font-black text-xl shadow-[0_20px_50px_rgba(255,255,255,0.1)] hover:scale-[1.05] active:scale-95 transition-all duration-500 hover:shadow-[0_25px_60px_rgba(255,255,255,0.15)]"
                >
                  START SUBMISSION
                  <div className="relative w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center group-hover/btn:bg-[var(--political-red)] transition-colors duration-500">
                    <ArrowRight className="w-5 h-5 group-hover/btn:text-white transition-colors" />
                  </div>
                </Link>

                <Link
                  href="/program/activities"
                  className="text-white/60 hover:text-white font-black text-sm uppercase tracking-widest border-b-2 border-white/10 hover:border-[var(--political-green)] transition-all py-2"
                >
                  View Past Initiatives
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final Marquee Banner */}
      <section className="py-20 bg-white dark:bg-gray-950 overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="flex items-center gap-16 text-[var(--political-green-dark)] text-8xl font-black uppercase tracking-tighter mx-8">
              <span>{settings?.marquee_name || leader?.name || partyName}</span>
              {marqueeKeywords.map((kw, ki) => (
                <React.Fragment key={ki}>
                  <span>•</span>
                  <span>{kw}</span>
                </React.Fragment>
              ))}
              <span>•</span>
            </div>
          ))}
        </div>
      </section>

      {/* Global Styles for Animations */}
      <style>{`
        .fade-in-section {
          opacity: 0;
          transform: translateY(15px);
          transition: all 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }
        .fade-in-section.is-visible {
          opacity: 1;
          transform: translateY(0);
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 60s linear infinite;
        }
      `}</style>

    </PublicLayout >
  );
}
