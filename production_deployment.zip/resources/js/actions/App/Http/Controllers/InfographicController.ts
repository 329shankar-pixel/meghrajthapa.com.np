import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InfographicController::index
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/leader/infographics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InfographicController::index
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InfographicController::index
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InfographicController::index
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\InfographicController::index
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InfographicController::index
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InfographicController::index
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\InfographicController::store
* @see app/Http/Controllers/InfographicController.php:36
* @route '/infographics'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/infographics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InfographicController::store
* @see app/Http/Controllers/InfographicController.php:36
* @route '/infographics'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InfographicController::store
* @see app/Http/Controllers/InfographicController.php:36
* @route '/infographics'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\InfographicController::store
* @see app/Http/Controllers/InfographicController.php:36
* @route '/infographics'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\InfographicController::store
* @see app/Http/Controllers/InfographicController.php:36
* @route '/infographics'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\InfographicController::destroy
* @see app/Http/Controllers/InfographicController.php:55
* @route '/infographics/{infographic}'
*/
export const destroy = (args: { infographic: number | { id: number } } | [infographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/infographics/{infographic}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\InfographicController::destroy
* @see app/Http/Controllers/InfographicController.php:55
* @route '/infographics/{infographic}'
*/
destroy.url = (args: { infographic: number | { id: number } } | [infographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { infographic: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { infographic: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            infographic: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        infographic: typeof args.infographic === 'object'
        ? args.infographic.id
        : args.infographic,
    }

    return destroy.definition.url
            .replace('{infographic}', parsedArgs.infographic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InfographicController::destroy
* @see app/Http/Controllers/InfographicController.php:55
* @route '/infographics/{infographic}'
*/
destroy.delete = (args: { infographic: number | { id: number } } | [infographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\InfographicController::destroy
* @see app/Http/Controllers/InfographicController.php:55
* @route '/infographics/{infographic}'
*/
const destroyForm = (args: { infographic: number | { id: number } } | [infographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\InfographicController::destroy
* @see app/Http/Controllers/InfographicController.php:55
* @route '/infographics/{infographic}'
*/
destroyForm.delete = (args: { infographic: number | { id: number } } | [infographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const InfographicController = { index, store, destroy }

export default InfographicController