import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LocationController::getProvinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
export const getProvinces = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProvinces.url(options),
    method: 'get',
})

getProvinces.definition = {
    methods: ["get","head"],
    url: '/api/provinces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LocationController::getProvinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
getProvinces.url = (options?: RouteQueryOptions) => {
    return getProvinces.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LocationController::getProvinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
getProvinces.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getProvinces.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getProvinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
getProvinces.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getProvinces.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LocationController::getProvinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
const getProvincesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProvinces.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getProvinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
getProvincesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProvinces.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getProvinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
getProvincesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getProvinces.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getProvinces.form = getProvincesForm

/**
* @see \App\Http\Controllers\LocationController::getDistricts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
export const getDistricts = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDistricts.url(args, options),
    method: 'get',
})

getDistricts.definition = {
    methods: ["get","head"],
    url: '/api/provinces/{province}/districts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LocationController::getDistricts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
getDistricts.url = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { province: args }
    }

    if (Array.isArray(args)) {
        args = {
            province: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        province: args.province,
    }

    return getDistricts.definition.url
            .replace('{province}', parsedArgs.province.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LocationController::getDistricts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
getDistricts.get = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getDistricts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getDistricts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
getDistricts.head = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getDistricts.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LocationController::getDistricts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
const getDistrictsForm = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDistricts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getDistricts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
getDistrictsForm.get = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDistricts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getDistricts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
getDistrictsForm.head = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getDistricts.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getDistricts.form = getDistrictsForm

/**
* @see \App\Http\Controllers\LocationController::getMunicipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
export const getMunicipalities = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMunicipalities.url(args, options),
    method: 'get',
})

getMunicipalities.definition = {
    methods: ["get","head"],
    url: '/api/districts/{district}/municipalities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LocationController::getMunicipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
getMunicipalities.url = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { district: args }
    }

    if (Array.isArray(args)) {
        args = {
            district: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        district: args.district,
    }

    return getMunicipalities.definition.url
            .replace('{district}', parsedArgs.district.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LocationController::getMunicipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
getMunicipalities.get = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getMunicipalities.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getMunicipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
getMunicipalities.head = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getMunicipalities.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LocationController::getMunicipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
const getMunicipalitiesForm = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMunicipalities.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getMunicipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
getMunicipalitiesForm.get = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMunicipalities.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::getMunicipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
getMunicipalitiesForm.head = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getMunicipalities.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getMunicipalities.form = getMunicipalitiesForm

const LocationController = { getProvinces, getDistricts, getMunicipalities }

export default LocationController