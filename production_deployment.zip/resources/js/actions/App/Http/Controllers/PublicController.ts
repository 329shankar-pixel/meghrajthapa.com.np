import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicController::index
* @see app/Http/Controllers/PublicController.php:17
* @route '/'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::index
* @see app/Http/Controllers/PublicController.php:17
* @route '/'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::index
* @see app/Http/Controllers/PublicController.php:17
* @route '/'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::index
* @see app/Http/Controllers/PublicController.php:17
* @route '/'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::index
* @see app/Http/Controllers/PublicController.php:17
* @route '/'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::index
* @see app/Http/Controllers/PublicController.php:17
* @route '/'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::index
* @see app/Http/Controllers/PublicController.php:17
* @route '/'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PublicController::joinTeam
* @see app/Http/Controllers/PublicController.php:43
* @route '/join-team'
*/
export const joinTeam = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: joinTeam.url(options),
    method: 'post',
})

joinTeam.definition = {
    methods: ["post"],
    url: '/join-team',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicController::joinTeam
* @see app/Http/Controllers/PublicController.php:43
* @route '/join-team'
*/
joinTeam.url = (options?: RouteQueryOptions) => {
    return joinTeam.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::joinTeam
* @see app/Http/Controllers/PublicController.php:43
* @route '/join-team'
*/
joinTeam.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: joinTeam.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PublicController::joinTeam
* @see app/Http/Controllers/PublicController.php:43
* @route '/join-team'
*/
const joinTeamForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: joinTeam.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PublicController::joinTeam
* @see app/Http/Controllers/PublicController.php:43
* @route '/join-team'
*/
joinTeamForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: joinTeam.url(options),
    method: 'post',
})

joinTeam.form = joinTeamForm

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
export const biography = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: biography.url(options),
    method: 'get',
})

biography.definition = {
    methods: ["get","head"],
    url: '/biography',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biography.url = (options?: RouteQueryOptions) => {
    return biography.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biography.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biography.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: biography.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
const biographyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biographyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biographyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

biography.form = biographyForm

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
export const news = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})

news.definition = {
    methods: ["get","head"],
    url: '/updates/news',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
news.url = (options?: RouteQueryOptions) => {
    return news.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
news.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
news.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: news.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
const newsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: news.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
newsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: news.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
newsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: news.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

news.form = newsForm

/**
* @see \App\Http\Controllers\PublicController::newsShow
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
export const newsShow = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newsShow.url(args, options),
    method: 'get',
})

newsShow.definition = {
    methods: ["get","head"],
    url: '/updates/news/{news}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::newsShow
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
newsShow.url = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { news: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
        args = { news: args.slug }
    }

    if (Array.isArray(args)) {
        args = {
            news: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        news: typeof args.news === 'object'
        ? args.news.slug
        : args.news,
    }

    return newsShow.definition.url
            .replace('{news}', parsedArgs.news.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::newsShow
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
newsShow.get = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newsShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::newsShow
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
newsShow.head = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: newsShow.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::newsShow
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
const newsShowForm = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: newsShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::newsShow
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
newsShowForm.get = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: newsShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::newsShow
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
newsShowForm.head = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: newsShow.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

newsShow.form = newsShowForm

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
export const blog = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blog.url(options),
    method: 'get',
})

blog.definition = {
    methods: ["get","head"],
    url: '/updates/blog',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blog.url = (options?: RouteQueryOptions) => {
    return blog.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blog.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blog.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blog.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: blog.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
const blogForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blogForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blogForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

blog.form = blogForm

/**
* @see \App\Http\Controllers\PublicController::blogShow
* @see app/Http/Controllers/PublicController.php:92
* @route '/updates/blog/{post}'
*/
export const blogShow = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blogShow.url(args, options),
    method: 'get',
})

blogShow.definition = {
    methods: ["get","head"],
    url: '/updates/blog/{post}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::blogShow
* @see app/Http/Controllers/PublicController.php:92
* @route '/updates/blog/{post}'
*/
blogShow.url = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { post: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
        args = { post: args.slug }
    }

    if (Array.isArray(args)) {
        args = {
            post: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        post: typeof args.post === 'object'
        ? args.post.slug
        : args.post,
    }

    return blogShow.definition.url
            .replace('{post}', parsedArgs.post.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::blogShow
* @see app/Http/Controllers/PublicController.php:92
* @route '/updates/blog/{post}'
*/
blogShow.get = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blogShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blogShow
* @see app/Http/Controllers/PublicController.php:92
* @route '/updates/blog/{post}'
*/
blogShow.head = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: blogShow.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::blogShow
* @see app/Http/Controllers/PublicController.php:92
* @route '/updates/blog/{post}'
*/
const blogShowForm = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blogShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blogShow
* @see app/Http/Controllers/PublicController.php:92
* @route '/updates/blog/{post}'
*/
blogShowForm.get = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blogShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blogShow
* @see app/Http/Controllers/PublicController.php:92
* @route '/updates/blog/{post}'
*/
blogShowForm.head = (args: { post: string | { slug: string } } | [post: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blogShow.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

blogShow.form = blogShowForm

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
export const events = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})

events.definition = {
    methods: ["get","head"],
    url: '/program/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
events.url = (options?: RouteQueryOptions) => {
    return events.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
events.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
events.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: events.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
const eventsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: events.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
eventsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: events.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
eventsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: events.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

events.form = eventsForm

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
export const activities = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activities.url(options),
    method: 'get',
})

activities.definition = {
    methods: ["get","head"],
    url: '/program/activities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activities.url = (options?: RouteQueryOptions) => {
    return activities.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activities.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activities.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activities.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: activities.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
const activitiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activities.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activitiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activities.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activitiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activities.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

activities.form = activitiesForm

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
export const galleries = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galleries.url(options),
    method: 'get',
})

galleries.definition = {
    methods: ["get","head"],
    url: '/media/galleries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleries.url = (options?: RouteQueryOptions) => {
    return galleries.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleries.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleries.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: galleries.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
const galleriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

galleries.form = galleriesForm

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
export const infographics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: infographics.url(options),
    method: 'get',
})

infographics.definition = {
    methods: ["get","head"],
    url: '/media/infographics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographics.url = (options?: RouteQueryOptions) => {
    return infographics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: infographics.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
const infographicsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographicsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographicsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

infographics.form = infographicsForm

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
export const videos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

videos.definition = {
    methods: ["get","head"],
    url: '/media/videos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videos.url = (options?: RouteQueryOptions) => {
    return videos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: videos.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
const videosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

videos.form = videosForm

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
export const resources = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resources.url(options),
    method: 'get',
})

resources.definition = {
    methods: ["get","head"],
    url: '/public-resources',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resources.url = (options?: RouteQueryOptions) => {
    return resources.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resources.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resources.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resources.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resources.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
const resourcesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resources.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resourcesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resources.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resourcesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resources.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

resources.form = resourcesForm

/**
* @see \App\Http\Controllers\PublicController::resourceSubmit
* @see app/Http/Controllers/PublicController.php:164
* @route '/public-resources/submit'
*/
export const resourceSubmit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resourceSubmit.url(options),
    method: 'get',
})

resourceSubmit.definition = {
    methods: ["get","head"],
    url: '/public-resources/submit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::resourceSubmit
* @see app/Http/Controllers/PublicController.php:164
* @route '/public-resources/submit'
*/
resourceSubmit.url = (options?: RouteQueryOptions) => {
    return resourceSubmit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::resourceSubmit
* @see app/Http/Controllers/PublicController.php:164
* @route '/public-resources/submit'
*/
resourceSubmit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resourceSubmit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resourceSubmit
* @see app/Http/Controllers/PublicController.php:164
* @route '/public-resources/submit'
*/
resourceSubmit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resourceSubmit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::resourceSubmit
* @see app/Http/Controllers/PublicController.php:164
* @route '/public-resources/submit'
*/
const resourceSubmitForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resourceSubmit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resourceSubmit
* @see app/Http/Controllers/PublicController.php:164
* @route '/public-resources/submit'
*/
resourceSubmitForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resourceSubmit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resourceSubmit
* @see app/Http/Controllers/PublicController.php:164
* @route '/public-resources/submit'
*/
resourceSubmitForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resourceSubmit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

resourceSubmit.form = resourceSubmitForm

/**
* @see \App\Http\Controllers\PublicController::resourceStore
* @see app/Http/Controllers/PublicController.php:178
* @route '/public-resources/submit'
*/
export const resourceStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resourceStore.url(options),
    method: 'post',
})

resourceStore.definition = {
    methods: ["post"],
    url: '/public-resources/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicController::resourceStore
* @see app/Http/Controllers/PublicController.php:178
* @route '/public-resources/submit'
*/
resourceStore.url = (options?: RouteQueryOptions) => {
    return resourceStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::resourceStore
* @see app/Http/Controllers/PublicController.php:178
* @route '/public-resources/submit'
*/
resourceStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resourceStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PublicController::resourceStore
* @see app/Http/Controllers/PublicController.php:178
* @route '/public-resources/submit'
*/
const resourceStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resourceStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PublicController::resourceStore
* @see app/Http/Controllers/PublicController.php:178
* @route '/public-resources/submit'
*/
resourceStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resourceStore.url(options),
    method: 'post',
})

resourceStore.form = resourceStoreForm

/**
* @see \App\Http\Controllers\PublicController::eventShow
* @see app/Http/Controllers/PublicController.php:192
* @route '/program/events/{event}'
*/
export const eventShow = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eventShow.url(args, options),
    method: 'get',
})

eventShow.definition = {
    methods: ["get","head"],
    url: '/program/events/{event}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::eventShow
* @see app/Http/Controllers/PublicController.php:192
* @route '/program/events/{event}'
*/
eventShow.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { event: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            event: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        event: typeof args.event === 'object'
        ? args.event.id
        : args.event,
    }

    return eventShow.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::eventShow
* @see app/Http/Controllers/PublicController.php:192
* @route '/program/events/{event}'
*/
eventShow.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eventShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::eventShow
* @see app/Http/Controllers/PublicController.php:192
* @route '/program/events/{event}'
*/
eventShow.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: eventShow.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::eventShow
* @see app/Http/Controllers/PublicController.php:192
* @route '/program/events/{event}'
*/
const eventShowForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: eventShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::eventShow
* @see app/Http/Controllers/PublicController.php:192
* @route '/program/events/{event}'
*/
eventShowForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: eventShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::eventShow
* @see app/Http/Controllers/PublicController.php:192
* @route '/program/events/{event}'
*/
eventShowForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: eventShow.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

eventShow.form = eventShowForm

/**
* @see \App\Http\Controllers\PublicController::volunteerStore
* @see app/Http/Controllers/PublicController.php:207
* @route '/program/events/{event}/volunteer'
*/
export const volunteerStore = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: volunteerStore.url(args, options),
    method: 'post',
})

volunteerStore.definition = {
    methods: ["post"],
    url: '/program/events/{event}/volunteer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicController::volunteerStore
* @see app/Http/Controllers/PublicController.php:207
* @route '/program/events/{event}/volunteer'
*/
volunteerStore.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { event: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            event: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        event: typeof args.event === 'object'
        ? args.event.id
        : args.event,
    }

    return volunteerStore.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::volunteerStore
* @see app/Http/Controllers/PublicController.php:207
* @route '/program/events/{event}/volunteer'
*/
volunteerStore.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: volunteerStore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PublicController::volunteerStore
* @see app/Http/Controllers/PublicController.php:207
* @route '/program/events/{event}/volunteer'
*/
const volunteerStoreForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: volunteerStore.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PublicController::volunteerStore
* @see app/Http/Controllers/PublicController.php:207
* @route '/program/events/{event}/volunteer'
*/
volunteerStoreForm.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: volunteerStore.url(args, options),
    method: 'post',
})

volunteerStore.form = volunteerStoreForm

/**
* @see \App\Http\Controllers\PublicController::activityShow
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
export const activityShow = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activityShow.url(args, options),
    method: 'get',
})

activityShow.definition = {
    methods: ["get","head"],
    url: '/program/activities/{activity}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::activityShow
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
activityShow.url = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { activity: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
        args = { activity: args.slug }
    }

    if (Array.isArray(args)) {
        args = {
            activity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        activity: typeof args.activity === 'object'
        ? args.activity.slug
        : args.activity,
    }

    return activityShow.definition.url
            .replace('{activity}', parsedArgs.activity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::activityShow
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
activityShow.get = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activityShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activityShow
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
activityShow.head = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: activityShow.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::activityShow
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
const activityShowForm = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activityShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activityShow
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
activityShowForm.get = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activityShow.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activityShow
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
activityShowForm.head = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activityShow.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

activityShow.form = activityShowForm

const PublicController = { index, joinTeam, biography, news, newsShow, blog, blogShow, events, activities, galleries, infographics, videos, resources, resourceSubmit, resourceStore, eventShow, volunteerStore, activityShow }

export default PublicController