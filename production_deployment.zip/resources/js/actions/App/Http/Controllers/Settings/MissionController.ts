import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\MissionController::index
* @see app/Http/Controllers/Settings/MissionController.php:23
* @route '/missions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/missions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\MissionController::index
* @see app/Http/Controllers/Settings/MissionController.php:23
* @route '/missions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\MissionController::index
* @see app/Http/Controllers/Settings/MissionController.php:23
* @route '/missions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::index
* @see app/Http/Controllers/Settings/MissionController.php:23
* @route '/missions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::index
* @see app/Http/Controllers/Settings/MissionController.php:23
* @route '/missions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::index
* @see app/Http/Controllers/Settings/MissionController.php:23
* @route '/missions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::index
* @see app/Http/Controllers/Settings/MissionController.php:23
* @route '/missions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Settings\MissionController::create
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/missions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\MissionController::create
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\MissionController::create
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::create
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::create
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::create
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::create
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Settings\MissionController::store
* @see app/Http/Controllers/Settings/MissionController.php:30
* @route '/missions'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/missions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\MissionController::store
* @see app/Http/Controllers/Settings/MissionController.php:30
* @route '/missions'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\MissionController::store
* @see app/Http/Controllers/Settings/MissionController.php:30
* @route '/missions'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::store
* @see app/Http/Controllers/Settings/MissionController.php:30
* @route '/missions'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::store
* @see app/Http/Controllers/Settings/MissionController.php:30
* @route '/missions'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Settings\MissionController::show
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}'
*/
export const show = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/missions/{mission}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\MissionController::show
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}'
*/
show.url = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mission: args }
    }

    if (Array.isArray(args)) {
        args = {
            mission: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        mission: args.mission,
    }

    return show.definition.url
            .replace('{mission}', parsedArgs.mission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\MissionController::show
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}'
*/
show.get = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::show
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}'
*/
show.head = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::show
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}'
*/
const showForm = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::show
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}'
*/
showForm.get = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::show
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}'
*/
showForm.head = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Settings\MissionController::edit
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}/edit'
*/
export const edit = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/missions/{mission}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\MissionController::edit
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}/edit'
*/
edit.url = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mission: args }
    }

    if (Array.isArray(args)) {
        args = {
            mission: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        mission: args.mission,
    }

    return edit.definition.url
            .replace('{mission}', parsedArgs.mission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\MissionController::edit
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}/edit'
*/
edit.get = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::edit
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}/edit'
*/
edit.head = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::edit
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}/edit'
*/
const editForm = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::edit
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}/edit'
*/
editForm.get = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::edit
* @see app/Http/Controllers/Settings/MissionController.php:0
* @route '/missions/{mission}/edit'
*/
editForm.head = (args: { mission: string | number } | [mission: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Settings\MissionController::update
* @see app/Http/Controllers/Settings/MissionController.php:45
* @route '/missions/{mission}'
*/
export const update = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/missions/{mission}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Settings\MissionController::update
* @see app/Http/Controllers/Settings/MissionController.php:45
* @route '/missions/{mission}'
*/
update.url = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mission: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { mission: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            mission: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        mission: typeof args.mission === 'object'
        ? args.mission.id
        : args.mission,
    }

    return update.definition.url
            .replace('{mission}', parsedArgs.mission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\MissionController::update
* @see app/Http/Controllers/Settings/MissionController.php:45
* @route '/missions/{mission}'
*/
update.put = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::update
* @see app/Http/Controllers/Settings/MissionController.php:45
* @route '/missions/{mission}'
*/
update.patch = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::update
* @see app/Http/Controllers/Settings/MissionController.php:45
* @route '/missions/{mission}'
*/
const updateForm = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::update
* @see app/Http/Controllers/Settings/MissionController.php:45
* @route '/missions/{mission}'
*/
updateForm.put = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::update
* @see app/Http/Controllers/Settings/MissionController.php:45
* @route '/missions/{mission}'
*/
updateForm.patch = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Settings\MissionController::destroy
* @see app/Http/Controllers/Settings/MissionController.php:60
* @route '/missions/{mission}'
*/
export const destroy = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/missions/{mission}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\MissionController::destroy
* @see app/Http/Controllers/Settings/MissionController.php:60
* @route '/missions/{mission}'
*/
destroy.url = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mission: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { mission: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            mission: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        mission: typeof args.mission === 'object'
        ? args.mission.id
        : args.mission,
    }

    return destroy.definition.url
            .replace('{mission}', parsedArgs.mission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\MissionController::destroy
* @see app/Http/Controllers/Settings/MissionController.php:60
* @route '/missions/{mission}'
*/
destroy.delete = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::destroy
* @see app/Http/Controllers/Settings/MissionController.php:60
* @route '/missions/{mission}'
*/
const destroyForm = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\MissionController::destroy
* @see app/Http/Controllers/Settings/MissionController.php:60
* @route '/missions/{mission}'
*/
destroyForm.delete = (args: { mission: number | { id: number } } | [mission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const MissionController = { index, create, store, show, edit, update, destroy }

export default MissionController