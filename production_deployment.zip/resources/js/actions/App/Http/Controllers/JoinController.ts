import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/joinnow',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\JoinController::index
* @see app/Http/Controllers/JoinController.php:19
* @route '/joinnow'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/joinnow',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\JoinController::store
* @see app/Http/Controllers/JoinController.php:285
* @route '/joinnow'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const JoinController = { index, store }

export default JoinController