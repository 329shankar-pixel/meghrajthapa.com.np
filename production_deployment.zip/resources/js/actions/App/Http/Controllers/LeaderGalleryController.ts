import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LeaderGalleryController::index
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/leader/galleries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::index
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::index
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::index
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::index
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::index
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::index
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\LeaderGalleryController::create
* @see app/Http/Controllers/LeaderGalleryController.php:39
* @route '/leader/galleries/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/leader/galleries/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::create
* @see app/Http/Controllers/LeaderGalleryController.php:39
* @route '/leader/galleries/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::create
* @see app/Http/Controllers/LeaderGalleryController.php:39
* @route '/leader/galleries/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::create
* @see app/Http/Controllers/LeaderGalleryController.php:39
* @route '/leader/galleries/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::create
* @see app/Http/Controllers/LeaderGalleryController.php:39
* @route '/leader/galleries/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::create
* @see app/Http/Controllers/LeaderGalleryController.php:39
* @route '/leader/galleries/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::create
* @see app/Http/Controllers/LeaderGalleryController.php:39
* @route '/leader/galleries/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\LeaderGalleryController::store
* @see app/Http/Controllers/LeaderGalleryController.php:52
* @route '/leader/galleries'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/leader/galleries',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::store
* @see app/Http/Controllers/LeaderGalleryController.php:52
* @route '/leader/galleries'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::store
* @see app/Http/Controllers/LeaderGalleryController.php:52
* @route '/leader/galleries'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::store
* @see app/Http/Controllers/LeaderGalleryController.php:52
* @route '/leader/galleries'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::store
* @see app/Http/Controllers/LeaderGalleryController.php:52
* @route '/leader/galleries'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\LeaderGalleryController::edit
* @see app/Http/Controllers/LeaderGalleryController.php:84
* @route '/leader/galleries/{gallery}/edit'
*/
export const edit = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/leader/galleries/{gallery}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::edit
* @see app/Http/Controllers/LeaderGalleryController.php:84
* @route '/leader/galleries/{gallery}/edit'
*/
edit.url = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gallery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { gallery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            gallery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gallery: typeof args.gallery === 'object'
        ? args.gallery.id
        : args.gallery,
    }

    return edit.definition.url
            .replace('{gallery}', parsedArgs.gallery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::edit
* @see app/Http/Controllers/LeaderGalleryController.php:84
* @route '/leader/galleries/{gallery}/edit'
*/
edit.get = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::edit
* @see app/Http/Controllers/LeaderGalleryController.php:84
* @route '/leader/galleries/{gallery}/edit'
*/
edit.head = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::edit
* @see app/Http/Controllers/LeaderGalleryController.php:84
* @route '/leader/galleries/{gallery}/edit'
*/
const editForm = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::edit
* @see app/Http/Controllers/LeaderGalleryController.php:84
* @route '/leader/galleries/{gallery}/edit'
*/
editForm.get = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::edit
* @see app/Http/Controllers/LeaderGalleryController.php:84
* @route '/leader/galleries/{gallery}/edit'
*/
editForm.head = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\LeaderGalleryController::update
* @see app/Http/Controllers/LeaderGalleryController.php:95
* @route '/leader/galleries/{gallery}'
*/
export const update = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/leader/galleries/{gallery}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::update
* @see app/Http/Controllers/LeaderGalleryController.php:95
* @route '/leader/galleries/{gallery}'
*/
update.url = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gallery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { gallery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            gallery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gallery: typeof args.gallery === 'object'
        ? args.gallery.id
        : args.gallery,
    }

    return update.definition.url
            .replace('{gallery}', parsedArgs.gallery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::update
* @see app/Http/Controllers/LeaderGalleryController.php:95
* @route '/leader/galleries/{gallery}'
*/
update.put = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::update
* @see app/Http/Controllers/LeaderGalleryController.php:95
* @route '/leader/galleries/{gallery}'
*/
const updateForm = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::update
* @see app/Http/Controllers/LeaderGalleryController.php:95
* @route '/leader/galleries/{gallery}'
*/
updateForm.put = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroy
* @see app/Http/Controllers/LeaderGalleryController.php:128
* @route '/leader/galleries/{gallery}'
*/
export const destroy = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/leader/galleries/{gallery}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroy
* @see app/Http/Controllers/LeaderGalleryController.php:128
* @route '/leader/galleries/{gallery}'
*/
destroy.url = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { gallery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { gallery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            gallery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        gallery: typeof args.gallery === 'object'
        ? args.gallery.id
        : args.gallery,
    }

    return destroy.definition.url
            .replace('{gallery}', parsedArgs.gallery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroy
* @see app/Http/Controllers/LeaderGalleryController.php:128
* @route '/leader/galleries/{gallery}'
*/
destroy.delete = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroy
* @see app/Http/Controllers/LeaderGalleryController.php:128
* @route '/leader/galleries/{gallery}'
*/
const destroyForm = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroy
* @see app/Http/Controllers/LeaderGalleryController.php:128
* @route '/leader/galleries/{gallery}'
*/
destroyForm.delete = (args: { gallery: number | { id: number } } | [gallery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroyPhoto
* @see app/Http/Controllers/LeaderGalleryController.php:143
* @route '/leader/gallery-photos/{photo}'
*/
export const destroyPhoto = (args: { photo: number | { id: number } } | [photo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPhoto.url(args, options),
    method: 'delete',
})

destroyPhoto.definition = {
    methods: ["delete"],
    url: '/leader/gallery-photos/{photo}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroyPhoto
* @see app/Http/Controllers/LeaderGalleryController.php:143
* @route '/leader/gallery-photos/{photo}'
*/
destroyPhoto.url = (args: { photo: number | { id: number } } | [photo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { photo: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { photo: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            photo: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        photo: typeof args.photo === 'object'
        ? args.photo.id
        : args.photo,
    }

    return destroyPhoto.definition.url
            .replace('{photo}', parsedArgs.photo.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroyPhoto
* @see app/Http/Controllers/LeaderGalleryController.php:143
* @route '/leader/gallery-photos/{photo}'
*/
destroyPhoto.delete = (args: { photo: number | { id: number } } | [photo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPhoto.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroyPhoto
* @see app/Http/Controllers/LeaderGalleryController.php:143
* @route '/leader/gallery-photos/{photo}'
*/
const destroyPhotoForm = (args: { photo: number | { id: number } } | [photo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyPhoto.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::destroyPhoto
* @see app/Http/Controllers/LeaderGalleryController.php:143
* @route '/leader/gallery-photos/{photo}'
*/
destroyPhotoForm.delete = (args: { photo: number | { id: number } } | [photo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyPhoto.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyPhoto.form = destroyPhotoForm

const LeaderGalleryController = { index, create, store, edit, update, destroy, destroyPhoto }

export default LeaderGalleryController