import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LeaderTimelineController::index
* @see app/Http/Controllers/LeaderTimelineController.php:19
* @route '/leader/timelines'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/leader/timelines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderTimelineController::index
* @see app/Http/Controllers/LeaderTimelineController.php:19
* @route '/leader/timelines'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderTimelineController::index
* @see app/Http/Controllers/LeaderTimelineController.php:19
* @route '/leader/timelines'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::index
* @see app/Http/Controllers/LeaderTimelineController.php:19
* @route '/leader/timelines'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::index
* @see app/Http/Controllers/LeaderTimelineController.php:19
* @route '/leader/timelines'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::index
* @see app/Http/Controllers/LeaderTimelineController.php:19
* @route '/leader/timelines'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::index
* @see app/Http/Controllers/LeaderTimelineController.php:19
* @route '/leader/timelines'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\LeaderTimelineController::store
* @see app/Http/Controllers/LeaderTimelineController.php:36
* @route '/leader/timelines'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/leader/timelines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaderTimelineController::store
* @see app/Http/Controllers/LeaderTimelineController.php:36
* @route '/leader/timelines'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderTimelineController::store
* @see app/Http/Controllers/LeaderTimelineController.php:36
* @route '/leader/timelines'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::store
* @see app/Http/Controllers/LeaderTimelineController.php:36
* @route '/leader/timelines'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::store
* @see app/Http/Controllers/LeaderTimelineController.php:36
* @route '/leader/timelines'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\LeaderTimelineController::update
* @see app/Http/Controllers/LeaderTimelineController.php:53
* @route '/leader/timelines/{timeline}'
*/
export const update = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/leader/timelines/{timeline}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaderTimelineController::update
* @see app/Http/Controllers/LeaderTimelineController.php:53
* @route '/leader/timelines/{timeline}'
*/
update.url = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timeline: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { timeline: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            timeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        timeline: typeof args.timeline === 'object'
        ? args.timeline.id
        : args.timeline,
    }

    return update.definition.url
            .replace('{timeline}', parsedArgs.timeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderTimelineController::update
* @see app/Http/Controllers/LeaderTimelineController.php:53
* @route '/leader/timelines/{timeline}'
*/
update.put = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::update
* @see app/Http/Controllers/LeaderTimelineController.php:53
* @route '/leader/timelines/{timeline}'
*/
const updateForm = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::update
* @see app/Http/Controllers/LeaderTimelineController.php:53
* @route '/leader/timelines/{timeline}'
*/
updateForm.put = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\LeaderTimelineController::destroy
* @see app/Http/Controllers/LeaderTimelineController.php:72
* @route '/leader/timelines/{timeline}'
*/
export const destroy = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/leader/timelines/{timeline}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\LeaderTimelineController::destroy
* @see app/Http/Controllers/LeaderTimelineController.php:72
* @route '/leader/timelines/{timeline}'
*/
destroy.url = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timeline: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { timeline: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            timeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        timeline: typeof args.timeline === 'object'
        ? args.timeline.id
        : args.timeline,
    }

    return destroy.definition.url
            .replace('{timeline}', parsedArgs.timeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderTimelineController::destroy
* @see app/Http/Controllers/LeaderTimelineController.php:72
* @route '/leader/timelines/{timeline}'
*/
destroy.delete = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::destroy
* @see app/Http/Controllers/LeaderTimelineController.php:72
* @route '/leader/timelines/{timeline}'
*/
const destroyForm = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderTimelineController::destroy
* @see app/Http/Controllers/LeaderTimelineController.php:72
* @route '/leader/timelines/{timeline}'
*/
destroyForm.delete = (args: { timeline: number | { id: number } } | [timeline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const LeaderTimelineController = { index, store, update, destroy }

export default LeaderTimelineController