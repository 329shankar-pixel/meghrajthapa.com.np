import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import newsB3a6f8 from './news'
import blog775ff7 from './blog'
import events735790 from './events'
import activities63c2d9 from './activities'
import resources885d5a from './resources'
import volunteer from './volunteer'
/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
export const biography = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: biography.url(options),
    method: 'get',
})

biography.definition = {
    methods: ["get","head"],
    url: '/biography',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biography.url = (options?: RouteQueryOptions) => {
    return biography.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biography.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biography.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: biography.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
const biographyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biographyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::biography
* @see app/Http/Controllers/PublicController.php:56
* @route '/biography'
*/
biographyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

biography.form = biographyForm

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
export const news = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})

news.definition = {
    methods: ["get","head"],
    url: '/updates/news',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
news.url = (options?: RouteQueryOptions) => {
    return news.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
news.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
news.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: news.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
const newsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: news.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
newsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: news.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::news
* @see app/Http/Controllers/PublicController.php:68
* @route '/updates/news'
*/
newsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: news.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

news.form = newsForm

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
export const blog = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blog.url(options),
    method: 'get',
})

blog.definition = {
    methods: ["get","head"],
    url: '/updates/blog',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blog.url = (options?: RouteQueryOptions) => {
    return blog.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blog.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blog.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blog.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: blog.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
const blogForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blogForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::blog
* @see app/Http/Controllers/PublicController.php:84
* @route '/updates/blog'
*/
blogForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

blog.form = blogForm

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
export const events = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})

events.definition = {
    methods: ["get","head"],
    url: '/program/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
events.url = (options?: RouteQueryOptions) => {
    return events.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
events.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
events.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: events.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
const eventsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: events.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
eventsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: events.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::events
* @see app/Http/Controllers/PublicController.php:100
* @route '/program/events'
*/
eventsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: events.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

events.form = eventsForm

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
export const activities = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activities.url(options),
    method: 'get',
})

activities.definition = {
    methods: ["get","head"],
    url: '/program/activities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activities.url = (options?: RouteQueryOptions) => {
    return activities.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activities.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: activities.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activities.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: activities.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
const activitiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activities.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activitiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activities.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::activities
* @see app/Http/Controllers/PublicController.php:108
* @route '/program/activities'
*/
activitiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: activities.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

activities.form = activitiesForm

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
export const galleries = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galleries.url(options),
    method: 'get',
})

galleries.definition = {
    methods: ["get","head"],
    url: '/media/galleries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleries.url = (options?: RouteQueryOptions) => {
    return galleries.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleries.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleries.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: galleries.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
const galleriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::galleries
* @see app/Http/Controllers/PublicController.php:124
* @route '/media/galleries'
*/
galleriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

galleries.form = galleriesForm

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
export const infographics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: infographics.url(options),
    method: 'get',
})

infographics.definition = {
    methods: ["get","head"],
    url: '/media/infographics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographics.url = (options?: RouteQueryOptions) => {
    return infographics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: infographics.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
const infographicsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographicsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::infographics
* @see app/Http/Controllers/PublicController.php:140
* @route '/media/infographics'
*/
infographicsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

infographics.form = infographicsForm

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
export const videos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

videos.definition = {
    methods: ["get","head"],
    url: '/media/videos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videos.url = (options?: RouteQueryOptions) => {
    return videos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: videos.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
const videosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::videos
* @see app/Http/Controllers/PublicController.php:156
* @route '/media/videos'
*/
videosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

videos.form = videosForm

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
export const resources = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resources.url(options),
    method: 'get',
})

resources.definition = {
    methods: ["get","head"],
    url: '/public-resources',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resources.url = (options?: RouteQueryOptions) => {
    return resources.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resources.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resources.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resources.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resources.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
const resourcesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resources.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resourcesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resources.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::resources
* @see app/Http/Controllers/PublicController.php:148
* @route '/public-resources'
*/
resourcesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: resources.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

resources.form = resourcesForm

const publicMethod = {
    biography: Object.assign(biography, biography),
    news: Object.assign(news, newsB3a6f8),
    blog: Object.assign(blog, blog775ff7),
    events: Object.assign(events, events735790),
    activities: Object.assign(activities, activities63c2d9),
    galleries: Object.assign(galleries, galleries),
    infographics: Object.assign(infographics, infographics),
    videos: Object.assign(videos, videos),
    resources: Object.assign(resources, resources885d5a),
    volunteer: Object.assign(volunteer, volunteer),
}

export default publicMethod