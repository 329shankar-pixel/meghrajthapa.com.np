import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
export const show = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/updates/news/{news}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
show.url = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { news: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
        args = { news: args.slug }
    }

    if (Array.isArray(args)) {
        args = {
            news: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        news: typeof args.news === 'object'
        ? args.news.slug
        : args.news,
    }

    return show.definition.url
            .replace('{news}', parsedArgs.news.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
show.get = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
show.head = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
const showForm = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
showForm.get = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:76
* @route '/updates/news/{news}'
*/
showForm.head = (args: { news: string | { slug: string } } | [news: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const news = {
    show: Object.assign(show, show),
}

export default news