import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
export const show = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/program/activities/{activity}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
show.url = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { activity: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
        args = { activity: args.slug }
    }

    if (Array.isArray(args)) {
        args = {
            activity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        activity: typeof args.activity === 'object'
        ? args.activity.slug
        : args.activity,
    }

    return show.definition.url
            .replace('{activity}', parsedArgs.activity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
show.get = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
show.head = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
const showForm = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
showForm.get = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PublicController::show
* @see app/Http/Controllers/PublicController.php:116
* @route '/program/activities/{activity}'
*/
showForm.head = (args: { activity: string | { slug: string } } | [activity: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const activities = {
    show: Object.assign(show, show),
}

export default activities