import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import exportMethod from './export'
/**
* @see \App\Http\Controllers\PartyMemberController::sendEmail
* @see app/Http/Controllers/PartyMemberController.php:241
* @route '/party-members/send-email'
*/
export const sendEmail = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendEmail.url(options),
    method: 'post',
})

sendEmail.definition = {
    methods: ["post"],
    url: '/party-members/send-email',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PartyMemberController::sendEmail
* @see app/Http/Controllers/PartyMemberController.php:241
* @route '/party-members/send-email'
*/
sendEmail.url = (options?: RouteQueryOptions) => {
    return sendEmail.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::sendEmail
* @see app/Http/Controllers/PartyMemberController.php:241
* @route '/party-members/send-email'
*/
sendEmail.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendEmail.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberController::sendEmail
* @see app/Http/Controllers/PartyMemberController.php:241
* @route '/party-members/send-email'
*/
const sendEmailForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sendEmail.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberController::sendEmail
* @see app/Http/Controllers/PartyMemberController.php:241
* @route '/party-members/send-email'
*/
sendEmailForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sendEmail.url(options),
    method: 'post',
})

sendEmail.form = sendEmailForm

/**
* @see \App\Http\Controllers\PartyMemberController::index
* @see app/Http/Controllers/PartyMemberController.php:28
* @route '/party-members'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/party-members',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberController::index
* @see app/Http/Controllers/PartyMemberController.php:28
* @route '/party-members'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::index
* @see app/Http/Controllers/PartyMemberController.php:28
* @route '/party-members'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::index
* @see app/Http/Controllers/PartyMemberController.php:28
* @route '/party-members'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberController::index
* @see app/Http/Controllers/PartyMemberController.php:28
* @route '/party-members'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::index
* @see app/Http/Controllers/PartyMemberController.php:28
* @route '/party-members'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::index
* @see app/Http/Controllers/PartyMemberController.php:28
* @route '/party-members'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\PartyMemberController::create
* @see app/Http/Controllers/PartyMemberController.php:71
* @route '/party-members/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/party-members/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberController::create
* @see app/Http/Controllers/PartyMemberController.php:71
* @route '/party-members/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::create
* @see app/Http/Controllers/PartyMemberController.php:71
* @route '/party-members/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::create
* @see app/Http/Controllers/PartyMemberController.php:71
* @route '/party-members/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberController::create
* @see app/Http/Controllers/PartyMemberController.php:71
* @route '/party-members/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::create
* @see app/Http/Controllers/PartyMemberController.php:71
* @route '/party-members/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::create
* @see app/Http/Controllers/PartyMemberController.php:71
* @route '/party-members/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\PartyMemberController::store
* @see app/Http/Controllers/PartyMemberController.php:91
* @route '/party-members'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/party-members',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PartyMemberController::store
* @see app/Http/Controllers/PartyMemberController.php:91
* @route '/party-members'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::store
* @see app/Http/Controllers/PartyMemberController.php:91
* @route '/party-members'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberController::store
* @see app/Http/Controllers/PartyMemberController.php:91
* @route '/party-members'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberController::store
* @see app/Http/Controllers/PartyMemberController.php:91
* @route '/party-members'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\PartyMemberController::show
* @see app/Http/Controllers/PartyMemberController.php:109
* @route '/party-members/{party_member}'
*/
export const show = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/party-members/{party_member}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberController::show
* @see app/Http/Controllers/PartyMemberController.php:109
* @route '/party-members/{party_member}'
*/
show.url = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member: args.party_member,
    }

    return show.definition.url
            .replace('{party_member}', parsedArgs.party_member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::show
* @see app/Http/Controllers/PartyMemberController.php:109
* @route '/party-members/{party_member}'
*/
show.get = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::show
* @see app/Http/Controllers/PartyMemberController.php:109
* @route '/party-members/{party_member}'
*/
show.head = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberController::show
* @see app/Http/Controllers/PartyMemberController.php:109
* @route '/party-members/{party_member}'
*/
const showForm = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::show
* @see app/Http/Controllers/PartyMemberController.php:109
* @route '/party-members/{party_member}'
*/
showForm.get = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::show
* @see app/Http/Controllers/PartyMemberController.php:109
* @route '/party-members/{party_member}'
*/
showForm.head = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\PartyMemberController::edit
* @see app/Http/Controllers/PartyMemberController.php:174
* @route '/party-members/{party_member}/edit'
*/
export const edit = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/party-members/{party_member}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PartyMemberController::edit
* @see app/Http/Controllers/PartyMemberController.php:174
* @route '/party-members/{party_member}/edit'
*/
edit.url = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member: args.party_member,
    }

    return edit.definition.url
            .replace('{party_member}', parsedArgs.party_member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::edit
* @see app/Http/Controllers/PartyMemberController.php:174
* @route '/party-members/{party_member}/edit'
*/
edit.get = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::edit
* @see app/Http/Controllers/PartyMemberController.php:174
* @route '/party-members/{party_member}/edit'
*/
edit.head = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PartyMemberController::edit
* @see app/Http/Controllers/PartyMemberController.php:174
* @route '/party-members/{party_member}/edit'
*/
const editForm = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::edit
* @see app/Http/Controllers/PartyMemberController.php:174
* @route '/party-members/{party_member}/edit'
*/
editForm.get = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PartyMemberController::edit
* @see app/Http/Controllers/PartyMemberController.php:174
* @route '/party-members/{party_member}/edit'
*/
editForm.head = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\PartyMemberController::update
* @see app/Http/Controllers/PartyMemberController.php:223
* @route '/party-members/{party_member}'
*/
export const update = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/party-members/{party_member}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\PartyMemberController::update
* @see app/Http/Controllers/PartyMemberController.php:223
* @route '/party-members/{party_member}'
*/
update.url = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member: args.party_member,
    }

    return update.definition.url
            .replace('{party_member}', parsedArgs.party_member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::update
* @see app/Http/Controllers/PartyMemberController.php:223
* @route '/party-members/{party_member}'
*/
update.put = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\PartyMemberController::update
* @see app/Http/Controllers/PartyMemberController.php:223
* @route '/party-members/{party_member}'
*/
update.patch = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\PartyMemberController::update
* @see app/Http/Controllers/PartyMemberController.php:223
* @route '/party-members/{party_member}'
*/
const updateForm = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberController::update
* @see app/Http/Controllers/PartyMemberController.php:223
* @route '/party-members/{party_member}'
*/
updateForm.put = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberController::update
* @see app/Http/Controllers/PartyMemberController.php:223
* @route '/party-members/{party_member}'
*/
updateForm.patch = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\PartyMemberController::destroy
* @see app/Http/Controllers/PartyMemberController.php:274
* @route '/party-members/{party_member}'
*/
export const destroy = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/party-members/{party_member}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PartyMemberController::destroy
* @see app/Http/Controllers/PartyMemberController.php:274
* @route '/party-members/{party_member}'
*/
destroy.url = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { party_member: args }
    }

    if (Array.isArray(args)) {
        args = {
            party_member: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        party_member: args.party_member,
    }

    return destroy.definition.url
            .replace('{party_member}', parsedArgs.party_member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PartyMemberController::destroy
* @see app/Http/Controllers/PartyMemberController.php:274
* @route '/party-members/{party_member}'
*/
destroy.delete = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\PartyMemberController::destroy
* @see app/Http/Controllers/PartyMemberController.php:274
* @route '/party-members/{party_member}'
*/
const destroyForm = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PartyMemberController::destroy
* @see app/Http/Controllers/PartyMemberController.php:274
* @route '/party-members/{party_member}'
*/
destroyForm.delete = (args: { party_member: string | number } | [party_member: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const partyMembers = {
    sendEmail: Object.assign(sendEmail, sendEmail),
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    export: Object.assign(exportMethod, exportMethod),
}

export default partyMembers