import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import videos3b3162 from './videos'
import categories from './categories'
import galleries6fe4c2 from './galleries'
import gallery_photos from './gallery_photos'
import timelines from './timelines'
/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/leader/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::create
* @see app/Http/Controllers/LeaderController.php:30
* @route '/leader/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/leader',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderController::store
* @see app/Http/Controllers/LeaderController.php:43
* @route '/leader'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\LeaderController::profile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/leader/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::profile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::profile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::profile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderController::profile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::profile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::profile
* @see app/Http/Controllers/LeaderController.php:79
* @route '/leader/profile'
*/
profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profile.form = profileForm

/**
* @see \App\Http\Controllers\LeaderController::update_profile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
export const update_profile = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update_profile.url(options),
    method: 'put',
})

update_profile.definition = {
    methods: ["put"],
    url: '/leader/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaderController::update_profile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
update_profile.url = (options?: RouteQueryOptions) => {
    return update_profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::update_profile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
update_profile.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update_profile.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LeaderController::update_profile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
const update_profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update_profile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderController::update_profile
* @see app/Http/Controllers/LeaderController.php:95
* @route '/leader/profile'
*/
update_profileForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update_profile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update_profile.form = update_profileForm

/**
* @see \App\Http\Controllers\LeaderController::biography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
export const biography = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: biography.url(options),
    method: 'get',
})

biography.definition = {
    methods: ["get","head"],
    url: '/leader/biography',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::biography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
biography.url = (options?: RouteQueryOptions) => {
    return biography.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::biography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
biography.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::biography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
biography.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: biography.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderController::biography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
const biographyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::biography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
biographyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::biography
* @see app/Http/Controllers/LeaderController.php:121
* @route '/leader/biography'
*/
biographyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: biography.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

biography.form = biographyForm

/**
* @see \App\Http\Controllers\LeaderController::update_biography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
export const update_biography = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update_biography.url(options),
    method: 'put',
})

update_biography.definition = {
    methods: ["put"],
    url: '/leader/biography',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LeaderController::update_biography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
update_biography.url = (options?: RouteQueryOptions) => {
    return update_biography.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::update_biography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
update_biography.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update_biography.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\LeaderController::update_biography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
const update_biographyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update_biography.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\LeaderController::update_biography
* @see app/Http/Controllers/LeaderController.php:137
* @route '/leader/biography'
*/
update_biographyForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update_biography.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update_biography.form = update_biographyForm

/**
* @see \App\Http\Controllers\QuoteController::quotes
* @see app/Http/Controllers/QuoteController.php:27
* @route '/leader/quotes'
*/
export const quotes = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quotes.url(options),
    method: 'get',
})

quotes.definition = {
    methods: ["get","head"],
    url: '/leader/quotes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\QuoteController::quotes
* @see app/Http/Controllers/QuoteController.php:27
* @route '/leader/quotes'
*/
quotes.url = (options?: RouteQueryOptions) => {
    return quotes.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QuoteController::quotes
* @see app/Http/Controllers/QuoteController.php:27
* @route '/leader/quotes'
*/
quotes.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quotes.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuoteController::quotes
* @see app/Http/Controllers/QuoteController.php:27
* @route '/leader/quotes'
*/
quotes.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quotes.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\QuoteController::quotes
* @see app/Http/Controllers/QuoteController.php:27
* @route '/leader/quotes'
*/
const quotesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: quotes.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuoteController::quotes
* @see app/Http/Controllers/QuoteController.php:27
* @route '/leader/quotes'
*/
quotesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: quotes.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuoteController::quotes
* @see app/Http/Controllers/QuoteController.php:27
* @route '/leader/quotes'
*/
quotesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: quotes.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

quotes.form = quotesForm

/**
* @see \App\Http\Controllers\InfographicController::infographics
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
export const infographics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: infographics.url(options),
    method: 'get',
})

infographics.definition = {
    methods: ["get","head"],
    url: '/leader/infographics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InfographicController::infographics
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
infographics.url = (options?: RouteQueryOptions) => {
    return infographics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InfographicController::infographics
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
infographics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InfographicController::infographics
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
infographics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: infographics.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\InfographicController::infographics
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
const infographicsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InfographicController::infographics
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
infographicsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\InfographicController::infographics
* @see app/Http/Controllers/InfographicController.php:22
* @route '/leader/infographics'
*/
infographicsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: infographics.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

infographics.form = infographicsForm

/**
* @see \App\Http\Controllers\LeaderVideoController::videos
* @see app/Http/Controllers/LeaderVideoController.php:22
* @route '/leader/videos'
*/
export const videos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

videos.definition = {
    methods: ["get","head"],
    url: '/leader/videos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderVideoController::videos
* @see app/Http/Controllers/LeaderVideoController.php:22
* @route '/leader/videos'
*/
videos.url = (options?: RouteQueryOptions) => {
    return videos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderVideoController::videos
* @see app/Http/Controllers/LeaderVideoController.php:22
* @route '/leader/videos'
*/
videos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderVideoController::videos
* @see app/Http/Controllers/LeaderVideoController.php:22
* @route '/leader/videos'
*/
videos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: videos.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderVideoController::videos
* @see app/Http/Controllers/LeaderVideoController.php:22
* @route '/leader/videos'
*/
const videosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderVideoController::videos
* @see app/Http/Controllers/LeaderVideoController.php:22
* @route '/leader/videos'
*/
videosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderVideoController::videos
* @see app/Http/Controllers/LeaderVideoController.php:22
* @route '/leader/videos'
*/
videosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: videos.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

videos.form = videosForm

/**
* @see \App\Http\Controllers\LeaderGalleryController::galleries
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
export const galleries = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galleries.url(options),
    method: 'get',
})

galleries.definition = {
    methods: ["get","head"],
    url: '/leader/galleries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderGalleryController::galleries
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
galleries.url = (options?: RouteQueryOptions) => {
    return galleries.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderGalleryController::galleries
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
galleries.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::galleries
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
galleries.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: galleries.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::galleries
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
const galleriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::galleries
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
galleriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderGalleryController::galleries
* @see app/Http/Controllers/LeaderGalleryController.php:24
* @route '/leader/galleries'
*/
galleriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galleries.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

galleries.form = galleriesForm

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/leader/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LeaderController::show
* @see app/Http/Controllers/LeaderController.php:67
* @route '/leader/{slug}'
*/
showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const leader = {
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    profile: Object.assign(profile, profile),
    update_profile: Object.assign(update_profile, update_profile),
    biography: Object.assign(biography, biography),
    update_biography: Object.assign(update_biography, update_biography),
    quotes: Object.assign(quotes, quotes),
    infographics: Object.assign(infographics, infographics),
    videos: Object.assign(videos, videos3b3162),
    categories: Object.assign(categories, categories),
    galleries: Object.assign(galleries, galleries6fe4c2),
    gallery_photos: Object.assign(gallery_photos, gallery_photos),
    timelines: Object.assign(timelines, timelines),
    show: Object.assign(show, show),
}

export default leader