import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\LocationController::provinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
export const provinces = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provinces.url(options),
    method: 'get',
})

provinces.definition = {
    methods: ["get","head"],
    url: '/api/provinces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LocationController::provinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
provinces.url = (options?: RouteQueryOptions) => {
    return provinces.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LocationController::provinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
provinces.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provinces.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::provinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
provinces.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provinces.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LocationController::provinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
const provincesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: provinces.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::provinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
provincesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: provinces.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::provinces
* @see app/Http/Controllers/LocationController.php:15
* @route '/api/provinces'
*/
provincesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: provinces.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

provinces.form = provincesForm

/**
* @see \App\Http\Controllers\LocationController::districts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
export const districts = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: districts.url(args, options),
    method: 'get',
})

districts.definition = {
    methods: ["get","head"],
    url: '/api/provinces/{province}/districts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LocationController::districts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
districts.url = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { province: args }
    }

    if (Array.isArray(args)) {
        args = {
            province: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        province: args.province,
    }

    return districts.definition.url
            .replace('{province}', parsedArgs.province.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LocationController::districts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
districts.get = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: districts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::districts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
districts.head = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: districts.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LocationController::districts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
const districtsForm = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: districts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::districts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
districtsForm.get = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: districts.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::districts
* @see app/Http/Controllers/LocationController.php:29
* @route '/api/provinces/{province}/districts'
*/
districtsForm.head = (args: { province: string | number } | [province: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: districts.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

districts.form = districtsForm

/**
* @see \App\Http\Controllers\LocationController::municipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
export const municipalities = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: municipalities.url(args, options),
    method: 'get',
})

municipalities.definition = {
    methods: ["get","head"],
    url: '/api/districts/{district}/municipalities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LocationController::municipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
municipalities.url = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { district: args }
    }

    if (Array.isArray(args)) {
        args = {
            district: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        district: args.district,
    }

    return municipalities.definition.url
            .replace('{district}', parsedArgs.district.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LocationController::municipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
municipalities.get = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: municipalities.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::municipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
municipalities.head = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: municipalities.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LocationController::municipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
const municipalitiesForm = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: municipalities.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::municipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
municipalitiesForm.get = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: municipalities.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LocationController::municipalities
* @see app/Http/Controllers/LocationController.php:43
* @route '/api/districts/{district}/municipalities'
*/
municipalitiesForm.head = (args: { district: string | number } | [district: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: municipalities.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

municipalities.form = municipalitiesForm

const api = {
    provinces: Object.assign(provinces, provinces),
    districts: Object.assign(districts, districts),
    municipalities: Object.assign(municipalities, municipalities),
}

export default api