<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark' => ($appearance ?? 'system') == 'dark']); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        
        <script>
            (function() {
                const appearance = '<?php echo e($appearance ?? "system"); ?>';

                if (appearance === 'system') {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                    if (prefersDark) {
                        document.documentElement.classList.add('dark');
                    }
                }
            })();
        </script>

        
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }
        </style>

        <?php
            $partyName = \App\Models\Setting::get('party_name', config('app.name', 'Laravel'));
            $tagline = \App\Models\Setting::get('site_tagline', 'Movement for Progress');
            $favicon = \App\Models\Setting::get('favicon');
            $faviconPath = $favicon ? asset('storage/' . $favicon) : asset('favicon.ico');
            $description = "Welcome to $partyName - $tagline. Working towards a prosperous nation.";
        ?>

        <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- SEO & Social Media Preview -->
        <meta name="description" content="<?php echo e($description); ?>">
        <meta property="og:title" content="<?php echo e($partyName); ?>">
        <meta property="og:description" content="<?php echo e($description); ?>">
        <meta property="og:image" content="<?php echo e($faviconPath); ?>">
        <meta property="og:type" content="website">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo e($partyName); ?>">
        <meta name="twitter:description" content="<?php echo e($description); ?>">
        <meta name="twitter:image" content="<?php echo e($faviconPath); ?>">

        <link rel="icon" href="<?php echo e($faviconPath); ?>" sizes="any">
        <link rel="apple-touch-icon" href="<?php echo e($faviconPath); ?>">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH /home/shada/Desktop/Project/Political/resources/views/app.blade.php ENDPATH**/ ?>